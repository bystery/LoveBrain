# -*- coding: utf-8 -*-
"""trusted_controller.py — 可信控制器（修复版 2026-10-21，对接 REPAIR_HANDOFF 工作组 1/2）。

核心修复（对照 ARENA_V1_INDEPENDENT_REVIEW §2/§3/§9）：
  - 真实纵向链路：候选按目录参数加载（host 不再硬编码合成候选）；驱动真实
    init/run_turn/snapshot/restore；gateway.generate 为同步请求/响应 IPC，
    模型原始结果在 run_turn 返回之前交给候选。
  - 评分权威：控制器侧调用 lb_scorer.run_case_scoring_safe（原题快照 +
    canonical_id_map），产出真实 score10/checks/veto；候选自报 score/gold
    字段不在回传白名单内。
  - 上游复用实际 lb_gateway 适配器与事件账：发送前持久化 attempt_started
    （ModelGateway event_log = 控制器侧 jsonl）；失败不退还已发送尝试额度；
    崩溃后 started 记录仍在（明确未决状态）。
  - 隔离：不再对主仓 ACL deny/整树搬移。控制器侧数据（checkpoint/账本/
    评分）放 out_dir/control_dir（不在候选可发现的 run_dir 内）；恢复副本
    不再进入候选可读位置。OS 级受限执行环境在本环境不可用（探针记录见
    ISOLATION.md §受限执行环境探测），网络面与"任意 open 读仓库 gold"
    如实判 FAIL + 最小权限申请，不降格为 RESIDUAL-PASS。
"""
import copy
import datetime
import hashlib
import json
import os
import queue
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid

_HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(_HERE))
sys.path.insert(0, os.path.join(ROOT, "arena"))

import lb_assembly          # noqa: E402  (评分账口径)
import lb_runner            # noqa: E402  权威入口复用（消毒/媒体校验/评分入参）
import lb_scorer            # noqa: E402  评分权威
from lb_gateway import ADAPTERS, ModelGateway, append_jsonl  # noqa: E402

MAX_FRAME = 16_000_000
READ_TIMEOUT = 600.0

HOST_ENTRY = os.path.join(_HERE, "_candidate_host.py")
HOST_RUNTIME = os.path.join(_HERE, "host_runtime.py")
ARENA_STAGED = ("lb_assembly.py", "protocol_public.py")


def _sha_file(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


class TrustedProxy:
    """可信模型代理：复用实际 lb_gateway 适配器与事件账。

    - adapter_name ∈ ADAPTERS（mock/echo 离线；openai_compat 仅在明确授权后
      由调用方传入 LB_API_BASE 等环境时启用）。
    - 事件账 event_log = control_dir/attempt_ledger.jsonl：attempt_started
      在适配器发送【之前】落盘（ModelGateway v3 行为原样复用）；失败不退款。
    - directive（测试替身台本）只在控制器侧合并，不跨 IPC。
    """

    def __init__(self, control_dir, batch_id, candidate, case_gid, quota,
                 adapter_name="mock", run_id=""):
        self.control_dir = control_dir
        self.batch_id, self.candidate, self.case_gid = batch_id, candidate, case_gid
        self.quota = quota
        self.used = 0
        self.run_id = run_id
        self._events = []           # 内存账（含拒绝事件）
        self._seq = 0
        self._directive = {}
        self._backend = ModelGateway(ADAPTERS[adapter_name](),
                                     event_log_path=os.path.join(
                                         control_dir, "attempt_ledger.jsonl"))
        self._backend.run_id = run_id

    def set_directive(self, d):
        self._directive = d or {}

    def _log(self, rec):
        rec = dict(rec, t=datetime.datetime.now().strftime("%H:%M:%S"))
        self._events.append(rec)
        return rec

    def generate(self, req):
        """req 来自宿主网关帧：{system,user,images,model,temperature,timeout_s,tag}。
        返回 (ok, body) 回传宿主。额度在【派发时】计；上游失败不退。"""
        self._seq += 1
        aid = "%s_g%03d" % (self.batch_id, self._seq)
        if self.used >= self.quota:
            self._log({"kind": "quota_exceeded", "attempt_id": aid,
                       "used": self.used, "quota": self.quota})
            return False, {"error": "quota exceeded", "used": self.used,
                           "quota": self.quota}
        self.used += 1
        self._backend.directive = self._directive
        self._backend.set_run_context(self.run_id, self.case_gid)
        images = req.get("images") or []
        try:
            res = self._backend.generate(
                req.get("system", ""), req.get("user", ""),
                images=images or None,
                model=req.get("model"),
                temperature=req.get("temperature"),
                timeout_s=req.get("timeout_s", 120) or 120,
                tag=req.get("tag", "main"))
        except Exception as e:
            # attempt_failed 已由 ModelGateway 落盘；不退还 used（已发送尝试）
            self._log({"kind": "attempt_failed", "attempt_id": aid,
                       "error": "%s: %s" % (type(e).__name__, e),
                       "quota_refunded": False})
            return False, {"error": "upstream failed: %s" % str(e)[:200]}
        # R3#8：完整 usage/响应标识入账（G11 演练验收口径）
        self._log({"kind": "attempt_completed", "attempt_id": aid,
                   "tag": req.get("tag", "main"),
                   "prompt_sha16": hashlib.sha256(
                       (req.get("user") or "").encode("utf-8"))
                   .hexdigest()[:16],
                   "usage": res.get("usage"),
                   "finish": res.get("finish"),
                   "resp_model": res.get("resp_model"),
                   "resp_id": res.get("resp_id")})
        return True, {"text": res.get("text", ""),
                      "finish": res.get("finish", ""),
                      "usage": res.get("usage"),
                      "resp_model": res.get("resp_model"),
                      "resp_id": res.get("resp_id")}

    def turn_usage(self):
        return self._backend.turn_usage()

    @property
    def adapter_name(self):
        return self._backend.adapter_name

    @property
    def audit_errors(self):
        return self._backend.event_log_errors

    def backend_calls(self):
        return self._backend.calls

    def ledger(self):
        return {"batch_id": self.batch_id, "candidate": self.candidate,
                "case_gid": self.case_gid, "quota": self.quota,
                "used": self.used, "adapter": self.adapter_name,
                "events": list(self._events)}


class IsolatedRun:
    """一次隔离运行：staging + 宿主进程 + IPC + 可信侧评分/产物/账本。"""

    def __init__(self, run_dir, out_dir, control_dir, candidate,
                 adapter="mock", quota=8, run_id=None):
        self.run_dir = os.path.abspath(run_dir)
        self.out_dir = os.path.abspath(out_dir)
        self.control_dir = os.path.abspath(control_dir)
        self.candidate = candidate
        self.adapter = adapter
        self.quota = quota
        self.run_id = run_id or ("iso_%s_%s" % (
            datetime.datetime.now().strftime("%Y%m%d_%H%M%S"),
            uuid.uuid4().hex[:6]))
        self.staged = {}
        self.events = []
        self.proc = None
        self._denied = []       # 已 deny 的受保护文件（close() 恒 /reset 还原）
        self._q = queue.Queue()
        self._reader = None

    # ---------- staging ----------
    def stage(self):
        self.staged_root = os.path.join(self.run_dir, "staged")
        for d in (self.staged_root, self.out_dir, self.control_dir):
            shutil.rmtree(d, ignore_errors=True)
            os.makedirs(d, exist_ok=True)
        self._stage_candidate_closure(self.candidate)
        for rel in ARENA_STAGED:
            src = os.path.join(ROOT, "arena", rel)
            dst = os.path.join(self.staged_root, "arena", rel)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy2(src, dst)
            self.staged["arena/" + rel] = _sha_file(src)
        for fn, src in (("_candidate_host.py", HOST_ENTRY),
                        ("host_runtime.py", HOST_RUNTIME)):
            dst = os.path.join(self.staged_root, fn)
            shutil.copy2(src, dst)
            self.staged[fn] = _sha_file(src)
        self.log("STAGED", candidate=self.candidate, files=len(self.staged))
        return self

    def _stage_candidate_closure(self, name, _depth=0):
        """拷贝候选整树；解析 mechanism 源码里引用的候选依赖并递归拷贝
        （如 phase3_facts 引用 candidates/phase1_retr_idf 与 phase2_expr）。"""
        if _depth > 4:
            raise RuntimeError("候选依赖闭包过深")
        src_root = os.path.join(ROOT, "candidates", name)
        if not os.path.isdir(src_root):
            raise RuntimeError("候选目录不存在: %s" % src_root)
        dst_root = os.path.join(self.staged_root, "candidates", name)
        if os.path.isdir(dst_root):
            return set()
        shutil.copytree(src_root, dst_root)
        for cur, _d, fs in os.walk(src_root):
            for f in fs:
                p = os.path.join(cur, f)
                self.staged["candidates/%s/%s" % (
                    name, os.path.relpath(p, src_root).replace("\\", "/"))] = \
                    _sha_file(p)
        mech = os.path.join(src_root, "mechanism", "mechanism.py")
        deps = set()
        if os.path.isfile(mech):
            src = open(mech, encoding="utf-8").read()
            for m in re.finditer(r'"candidates",\s*"([A-Za-z0-9_]+)"', src):
                deps.add(m.group(1))
            for m in re.finditer(r"candidates[/\\\\]+([A-Za-z0-9_]+)", src):
                deps.add(m.group(1))
        deps.discard(name)
        for dep in sorted(deps):
            if os.path.isdir(os.path.join(ROOT, "candidates", dep)):
                self._stage_candidate_closure(dep, _depth + 1)
        return deps

    # ---------- 进程与 IPC ----------
    def start(self):
        env = {"SYSTEMROOT": os.environ.get("SYSTEMROOT", ""),
               "PATH": os.path.dirname(sys.executable),
               "PYTHONHASHSEED": "0"}
        self.proc = subprocess.Popen(
            [sys.executable, "-I", "-B",
             os.path.join(self.staged_root, "_candidate_host.py"),
             "--staged-root", self.staged_root,
             "--candidate", self.candidate],
            cwd=self.staged_root, env=env,
            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, encoding="utf-8")
        self._reader = threading.Thread(target=self._read_loop, daemon=True)
        self._reader.start()
        self.log("HOST_STARTED", pid=self.proc.pid)
        hello = self.recv(READ_TIMEOUT)
        if not hello or hello.get("hello") != "candidate_host":
            raise RuntimeError("宿主握手失败: %r" % hello)
        if hello.get("error"):
            raise RuntimeError("宿主初始化失败: %r" % hello)
        self.mech_origin = hello.get("mechanism", "?")
        self.lifecycle = hello.get("lifecycle", "?")
        self.log("HOST_HELLO", mechanism=self.mech_origin,
                 lifecycle=self.lifecycle)
        return self

    def _read_loop(self):
        for line in self.proc.stdout:
            self._q.put(line.rstrip("\n"))
        self._q.put(None)

    def log(self, kind, **kw):
        self.events.append({"kind": kind, "t": time.time(), **kw})

    def send(self, obj):
        self.proc.stdin.write(json.dumps(obj, ensure_ascii=True) + "\n")
        self.proc.stdin.flush()

    def recv(self, timeout=READ_TIMEOUT):
        try:
            line = self._q.get(timeout=timeout)
        except queue.Empty:
            return {"error": "TIMEOUT"}
        if line is None:
            err = ""
            if self.proc.poll() is not None:
                try:
                    err = self.proc.stderr.read()[-600:]
                except Exception:
                    pass
            return {"error": "HOST_EXITED", "code": self.proc.poll(),
                    "stderr_tail": err}
        if len(line) > MAX_FRAME:
            return {"error": "OVERSIZED_FRAME", "len": len(line)}
        try:
            return json.loads(line)
        except json.JSONDecodeError as e:
            return {"error": "BAD_JSON", "detail": str(e)[:200],
                    "line_head": line[:260]}

    def request(self, obj, timeout=READ_TIMEOUT):
        """发送命令并等待回包；期间到达的 gateway_generate 帧即时分派
        （同步代理：模型结果在候选 run_turn 返回之前交给候选）。"""
        self.send(obj)
        deadline = time.time() + timeout
        while True:
            remain = max(1.0, deadline - time.time())
            r = self.recv(remain)
            if isinstance(r, dict) and r.get("op") == "gateway_generate":
                ok, body = self._proxy.generate(r.get("req") or {})
                self.send({"op": "gateway_generate_result",
                           "req_id": r.get("req_id"),
                           "ok": ok, "body": body,
                           "error": None if ok else body.get("error")})
                continue
            return r

    # ---------- 生命周期（可信侧编排，评分权威在此） ----------
    def run_episode(self, episode_path, stop_after=None, resume=False,
                    require_assets=True):
        """镜像 arena/lb_runner.run_episode 的轮次编排；评分/产物/账本全在
        可信侧完成（候选只见消毒后的 ctx）。require_assets=False 仅限
        非生产夹具（攻击矩阵），生产路径一律 fail-fast。"""
        with open(episode_path, encoding="utf-8") as f:
            ep = json.load(f)
        cand_dir = os.path.join(ROOT, "candidates", self.candidate)
        # integrity 先算（deny 之后控制器自己也读不了题面文件）
        integrity_pre = lb_runner.integrity_manifest(episode_path, cand_dir)
        # gold 保护：题面（含 gold）加载进内存后立即对源文件 deny——
        # 候选宿主进程从此读不到原文件；还原在 close()（含异常路径）。
        self.deny_files([episode_path])
        if require_assets:
            lb_runner.require_candidate_assets(cand_dir)
        mech, origin, version = lb_runner.load_mechanism(cand_dir)
        contract = lb_runner.load_contract(cand_dir)
        ep_meta = {k: v for k, v in ep.items() if k in lb_runner.EP_META_VISIBLE_KEYS}
        os.makedirs(self.out_dir, exist_ok=True)

        # init（或恢复）
        if resume and os.path.isfile(os.path.join(self.out_dir, "checkpoint.bin")):
            start_idx = self._resume_from_checkpoint()
        else:
            start_idx = 0
            r = self.request({"op": "init", "ep_meta": ep_meta})
            if r.get("error"):
                raise RuntimeError("宿主 init 失败: %r" % r)
            self.log("INIT_DONE", version=r.get("version"),
                     mechanism=r.get("mechanism"))

        proxy = TrustedProxy(self.control_dir, self.run_id, self.candidate,
                             ep.get("episode_id", ""), self.quota,
                             adapter_name=self.adapter, run_id=self.run_id)
        self._proxy = proxy
        turns_manifest = []
        for i in range(start_idx):
            td = _turn_dir(self.out_dir, i, ep["turns"][i])
            with open(os.path.join(td, "manifest.json"), encoding="utf-8") as f:
                turns_manifest.append(json.load(f))

        ran = 0
        for i in range(start_idx, len(ep["turns"])):
            if stop_after is not None and (i + 1) > stop_after:
                break
            turn = ep["turns"][i]
            turn_eval = copy.deepcopy(turn)     # 候选从未接触的原题快照
            lb_runner.validate_media_mapping(turn.get("input") or {},
                                             turn.get("case_id", ""))
            ctx = lb_runner.sanitize_turn(turn)
            ctx["assets_root"] = os.path.join(
                self.staged_root, "candidates", self.candidate, "assets")
            ctx["sandbox"] = os.path.join(self.staged_root, "sandbox")
            ctx["turn_type"] = turn.get("turn_type", "reply")
            ctx["turn_index"] = i + 1
            proxy.set_directive(lb_runner._turn_directive(turn_eval))
            proxy._backend.set_run_context(self.run_id,
                                           turn.get("case_id", ""))
            td = _turn_dir(self.out_dir, i, turn)
            t0 = time.time()
            err = None
            try:
                r = self.request({"op": "turn", "ctx": ctx})
            except Exception as e:
                r = {"error": "IPC_FAIL", "detail": str(e)[:300]}
            latency_ms = int((time.time() - t0) * 1000)
            self._dump_calls(td, proxy)
            if r.get("error"):
                err = "%s: %s | frame=%s" % (r["error"],
                                             str(r.get("detail", ""))[:200],
                                             str(r)[:400])
                _w(td, "error.json", json.dumps(
                    {"case_id": turn.get("case_id"), "turn_index": i + 1,
                     "error": err,
                     "adapter": proxy.adapter_name,
                     "ts": datetime.datetime.now().strftime(
                         "%Y-%m-%d %H:%M:%S")},
                    ensure_ascii=False, indent=2))
                self.log("TURN_ERROR", turn=i + 1, error=err)
                raise RuntimeError("第 %d 轮执行失败: %s" % (i + 1, err))
            reply_raw = r.get("reply_raw", "")
            # ---------- 评分权威（可信侧，原题快照 + 独立 id_map） ----------
            id_map = lb_runner.canonical_id_map(
                (turn_eval.get("input") or {}).get("messages"))
            scoring = lb_scorer.run_case_scoring_safe(turn_eval, reply_raw,
                                                      id_map, contract)
            usage = proxy.turn_usage()
            manifest = {
                "case_id": turn.get("case_id"),
                "turn_type": turn.get("turn_type", "reply"),
                "candidate": self.candidate,
                "adapter": proxy.adapter_name,
                "model": os.environ.get("LB_MODEL", "") or "mock",
                "lifecycle": self.lifecycle, "mechanism": self.mech_origin,
                "contract": contract or "legacy",
                "run_id": self.run_id, "runner_pid": os.getpid(),
                "audit_errors": proxy.audit_errors,
                "clock_injected": (turn.get("input") or {}).get("clock"),
                "media_refs": lb_runner._collect_images(
                    turn.get("input") or {}),
                "tokens": usage,
                "gateway_calls": usage.get("n_calls", 0),
                "latency_ms": latency_ms,
                "score10": scoring["score10"], "veto": scoring["veto"],
                "mechanism_error": r.get("mech_error"),
                "ts": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "prompt_chars": {
                    "prompt_sum": usage.get("prompt"),
                    "reply_sum": usage.get("completion")},
                "isolated": True,
            }
            _w(td, "reply_raw.txt", reply_raw)
            _w(td, "scoring.json", json.dumps(scoring, ensure_ascii=False,
                                              indent=2))
            _w(td, "manifest.json", json.dumps(manifest, ensure_ascii=False,
                                               indent=2))
            if r.get("notes"):
                _w(td, "mechanism_notes.txt", str(r["notes"]))
            turns_manifest.append(manifest)
            ran += 1
            self.log("TURN_DONE", turn=i + 1, score10=manifest["score10"],
                     veto=manifest["veto"])
            # checkpoint（可信侧保存；宿主仅按需回传快照字节）
            snap = self.request({"op": "snapshot"})
            if snap.get("ok"):
                snap_b = _b64decode(snap["snapshot_b64"])
                _wb(self.out_dir, "checkpoint.bin", snap_b)
                _w(self.out_dir, "checkpoint.json", json.dumps(
                    {"turns_done": i + 1,
                     "episode_id": ep.get("episode_id"),
                     "candidate": self.candidate, "lifecycle": self.lifecycle,
                     "ts": datetime.datetime.now().strftime(
                         "%Y-%m-%d %H:%M:%S")},
                    ensure_ascii=False, indent=2))

        ep_manifest = {
            "episode_id": ep.get("episode_id"),
            "candidate": self.candidate,
            "adapter": proxy.adapter_name, "mechanism": self.mech_origin,
            "lifecycle": self.lifecycle, "contract": contract or "legacy",
            "run_id": self.run_id, "runner_pid": os.getpid(),
            "turns": len(turns_manifest),
            "turns_total": len(ep["turns"]),
            "complete": len(turns_manifest) == len(ep["turns"]),
            "resumed_from": start_idx if start_idx else None,
            "mean_score10": round(sum(m["score10"] for m in turns_manifest)
                                  / len(turns_manifest), 2)
            if turns_manifest else 0.0,
            "veto_turns": sum(1 for m in turns_manifest if m["veto"]),
            "first_pass_rate": round(
                sum(1 for m in turns_manifest if not m["veto"])
                / len(turns_manifest), 4) if turns_manifest else 0.0,
            "tokens_total": {
                "prompt": sum((m["tokens"].get("prompt") or 0)
                              for m in turns_manifest),
                "completion": sum((m["tokens"].get("completion") or 0)
                                  for m in turns_manifest)},
            "latency_ms_p95": max([m["latency_ms"] for m in turns_manifest],
                                  default=0),
            "integrity": integrity_pre,
            "isolated": True,
            "ts": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }
        _w(self.out_dir, "episode_manifest.json",
           json.dumps(ep_manifest, ensure_ascii=False, indent=2))
        self.flush_proxy(proxy)
        return ep_manifest, proxy

    def _resume_from_checkpoint(self):
        with open(os.path.join(self.out_dir, "checkpoint.json"),
                  encoding="utf-8") as f:
            ck = json.load(f)
        start_idx = int(ck["turns_done"])
        snap = open(os.path.join(self.out_dir, "checkpoint.bin"), "rb").read()
        r = self.request({"op": "restore",
                          "snapshot_b64": _b64encode(snap)})
        if r.get("error"):
            raise RuntimeError("宿主 restore 失败: %r" % r)
        self.log("RESTORED", resumed_from=start_idx)
        return start_idx

    def _dump_calls(self, td, proxy):
        _w(td, "calls.json", json.dumps(proxy.backend_calls(),
                                        ensure_ascii=False, indent=2))

    # ---------- 账本 ----------
    def flush_proxy(self, proxy):
        ledger = {"run_dir": os.path.basename(self.run_dir),
                  "candidate": self.candidate,
                  "controller_events": self.events,
                  "proxy": proxy.ledger(),
                  "staged_hashes": self.staged}
        blob = json.dumps(ledger, ensure_ascii=False, sort_keys=True)
        p = os.path.join(self.control_dir, "ledger.json")
        open(p, "w", encoding="utf-8").write(blob)
        side = hashlib.sha256(blob.encode("utf-8")).hexdigest()
        open(p + ".sha256", "w").write(side + "\n")
        return {"ledger": p, "sidecar_sha256": side}

    # ---------- 受保护文件 deny（A1/A2 隔离的文件层闭环） ----------
    def deny_files(self, paths):
        """对受保护文件拒绝读取内容（Windows ACL，文件级）。
        纪律一：只对文件用——目录级 deny 曾造成锁死事故，禁用。
        纪律二：deny 掩码必须是 (RD)（仅拒文件数据读取），绝不能用 (R)——
        (R) 含 READ_CONTROL，会把 icacls 自己也锁死（无法 /reset，
        2026-10-21 事故实证）。还原走 undeny_files()/close()。"""
        for p in paths:
            p = os.path.abspath(p)
            if not os.path.isfile(p):
                continue
            # icacls 输出为系统 ANSI（GBK），不用 text=True 读
            r = subprocess.run(["icacls", p, "/deny", "*S-1-1-0:(RD)"],
                               capture_output=True)
            if r.returncode == 0:
                self._denied.append(p)
                self.log("FILE_DENY", path=os.path.relpath(p, ROOT))
            else:
                self.log("FILE_DENY_FAIL", path=p,
                         err=(r.stderr or r.stdout or b"").decode(
                             "utf-8", "replace")[:120])
        return self

    def undeny_files(self):
        for p in list(self._denied):
            try:
                r = subprocess.run(["icacls", p, "/reset"],
                                   capture_output=True)
                self.log("FILE_UNDENY", path=os.path.relpath(p, ROOT),
                         rc=r.returncode)
            except Exception as e:
                self.log("FILE_UNDENY_FAIL", path=p, err=str(e)[:120])
        self._denied.clear()

    def close(self):
        self.undeny_files()
        if self.proc and self.proc.poll() is None:
            try:
                self.proc.stdin.close()
                self.proc.wait(timeout=8)
            except Exception:
                self.proc.kill()
        self.log("HOST_CLOSED", code=self.proc.poll() if self.proc else None)


def _b64encode(b):
    import base64
    return base64.b64encode(b).decode()


def _b64decode(s):
    import base64
    return base64.b64decode(s)


def _turn_dir(out_dir, i, turn):
    return os.path.join(out_dir, "turn_%02d_%s"
                        % (i + 1, turn.get("case_id", "case")))


def _w(out_dir, name, content):
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, name), "w", encoding="utf-8",
              newline="") as f:
        f.write(content)


def _wb(out_dir, name, content):
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, name), "wb") as f:
        f.write(content)
