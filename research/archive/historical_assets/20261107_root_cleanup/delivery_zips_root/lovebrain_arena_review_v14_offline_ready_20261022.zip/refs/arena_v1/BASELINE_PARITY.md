# BASELINE_PARITY — 冻结原产品主链路参考基线（工作包 B / G04）

日期：2026-10-21。原则：基线保真 = **与原产品相符**，不是基线通过全部能力题；
不为对拍添加原产品没有的能力；原产品本来不检索长期档案，如实保留。

## 1. 冻结来源版本（sha256，2026-10-21 实算）

参照：`D:/LoveBrain`（Kotlin/Android 工作树）。被测主链路组件：

| 原文件 | sha256 |
|---|---|
| domain/prompt/ChatTranscriptBlock.kt | `f8397740…d14e` |
| domain/prompt/IntentIdeaBlock.kt | `ed27e023…92e` |
| domain/prompt/CurrentSceneInjection.kt | `2f342778…2ab2` |
| domain/MemoryCorrectionPolicy.kt | `6cfc2711…1adf` |
| data/KnowledgeMemoryStore.kt | `07cfa07e…4423` |
| domain/OngoingContextSelector.kt | `ac642635…69d6` |
| domain/PromptBuilder.kt | `b08b2a08…e19` |
| model/Models.kt | `3b3f48a9…319` |
| AppConfig.kt | `b865c790…43e5` |
| test/.../MemoryCorrectionPolicyTest.kt（预期来源） | `a4bb5dc2…d146` |
| test/.../OngoingContextSelectorTest.kt（预期来源） | `e0be2c45…7871e` |

参考移植与夹具：

| 文件 | sha256 |
|---|---|
| candidates/reference_product_v1/reference_chain.py | `5ee21efd…1737` |
| tools/test_baseline_parity.py | `a5460b1a…1422` |

## 2. 实现方式（§4-B2）

- 原实现为 Kotlin/Android，本环境无构建运行条件 → 采用 **Python 参考移植**，
  逐函数引用原文件+行号；预期值来自**原仓库源码逐字常量与自带单元测试**
  （MemoryCorrectionPolicyTest、OngoingContextSelectorTest、PromptByteFreezeBaselineTest）。
- 模型输出环节用固定原文替身，无采样噪声混入机制对拍。
- 未顺手替原产品修 bug：发现的差异只登记（见 §4），不改原语义。

## 3. 对拍结果（tools/test_baseline_parity.py，26 夹具 / 9 多轮）

| 能力（§4-B3） | 夹具 | 结果 |
|---|---|---|
| 静态资产与动态装配 | B-T01/T02/T03（T03 多轮长会话掐尾） | PASS |
| 意图/备注/阶段开关 | B-T04/T05（有效性四态、军师备注逐字） | PASS |
| HER/ME/IDEA 与来源 | B-T01（IDEA 不占号不冒充来源） | PASS |
| 场景判定（优先级/主体） | B-T06/T07/T08/T09 | PASS |
| 四种纠正 + revision 单调 | B-T10~T14（T12/T13/T14 多步/恢复） | PASS |
| ongoing（冷却/休眠/完成取消/词表） | B-T15~T25（T17/T19/T21/T24/T25 多轮） | PASS |
| 时效与常量边界 | B-T26（2h/2 条/60 条/3 轮/5 轮） | PASS |
| 重复提交/异常与恢复 | B-T14（写失败不写 revision+坏 JSON） | PASS |
| 图片和输出解析 | B-T02（JSON 转义防注入；图片出站属 E11 真实集成验证范围） | PASS |

执行：`python tools/test_baseline_parity.py` → `BASELINE PARITY PASS: 26 fixtures (9 multi-turn)`。
证据清单：`refs/arena_v1/baseline_parity_fixtures.json`。

## 4. 题库接口适配登记（§4-B2）

| 原形（原产品） | 适配后（考场题面） | 理由 | 双方可见条件 |
|---|---|---|---|
| intent = `moment/intent.json`（IntentConfig，enabled/status） | 题面 `input.intent = {text, enabled, status}` 直接映射 | 同一颗 isIntentEffective 判据 | 双方同源同判 |
| may_decline 不存在于原产品（无"允许不回"概念） | 题面 `input.may_decline` 轮级许可 | 考场协议能力；基线不消费此字段 | 仅候选契约消费；基线对比不计该维度 |
| IDEA = 本轮用户想法（replyDirective） | 题面 IDEA 消息行 | 同义映射 | 双方均不进围栏/不占编号 |
| 时钟 = 系统时钟（TimeFmt） | 题面固定 clock 字段 | 确定性对拍需注入固定时钟（B2 允许并记录） | 双方一致 |

适配新增能力（may_decline 等）**不**归为候选或产品的已证明优势（§4-B2）。

## 5. 差异与排除声明

1. **图片实际出站**：原产品经 Android 层发送；本环境无法真发 → 图片出站归 G11
   真实集成验证，本轮以媒体登记/散列单向流验证（test_input_boundary 已覆盖）。
2. **后台引擎**（谈心/主动开场）不在 B1 范围，未删除任何影响比较的逻辑。
3. Kotlin 单元测试未在本机执行（无 Gradle/SDK）——预期值转写自测试文件与源码逐字
   常量；若需构建级对拍，属外部缺件（见 SCOPE_AND_STATUS §6）。
4. 考场侧 infer_scene（arena/lb_assembly.py）的 Wave15/16 修复属**候选侧共同工程**，
   与参考基线（原产品语义）的差异是设计使然，不构成基线失真。
