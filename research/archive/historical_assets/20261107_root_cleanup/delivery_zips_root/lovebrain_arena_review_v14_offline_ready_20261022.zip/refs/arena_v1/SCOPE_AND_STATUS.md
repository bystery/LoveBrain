# ARENA V1 收口 · 范围与真实状态（SCOPE_AND_STATUS）

日期：2026-10-21（R3 收口后按实测重写；旧版 OFFLINE_READY 自评已被
独立复核推翻，本版为其重写账）。依据：`refs/ARENA_V1_CLOSEOUT_GUIDE_20261021.md`
与 `refs/ARENA_V1_INDEPENDENT_REVIEW_20261021.md`。
**本文件是执行方案的状态账，不是验收通过书。** 每项状态只随实际证据更新；
最终判定以 `logs/arena_v1_acceptance/<run_id>/ACCEPTANCE.json` 为准。

## 0. 本轮主线

ARENA_V1_CLOSEOUT：建成一个可审计、比较公平、人工监督裁决质量的考场。
phase1/2/3 候选保留为**被测对象**；其成绩不决定考场设施是否建成。
52 次父子对照单列，另行授权，不计入本轮工程验收。

## 1. 角色/边界（§1.1）

| 内容 | 侧 | 本轮处理 |
|---|---|---|
| runner / 调用代理 / 输入白名单 / 客观评分 / 审计 / 隔离 / 统计展示 | 考场设施 | 修复并验收（G02/G03/G08/G09） |
| 冻结原产品主链路参考基线 | 比较基准 | 补齐保真对拍（G04），不训练成更强产品 |
| 题库 / 划分 / 评分依据 / 人工审查协议 | 测量体系 | 建立并冻结有明确范围的版本（G05/G06a） |
| phase1/2/3 检索、纠正、表达、记忆 | 被测候选 | 保留现状 + Wave17 修复版本与其测试 |
| 52 次对照 / 下一代 / 冠军替换 | 候选研发 | 单独登记，不在本轮 |

## 2. 版本冻结（release.json 摘要）

- 仓库：`D:/lovebrain-arena`；评审模式：`human_supervised`；Judge：禁用（未校准）。
- 散列登记：`refs/arena_v1/release.json`（由 `tools/freeze_release.py` 生成，
  与 `tools/build_release_package.py` 打包白名单**同源**；R3#7 后为 221 文件级清单）。
- 参照产品：`D:/LoveBrain`（Kotlin/Android；主链路 = PromptBuilder + MemoryCorrectionPolicy
  + OngoingContextSelector/OngoingPlanStore + KnowledgeMemoryStore + GenerationEngine）。
  冻结散列见 `refs/arena_v1/BASELINE_PARITY.md`。
- 历史：`round_0_baseline`、旧 66 实跑（`logs/l3b_66_real66_v1/`）与各轮日志**只读保留**。

## 3. 已验证基础设施（历史证据，不自动预填 PASS）

- 66 实跑账本/唯一 run_id/严格 attempt 配对；52 槽执行器额度守卫/停批/不可恢复。
- 输入白名单、原题快照评分权威、伪造 id_map 不可影响评分（test_scoring_authority，
  R3#3 后为五类篡改×逐项全量比对）。
- no_reply 三分协议、嵌套结构校验、失败持久化、恢复事件（既有 15 套测试）。
- 上述在新隔离架构下已重走对应路径（矩阵 A5/A7/A8 + R3 守卫自测）。

## 4. 门禁状态账（G01–G11，§7-E2）

> 状态口径：OFFLINE_READY = G01–G05、G06a、G07–G10 全 PASS；
> ENGINEERING_READY = + G11；ARENA_V1_READY_HUMAN = 再 + G06b。
> 下表登记 **2026-10-21 22:25 实测**（`logs/arena_v1_acceptance/20261021_r3closeout_v7/ACCEPTANCE.json`，
> **总状态 OFFLINE_READY，EXIT=0**；干净目录完整 offline 复验同轮通过）。

| ID | 门禁 | 状态 | 证据（v7 实测） |
|---|---|---|---|
| G01 | 范围/版本/依赖/权限模式冻结 | **PASS** | release.json（freeze_release 223 文件，路径全部相对）逐文件 sha256 核对 0 漂移 |
| G02 | IO/动作/类型/扩展契约一致 | **PASS** | CONTRACT_MATRIX 16/16 + 协议等价 rc=0（攻击夹具豁免已审定：A4 探针故意 import lb_scorer） |
| G03 | 评分权威/伪造隔离 | **PASS** | test_scoring_authority 五类篡改×逐项全量比对（16 检查点条目）+ 矩阵 A5 isolated_forge_ignored=True |
| G04 | 冻结产品主链路公平基线 | **PASS** | BASELINE_PARITY 26 夹具（9 多轮）FAIL: none |
| G05 | 自然题面与覆盖可验收 | **PASS** | coverage 12 族 36 点 0 缺失 + 字段审计 0 issue（含 R3#5 时钟单调/message.image） |
| G06a | 划分/暴露/封存接口 | **PASS** | split_manifest 27 随包文件对账 0 bad（4 条 logs/ 历史证据标 unshipped 仅溯源）+ seal 完整性 + R3#6 访问控制实测 |
| G06b | 独立选择内容与保管 | **NOT_READY**（外部缺件） | 需用户指定保管身份或批准最小方案 |
| G07 | 人工评审闭环 | **PASS** | rv2 材料内容绑定+去重+分母分离；12 材料 11 收 1 拒，0 漂移 |
| G08 | 实际运行隔离 | **PASS** | 矩阵 18 必要检查全 PASS（文件级 deny；A1/A2 隔离旁路已修；A6a socket 残差白名单登记） |
| G09 | 可信代理/额度/失败/恢复 | **PASS** | A7/A8 子集全 PASS + 账本 sidecar |
| G10 | 可复现发布与历史保护 | **PASS** | 发布包 224 文件 0 违例 0 缺件 + **干净目录同一完整 offline 入口复验**（嵌套 G01-G10 全 PASS，G10 嵌套用 light 冒烟防递归） |
| G11 | 集成入口 | **REFUSED/NOT_RUN**（离线模式） | 本地替身完整演练 PASS（test_g11_standin：model/温度/图片/usage 三件套/9000 字符不截断/账本 7+7）；真实上游批次待批 |

### v7 收口过程中发现并修复的三个真实缺陷（教训）

1. **freeze_release 绝对路径 bug**：release.json 首版混入 184 条绝对路径——干净目录
   里 G01 会审计到本机原文件而非包内容（假通过）。已修复为强制相对化。
2. **split_manifest 混入 logs/ 历史证据**：4 条 logs/ 文件登记进对账集，干净目录必
   MISSING。已加家族级 `unshipped_files`（仅溯源，不强制随包）。
3. **沙箱批量删除守卫**：矩阵清理 staged 残骸（55 项）触发
   SAFE_DELETE_BULK_CONFIRM_REQUIRED → verify 内矩阵假败。验收须在非沙箱环境执行
   （icacls ACL 操作同理）；已让 verify 在 G08 失败时记录子工具输出尾部以便诊断。
4. **打包复验递归**：干净目录完整 offline 入口里的 G10 再触发完整打包→无限嵌套。
   已加 ARENA_UNPACK_CONTEXT/ARENA_SMOKE_MODE 边界（嵌套层 G10 用 light 冒烟）。

## 5. R3 收口实际修复（对照独立复核六大缺陷）

| 复核缺陷 | 修复与证据 |
|---|---|
| ①真实链路未接通 | R1 三件套重写；_dbg8 mock 全绿（mean 7.43）；_dbg9_real 真实端到端 PASS（mean 8.0，5 attempt） |
| ②评分占位 | lb_scorer v0.2+ 十检查点+二 veto；test_scoring_authority 升级逐项全量比对 |
| ③隔离旁路 | 矩阵重写暴露 A1/A2 VIOLATION_READ_OK → 文件级 deny（(RD) 掩码）修复；18 检查全绿 |
| ④总验收误报 | verify_arena_v1 严格证据绑定（R3#1）+ 7 反例负例自测（R3#2） |
| ⑤评审统计不可靠 | review_loop rv2：内容绑定/重复替代/分母分离（R3#4）+ 6 反例守卫自测 |
| ⑥发布包不完整 | 补 9 测试文件+可重建说明+干净目录完整 offline 入口复验（R3#7）+ freeze_release 同源冻结 |

## 6. 已知阻塞与外部缺件（持续更新）

1. **G06b 独立出题/保管身份**：需用户指定保管身份或接受最小执行方案后冻结。
2. **G08 纵深残差（非必要路径）**：候选进程原始 socket 可达本地任意端口；
   必要不变量（不产生未登记真实请求）已由上游密钥门禁实测保证；
   管理员防火墙规则为纵深防御最小权限需求。
3. **ACL 残石清理**：`_ACL_LOCKED_LEDGER.json` 161 条记录/146 条当前存在，
   只清点不删；管理员善后单独准备、逐目标验证最终绝对路径+副本+散列+退出码。
   （教训：icacls 目录级 deny 曾锁死题库；现行为文件级 (RD)，绝不用 (R)。）
4. **G11 真实上游批次**：本地替身演练已 PASS；≤8 attempts 真实批次待用户批准。
5. **G10 干净目录复验耗时**：完整 offline 入口含嵌套发布，单次复验约 10 分钟级，
   属预期成本，不是缺陷。

## 7. 完工状态口径（§1.3）

判定规则见验收模板 `refs/ARENA_V1_ACCEPTANCE_TEMPLATE_20261021.json`。
G06b 未具备时报告首页必须写明"独立选择未就绪"。AUTO_JUDGE_READY /
PROMOTION_AUTHORIZED / MONSTER_VALIDATED 本轮均为 false，不可从上表推导。
