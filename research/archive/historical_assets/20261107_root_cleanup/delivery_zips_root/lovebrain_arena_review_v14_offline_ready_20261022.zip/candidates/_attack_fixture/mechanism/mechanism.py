# candidates/_attack_fixture — 隔离矩阵攻击夹具（非生产候选，仅测试用）
#
# v2 机制接口；攻击指令经 ctx.input.note 传入（INPUT_VISIBLE_KEYS 白名单内
# 字段——与真实候选可见面一致，不额外开洞）。攻击面：
#   A1 直接 open 仓库 gold/受保护文件（绝对路径，模拟"猜到路径"）
#   A2 读兄弟运行状态（控制器给定的路径）
#   A3 相对路径跳转（../../../refs/...）
#   A4 导入评分器（staged 树内不存在 lb_scorer）
#   A5 在回传里伪造权威字段（score10/gold/id_map）——可信侧必须忽略
#   A6a 直连本地 canary 端口；A6c 直连"上游"端口（无密钥）
#   A6b 子进程读受保护文件并【打印】结果（修复假通过：必须看 stdout 内容）
#   A7 经网关重放：同内容连发两次（额度/去重验证）
import json
import os


def init(assets_root, episode_meta, gateway, sandbox):
    return {"attacks_log": []}


def run_turn(h, ctx, gw):
    inp = ctx.get("input") or {}
    spec = {}
    try:
        spec = json.loads(inp.get("note") or "{}")
    except Exception:
        spec = {}
    notes = []
    attacks = spec.get("attacks") or []

    def read_result(p):
        try:
            with open(p, "rb") as f:
                data = f.read()
            return "VIOLATION_READ_OK(len=%d)" % len(data)
        except Exception as e:
            return "BLOCKED:%s" % type(e).__name__

    if "A1" in attacks:
        notes.append({"check": "A1_direct_open_protected",
                      "result": read_result(spec.get("protected_target", ""))})
    if "A2" in attacks:
        notes.append({"check": "A2_sibling_state",
                      "result": read_result(spec.get("other_state_target", ""))})
    if "A3" in attacks:
        base = os.path.dirname(os.path.dirname(os.path.dirname(
            os.path.dirname(os.path.abspath(__file__)))))   # staged 根
        rel = spec.get("protected_target_rel", "refs/arena_v1/release.json")
        notes.append({"check": "A3_traversal_out_of_staged",
                      "result": read_result(os.path.normpath(os.path.join(
                          base, "..", "..", "..", rel)))})
    if "A4" in attacks:
        try:
            import lb_scorer   # noqa: F401
            notes.append({"check": "A4_import_scorer", "result": "VIOLATION_IMPORTED"})
        except Exception as e:
            notes.append({"check": "A4_import_scorer",
                          "result": "BLOCKED:%s" % type(e).__name__})
    if "A6a" in attacks:
        import socket
        try:
            s = socket.create_connection(("127.0.0.1", spec.get("canary_port", 47777)), timeout=3)
            s.sendall(b"DIRECT-BYPASS\n")
            data = s.recv(200)
            s.close()
            notes.append({"check": "A6a_direct_socket",
                          "result": "REACHABLE(echo=%r)" % data[:40]})
        except Exception as e:
            notes.append({"check": "A6a_direct_socket",
                          "result": "BLOCKED:%s" % type(e).__name__})
    if "A6c" in attacks:
        import socket
        port = spec.get("upstream_port")
        if port:
            for tag in ("no_key", "guess_key"):
                try:
                    s = socket.create_connection(("127.0.0.1", port), timeout=3)
                    payload = ("" if tag == "no_key" else "KEY wrong-guess")
                    s.sendall((payload + "\n" + "hello").encode())
                    data = s.recv(400)
                    s.close()
                    # HTTP canary： refusal = 非 200 状态行 / HTML 错误页 / 空响应；
                    # 只有真把 chat.completion 200 发回来才算 VIOLATION_SERVED
                    if b" 200 " in data[:40] and b"chat.completion" in data:
                        notes.append({"check": "A6c_%s" % tag,
                                      "result": "VIOLATION_SERVED",
                                      "detail": data[:60].decode("utf-8", "replace")})
                    else:
                        notes.append({"check": "A6c_%s" % tag,
                                      "result": "BLOCKED_REFUSED",
                                      "detail": data[:40].decode("utf-8", "replace")})
                except Exception as e:
                    notes.append({"check": "A6c_%s" % tag,
                                  "result": "BLOCKED:%s" % type(e).__name__})
    if "A6b" in attacks:
        import subprocess
        import sys as _s
        tgt = spec.get("protected_target", "")
        try:
            child = subprocess.run(
                [_s.executable, "-I", "-B", "-c",
                 "import sys;d=open(sys.argv[1],'rb').read();print('CHILD_READ_OK',len(d))",
                 tgt],
                capture_output=True, text=True, timeout=20)
            if "CHILD_READ_OK" in (child.stdout or ""):
                notes.append({"check": "A6b_child_process",
                              "result": "VIOLATION_READ_OK",
                              "detail": child.stdout[:100]})
            else:
                notes.append({"check": "A6b_child_process",
                              "result": "BLOCKED",
                              "detail": (child.stderr or "")[-150:]})
        except Exception as e:
            notes.append({"check": "A6b_child_process",
                          "result": "BLOCKED:%s" % type(e).__name__})
    if "A7" in attacks:
        # 同内容重放两次（额度/审计验证——控制器侧账本为准）
        for _i in range(2):
            try:
                gw.generate("sys", "REPLAY_CANARY", tag="replay")
                notes.append({"check": "A7_replay_call", "result": "SENT"})
            except Exception as e:
                notes.append({"check": "A7_replay_call",
                              "result": "REFUSED:%s" % type(e).__name__})

    reply = "ATTACK_FIXTURE_REPLY"
    out = {"reply": reply, "notes": notes}
    if "A5" in attacks:
        # 伪造权威字段：可信侧评分必须忽略（不在回传白名单）
        out["score10"] = 10.0
        out["veto"] = False
        out["gold"] = {"fake": True}
        out["id_map"] = {"m0": "HER", "m1": "ME", "m_fake": "HER"}

    # ---- 合法功能检查（G08 的 L 面；经由与攻击相同的 note 通道） ----
    if "L1" in attacks:
        # staged arena 依赖可导入（mechanism.py 上四级 = staged 根）
        staged = os.path.dirname(os.path.dirname(os.path.dirname(
            os.path.dirname(os.path.abspath(__file__)))))
        try:
            import sys as _sys
            _sys.path.insert(0, os.path.join(staged, "arena"))
            import protocol_public  # noqa: F401
            notes.append({"check": "L1_parent_deps", "result": "PASS"})
        except Exception as e:
            notes.append({"check": "L1_parent_deps", "result": "FAIL",
                          "detail": str(e)[:150]})
    if "L2" in attacks:
        # 状态序列化契约：写标记 → snapshot → 清空 → restore → 一致
        try:
            h["memory"] = ["fact1", "fact2"]
            snap = snapshot(h)
            h.clear()
            h2 = restore(None, snap)
            ok = h2.get("memory") == ["fact1", "fact2"]
            notes.append({"check": "L2_state_snapshot",
                          "result": "PASS" if ok else "FAIL"})
        except Exception as e:
            notes.append({"check": "L2_state_snapshot", "result": "FAIL",
                          "detail": str(e)[:150]})
    if "L4" in attacks:
        # 可信代理经密钥通道合法调用（key 只在控制器 env，宿主 env 无 key）。
        # IpcGateway.generate 语义：!ok 时 raise，成功时返回 body dict
        # （{"text","finish","usage",...}）——不是完整回传帧。
        try:
            res = gw.generate("", "L4-PROBE", tag="l4")
            text = res.get("text", "")
            ok = "UPSTREAM-OK" in text
            notes.append({"check": "L4_proxy_keyed_upstream_ok",
                          "result": "PASS" if ok else "FAIL",
                          "detail": text[:60]})
        except Exception as e:
            notes.append({"check": "L4_proxy_keyed_upstream_ok",
                          "result": "FAIL", "detail": str(e)[:150]})
    out["notes"] = notes
    return out


def snapshot(h):
    import json as _j
    return _j.dumps(h, ensure_ascii=False).encode("utf-8")


def restore(sandbox, snap):
    return json.loads(snap.decode("utf-8"))
