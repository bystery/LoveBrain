# ARENA V1 验收报告（20261021_r3closeout_FINAL）

模式：offline ｜ 生成时间：2026-10-21T22:29:28

> **独立选择未就绪（G06b）**：独立出题/保管身份未指定，不得简称“完整考场建成”。

总状态：**OFFLINE_READY**

| 门禁 | 状态 | 说明 |
|---|---|---|
| G01 | PASS | release.json 逐文件散列核对 |
| G02 | PASS | contract 16/16 (rc1=0) protocol_equiv rc=0 |
| G03 | PASS | authority rc=0（评分与原题权威评分逐项全量比对）；isolated_forge_ignored=True |
| G04 | PASS | rc=0 tail=ti-turn 9) / FAIL: none ==
BASELINE PARITY PASS: 26 fixtures (9 multi-turn), all expectations from frozen Kotl |
| G05 | PASS | coverage_matrix: families=12 points=36 missing=0 field_issues=0 |
| G06a | PASS | seal rc=0; manifest files=27 bad=0 |
| G06b | NOT_READY | 独立出题/保管身份未指定（外部缺件）——不阻塞离线工程门禁，报告首页如实写明 |
| G07 | PASS | materials=12 bad=0 accepted=11 rejected=1 |
| G08 | PASS | 固定预期集合 17 项逐项终态核验；残差仅白名单 ['A6a_direct_socket'] |
| G09 | PASS | A7/A8 checks=5 all_pass={'note': 'proxy ledger in runs/_atk_network/out/_control'} ledger_sidecar=yes |
| G10 | PASS | PACKAGE PASS pkg=dist\arena_v1_pkg\20261021_222856 unpack_verify=OK files=224 missing=0 violations=0 smoke=full_offline  |

口径：OFFLINE_READY = G01-G05、G06a、G07-G10 全 PASS；ENGINEERING_READY = + G11；ARENA_V1_READY_HUMAN = 再 + G06b。
Judge 自动裁判未启用；真实 B 线未开启；52 次候选对照另列未授权。