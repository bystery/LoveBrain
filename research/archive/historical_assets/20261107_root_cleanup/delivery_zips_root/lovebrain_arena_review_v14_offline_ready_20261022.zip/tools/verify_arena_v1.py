# -*- coding: utf-8 -*-
"""verify_arena_v1.py — ARENA V1 考场总验收入口（指导书 §7-E1）。

只组织确定性检查、固定回放和经明确授权的集成测试：
不选择变异、不训练、不自动开新批次绕预算。

用法：
  python -B -X utf8 tools/verify_arena_v1.py --mode offline \
      --release refs/arena_v1/release.json --out logs/arena_v1_acceptance/<run_id>

模式：
  offline      默认。禁用真实上游适配器；隔离矩阵走密钥门禁本地替身上游；
               全部检查在确定性环境中执行。
  integration  只验证新隔离路径下的真实调用。无授权记录
               （refs/arena_v1/AUTHORIZATION_INTEGRATION.json authorized=true）
               时拒绝运行。

退出码：0 = 必要门禁集合（G01-G05、G06a、G07-G10）全 PASS；
        非 0 = 存在 FAIL/NOT_RUN（G06b 外部缺件不影响 offline 判定）。
状态口径（验收模板 §readiness_rules）：
  OFFLINE_READY = G01-G05、G06a、G07-G10 全 PASS；
  ENGINEERING_READY = + G11；ARENA_V1_READY_HUMAN = 再 + G06b。
"""
import argparse
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REQUIRED_OFFLINE = ["G01", "G02", "G03", "G04", "G05", "G06a", "G07", "G08", "G09", "G10"]
AUTH_FILE = os.path.join(ROOT, "refs", "arena_v1", "AUTHORIZATION_INTEGRATION.json")

# R3#1：固定预期测试集合（独立复核 §4——"证据必须属于本次 run、相同 release、
# 明确的预期测试集合"）。矩阵日志必须覆盖全部 ID；终态只允许 PASS/FAIL/
# RESIDUAL_DOCUMENTED；REQUIRED_PASS 必须逐项 PASS；RESIDUAL 仅允许白名单。
MATRIX_EXPECTED_PASS = {
    "L1_parent_deps", "L2_state_snapshot", "L4_proxy_keyed_upstream_ok",
    "A1_direct_open_protected", "A2_sibling_state",
    "A3_traversal_out_of_staged", "A4_import_scorer",
    "A5_forge_authority_ignored", "A6b_child_process",
    "A6c_no_key", "A6c_guess_key",
    "A6c_upstream_ledger_zero_unkeyed_served",
    "A7_quota_ledger_unique",
    "A8a_host_crash_error_path", "A8b_oversized_frame_error_path",
    "A8c_dead_host_no_silent_regen", "A8d_bad_json_error_path",
}
# 2026-10-21 矩阵随新隔离架构重写（旧 ID 集含 L3/A3a-c/A5a-b/A6c_env_key_absent
# 已废弃：L3 由 coverage 的 message.image 承担；env key 白名单为宿主 env 结构保证）
MATRIX_RESIDUAL_ALLOWED = {"A6a_direct_socket"}  # 任意本地 socket 残差（已登记）


def sha_file(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def run_tool(cmd, timeout=600, env=None):
    """cwd=ROOT 跑子工具，返回 (exit_code, stdout_tail)。"""
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True,
                       encoding="utf-8", errors="replace", timeout=timeout,
                       env=env)
    out = (r.stdout or "") + (("\n[stderr] " + r.stderr[-400:]) if r.stderr.strip() else "")
    return r.returncode, out.strip()


class Verify:
    def __init__(self, mode, release_path, out_dir):
        self.mode = mode
        self.release_path = os.path.join(ROOT, release_path) if not os.path.isabs(release_path) else release_path
        self.out = out_dir
        os.makedirs(self.out, exist_ok=True)
        self.gates = {}
        self.run_started = time.time()      # R3#1：证据时间锚（本次 run 起点）
        self.matrix_log_rel = None          # R3#1：本次 run 实际产出的矩阵日志

    def record(self, gid, status, evidence, command=None, observed=None, note=None):
        self.gates[gid] = {"id": gid, "status": status, "evidence": evidence,
                           "executed_command": command, "observed_result": observed,
                           "note": note}
        print("  [%s] %s %s" % (status, gid, (note or observed or "")[:110]))

    # ---------- G01 范围/版本/依赖冻结 ----------
    def g01_release_audit(self):
        rel = json.load(open(self.release_path, encoding="utf-8"))
        bad, missing = [], []
        files = rel.get("files", {})
        # R3#1 反例③：files={} 是空发布证明，不是 PASS
        if not files:
            self.record("G01", "FAIL",
                        [os.path.relpath(self.release_path, ROOT)],
                        observed="files=0（空 release 清单不得放行）",
                        note="release.json 无 files 或 files 为空")
            return False
        for f, meta in files.items():
            p = os.path.join(ROOT, f)
            if not os.path.isfile(p):
                missing.append(f)
                continue
            want = meta["sha256"] if isinstance(meta, dict) else meta
            if sha_file(p) != want:
                bad.append(f)
        ok = not bad and not missing
        self.record("G01", "PASS" if ok else "FAIL",
                    [os.path.relpath(self.release_path, ROOT)],
                    observed="files=%d missing=%d mismatch=%d"
                             % (len(rel.get("files", {})), len(missing), len(bad)),
                    note="release.json 逐文件散列核对"
                         + ("；漂移=%s" % (bad + missing)[:3] if (bad or missing) else ""))
        return ok

    # ---------- G02 契约矩阵 + 协议等价 ----------
    def g02_contract(self):
        rc1, out1 = run_tool([sys.executable, "-B", "-X", "utf8",
                              "tools/gen_contract_matrix.py"])
        m = re.search(r"CONTRACT_MATRIX\.md: (\d+)/(\d+) PASS", out1)
        n, total = (int(m.group(1)), int(m.group(2))) if m else (0, 0)
        rc2, out2 = run_tool([sys.executable, "-B", "-X", "utf8",
                              "tools/test_protocol_public.py"])
        ok = rc1 == 0 and rc2 == 0 and n == total and total >= 16
        self.record("G02", "PASS" if ok else "FAIL",
                    ["refs/arena_v1/CONTRACT_MATRIX.md"],
                    command="gen_contract_matrix + test_protocol_public",
                    observed="contract %d/%d (rc1=%d) protocol_equiv rc=%d"
                             % (n, total, rc1, rc2))
        return ok

    # ---------- G03 评分权威/原题快照/伪造隔离 ----------
    def g03_scoring(self):
        rc, out = run_tool([sys.executable, "-B", "-X", "utf8",
                            "tools/test_scoring_authority.py"], timeout=300)
        auth_ok = rc == 0 and "SCORING AUTHORITY PASS" in out
        # 新隔离路径下的伪造字段隔离（共享矩阵结果的 A4 判定）
        a4 = self._matrix_a4()
        ok = auth_ok and a4
        self.record("G03", "PASS" if ok else "FAIL",
                    ["tools/test_scoring_authority.py",
                     "logs/isolation_matrix_*.json"],
                    command="test_scoring_authority + isolation A4",
                    observed="authority rc=%d（评分与原题权威评分逐项全量比对）；"
                             "isolated_forge_ignored=%s" % (rc, a4))
        return ok

    def _matrix_a4(self):
        """R3#1 反例⑤：A4 证据必须来自本次 run 的矩阵日志（g08 先行产出），
        禁止读取历史日志的旧标记。"""
        rel = self.matrix_log_rel
        if not rel:
            return False
        p = os.path.join(ROOT, rel)
        if not os.path.isfile(p) or os.path.getmtime(p) < self.run_started:
            return False
        res = json.load(open(p, encoding="utf-8"))
        vs = res.get("verdicts", [])
        if not vs:
            return False
        return any(v.get("check") == "A5_forge_authority_ignored"
                   and v.get("verdict") == "PASS" for v in vs)

    # ---------- G04 基线对拍 ----------
    def g04_baseline(self):
        rc, out = run_tool([sys.executable, "-B", "-X", "utf8",
                            "tools/test_baseline_parity.py"], timeout=300)
        ok = rc == 0 and "BASELINE PARITY PASS" in out and "FAIL: none" in out
        self.record("G04", "PASS" if ok else "FAIL",
                    ["refs/arena_v1/BASELINE_PARITY.md"],
                    command="test_baseline_parity",
                    observed="rc=%d tail=%s" % (rc, out[-120:]))
        return ok

    # ---------- G05 覆盖矩阵 ----------
    def g05_coverage(self):
        rc, out = run_tool([sys.executable, "-B", "-X", "utf8",
                            "tools/gen_coverage_matrix.py"], timeout=300)
        m = re.search(r"families=(\d+) points=(\d+) missing=(\d+) field_issues=(\d+)", out)
        ok = rc == 0 and m and m.group(3) == "0" and m.group(4) == "0"
        self.record("G05", "PASS" if ok else "FAIL",
                    ["benchmark/releases/arena_v1/coverage_matrix.json"],
                    command="gen_coverage_matrix",
                    observed=out.splitlines()[0][:140] if out else "no output")
        return ok

    # ---------- G06a 划分/封存接口 ----------
    def g06a_split_seal(self):
        rc, out = run_tool([sys.executable, "-B", "-X", "utf8",
                            "tools/verify_seal_fixture.py"])
        # split_manifest 散列对账（只强制随包交付文件；unshipped_files=
        # 历史溯源登记如 logs/ 证据，不进发布包——R3 收口口径）
        mf = os.path.join(ROOT, "benchmark/releases/arena_v1/split_manifest.json")
        m = json.load(open(mf, encoding="utf-8"))
        ref = {f: h for fam in m.get("families", [])
               for f, h in fam.get("files", {}).items()
               if h != "MISSING"
               and f not in set(fam.get("unshipped_files") or [])}
        # R3#1 反例②同类：空 manifest 不是通过证明
        if not ref:
            self.record("G06a", "FAIL",
                        ["benchmark/releases/arena_v1/split_manifest.json"],
                        command="verify_seal_fixture + manifest hash audit",
                        observed="manifest files=0（空划分清单不得放行）")
            return False
        bad = [f for f, h in ref.items()
               if not os.path.isfile(os.path.join(ROOT, f))
               or sha_file(os.path.join(ROOT, f)) != h]
        ok = rc == 0 and not bad
        self.record("G06a", "PASS" if ok else "FAIL",
                    ["benchmark/releases/arena_v1/split_manifest.json"],
                    command="verify_seal_fixture + manifest hash audit",
                    observed="seal rc=%d; manifest files=%d bad=%d"
                             % (rc, len(ref), len(bad)))
        return ok

    # ---------- G06b 独立选择（外部缺件，如实报告） ----------
    def g06b_selection(self):
        mf = os.path.join(ROOT, "benchmark/releases/arena_v1/split_manifest.json")
        m = json.load(open(mf, encoding="utf-8"))
        sel = m.get("selection_set", {}) or {}
        status = sel.get("status", "NOT_READY")
        # R3#1 反例④：只填 status=READY 而无实际内容/保管与独立性证据 → 不得就绪
        has_content = bool(sel.get("case_refs") or sel.get("files")
                           or sel.get("families"))
        has_custody = bool(sel.get("custodian")) and bool(sel.get("independent"))
        if status == "READY" and not (has_content and has_custody):
            status = "NOT_READY"
        self.record("G06b", "NOT_READY" if status != "READY" else "PASS",
                    [os.path.relpath(mf, ROOT)],
                    observed="selection_set.status=%s content=%s custody=%s"
                             % (sel.get("status"), has_content, has_custody),
                    note="独立出题/保管身份未指定（外部缺件）——"
                         "不阻塞离线工程门禁，报告首页如实写明"
                         if status != "READY" else None)
        return status == "READY"

    # ---------- G07 评审闭环 ----------
    def g07_review_loop(self):
        W = os.path.join(ROOT, "benchmark/releases/arena_v1/review_loop")
        try:
            mp = json.load(open(os.path.join(W, "mapping_secret.json"),
                                encoding="utf-8"))
            ing = json.load(open(os.path.join(W, "ingest_result.json"),
                                 encoding="utf-8"))
            spec = json.load(open(os.path.join(
                ROOT, "refs/arena_v1/review_drill_spec.json"),
                encoding="utf-8"))
        except Exception as e:
            self.record("G07", "FAIL", [], observed="missing artifacts: %s" % e)
            return False

        def sha16(o):
            return hashlib.sha256(json.dumps(
                o, ensure_ascii=False, sort_keys=True).encode("utf-8")
            ).hexdigest()[:16]

        def load_case(ref):
            if ":" not in ref:   # 独立 case 文件（如 SMOKE_NOTE_TRAP_001）
                pth = os.path.join(ROOT, "benchmark/cases", ref + ".json")
                return json.load(open(pth, encoding="utf-8")) \
                    if os.path.isfile(pth) else None
            eid, cid = ref.rsplit(":", 1)
            for sub in ("", "dev/", "archive/"):
                pth = os.path.join(ROOT, "benchmark/episodes", sub,
                                   eid + ".json")
                if os.path.isfile(pth):
                    ep = json.load(open(pth, encoding="utf-8"))
                    for t in ep.get("turns", []):
                        if t.get("case_id") == cid:
                            return t
            return None

        # R3#4：material_version 以映射文件（gen 时落盘）为准，spec 仅为回退
        ver = mp.get("material_version") or spec.get("material_version", "rv1")
        bad = []
        mapping = mp.get("mapping", {})
        for idx, m in enumerate(spec.get("materials", []), 1):
            mid = "MAT_%02d" % idx
            c = load_case(m["case_ref"])
            if c is None:
                bad.append(mid + ":case_missing")
                continue
            binding = sha16({"case_ref": m["case_ref"],
                             "case_sha": sha16(c),
                             "arms": m["arm_x"]["reply"] + "|"
                                     + m["arm_y"]["reply"],
                             "material_version": ver})
            if binding != mapping.get(mid, {}).get("binding_sha256_16"):
                bad.append(mid + ":binding_drift")
            matp = os.path.join(W, "materials", mid + ".json")
            if not os.path.isfile(matp):
                bad.append(mid + ":material_missing")
            else:
                mat = json.load(open(matp, encoding="utf-8"))
                if mat.get("binding_sha256_16") != mapping.get(mid, {}).get(
                        "binding_sha256_16"):
                    bad.append(mid + ":material_binding_mismatch")
        acc = len(ing.get("accepted", []))
        rej = len(ing.get("rejected", []))
        ok = not bad and acc >= 11 and rej >= 1
        self.record("G07", "PASS" if ok else "FAIL",
                    ["refs/arena_v1/C_PACKAGE_REPORT_20261021.md"],
                    command="binding recompute from live cases + ingest audit",
                    observed="materials=%d bad=%s accepted=%d rejected=%d"
                             % (len(mapping), bad or 0, acc, rej))
        return ok

    # ---------- G08/G09 隔离矩阵（一次运行，两门禁共享；R3#1 严格证据绑定） ----------
    def g08_g09_matrix(self):
        rc, out = run_tool([sys.executable, "-B", "-X", "utf8",
                            "tools/test_isolation_matrix.py"], timeout=900)
        # R3#1 反例①：子工具 rc≠0 立即本门失败，不读任何日志；
        # 观察值附子工具输出尾部（可诊断性——矩阵 rc=1 必须能看到死在哪）
        if rc != 0:
            tail = (out or "")[-400:].replace("\n", " | ")
            self.record("G08", "FAIL", [],
                        command="test_isolation_matrix",
                        observed="subtool rc=%d — 子工具失败立即失败；tail=%s"
                                 % (rc, tail))
            self.record("G09", "FAIL", [],
                        command="test_isolation_matrix",
                        observed="subtool rc=%d — 子工具失败立即失败" % rc)
            return False
        # 证据绑定：只认子工具本次 stdout 声明的日志，且 mtime ≥ 本次 run 起点
        mm = re.search(r"ISOLATION MATRIX -> (\S+)", out)
        if not mm:
            self.record("G08", "FAIL", [], command="test_isolation_matrix",
                        observed="stdout 未声明矩阵日志路径")
            self.record("G09", "FAIL", [], command="test_isolation_matrix",
                        observed="stdout 未声明矩阵日志路径")
            return False
        rel = mm.group(1).replace("\\", "/")
        p = os.path.join(ROOT, rel)
        if not os.path.isfile(p):
            self.record("G08", "FAIL", [], observed="declared log missing: %s" % rel)
            self.record("G09", "FAIL", [], observed="declared log missing: %s" % rel)
            return False
        if os.path.getmtime(p) < self.run_started:
            self.record("G08", "FAIL", [rel], command="test_isolation_matrix",
                        observed="日志 mtime 早于本次验收起点（旧证据不得放行）")
            self.record("G09", "FAIL", [rel], command="test_isolation_matrix",
                        observed="日志 mtime 早于本次验收起点（旧证据不得放行）")
            return False
        self.matrix_log_rel = rel
        res = json.load(open(p, encoding="utf-8"))
        vs = res.get("verdicts", [])
        # R3#1 反例②：空 verdicts / 缺必要集合 / 非终态不得放行
        if not vs:
            self.record("G08", "FAIL", [rel], command="test_isolation_matrix",
                        observed="verdicts=[]（空检查结果不得放行）")
            self.record("G09", "FAIL", [rel], command="test_isolation_matrix",
                        observed="verdicts=[]（空检查结果不得放行）")
            return False
        by_id = {}
        nonterminal = []
        for v in vs:
            vd = v.get("verdict")
            if vd not in ("PASS", "FAIL", "RESIDUAL_DOCUMENTED"):
                nonterminal.append("%s:%s" % (v.get("check"), vd))
            by_id[v.get("check")] = vd
        missing = MATRIX_EXPECTED_PASS - set(by_id)
        fails = [c for c in MATRIX_EXPECTED_PASS if by_id.get(c) == "FAIL"]
        bad_residual = [c for c, vd in by_id.items()
                        if vd == "RESIDUAL_DOCUMENTED"
                        and c not in MATRIX_RESIDUAL_ALLOWED]
        up = res.get("upstream_ledger", {}) or {}
        ledger_att = res.get("ledger_attacker")
        g08_ok = not missing and not fails and not nonterminal and not bad_residual
        self.record("G08", "PASS" if g08_ok else "FAIL",
                    [rel, "refs/arena_v1/ISOLATION.md"],
                    command="test_isolation_matrix",
                    observed="checks=%d expected=%d missing=%s fail=%s "
                             "nonterminal=%s bad_residual=%s；upstream "
                             "attempts=%d unkeyed_refused=%d"
                             % (len(vs), len(MATRIX_EXPECTED_PASS),
                                sorted(missing)[:3] or "none",
                                fails or "none", nonterminal or "none",
                                bad_residual or "none",
                                up.get("attempts", 0),
                                up.get("unkeyed_refused", 0)),
                    note="固定预期集合 %d 项逐项终态核验；残差仅白名单 %s"
                         % (len(MATRIX_EXPECTED_PASS),
                            sorted(MATRIX_RESIDUAL_ALLOWED)))
        # G09：代理重放/超额/账本唯一 attempt + 崩溃/坏 IPC 错误路径
        g9_ids = [c for c in by_id if c.startswith(("A7", "A8"))]
        g09_ok = (g9_ids and all(by_id[c] == "PASS" for c in g9_ids)
                  and isinstance(ledger_att, dict) and ledger_att)
        self.record("G09", "PASS" if g09_ok else "FAIL",
                    [rel],
                    command="test_isolation_matrix (A7/A8 subset)",
                    observed="A7/A8 checks=%d all_pass=%s ledger_sidecar=%s"
                             % (len(g9_ids), g09_ok,
                                "yes" if isinstance(ledger_att, dict) and ledger_att
                                else "empty/missing"))
        return g08_ok and g09_ok

    # ---------- G10 可复现发布与历史保护 ----------
    def g10_release_package(self):
        # R3#7 后：干净目录复验 = 完整 offline 入口（含嵌套矩阵+嵌套打包），
        # 600s 不够——放宽到 2400s。
        # 递归边界（R3 收口）：unpack 冒烟里跑的 verify 自身再调 G10 时，
        # 其打包冒烟降为 light（protocol+import），防止 verify→build→verify→build 无限嵌套。
        env = None
        if os.environ.get("ARENA_UNPACK_CONTEXT"):
            env = dict(os.environ, ARENA_SMOKE_MODE="light")
        rc, out = run_tool([sys.executable, "-B", "-X", "utf8",
                            "tools/build_release_package.py"], timeout=2400,
                           env=env)
        m = re.search(r"PACKAGE (PASS|FAIL) pkg=(\S+) unpack_verify=(\w+)", out)
        if rc == 0 and m and m.group(1) == "PASS" and m.group(3) == "OK":
            self.record("G10", "PASS", [m.group(2)],
                        command="build_release_package + clean-dir offline smoke",
                        observed=out.splitlines()[0][:140])
            return True
        self.record("G10", "FAIL", [], command="build_release_package",
                    observed=(out or "no output")[-200:])
        return False

    # ---------- 主流程 ----------
    def run_offline(self):
        print("ARENA V1 OFFLINE VERIFY — %s" % datetime.datetime.now().isoformat())
        print("mode=offline（真实上游适配器禁用；隔离矩阵走本地替身上游）")
        # 意外真实访问检测：若环境注入了真实端点则拒绝
        for ev in ("LOVEBRAIN_UPSTREAM", "OPENAI_API_KEY", "ANTHROPIC_API_KEY"):
            if os.environ.get(ev):
                self.record("G01", "FAIL", [],
                            observed="env %s present — 拒绝在含真实端点的环境离线验证" % ev)
                return False
        # R3#1：矩阵先跑——G03 的 A4 证据必须取自本次 run 的矩阵日志（反例⑤）
        self.g08_g09_matrix()
        self.g01_release_audit()
        self.g02_contract()
        self.g03_scoring()
        self.g04_baseline()
        self.g05_coverage()
        self.g06a_split_seal()
        self.g06b_selection()
        self.g07_review_loop()
        # G10 最后：打包并干净目录复验
        self.g10_release_package()
        return self.finalize()

    def run_integration(self):
        print("ARENA V1 INTEGRATION VERIFY — %s" % datetime.datetime.now().isoformat())
        if not os.path.isfile(AUTH_FILE):
            self.record("G11", "REFUSED", [],
                        observed="无授权记录 %s" % os.path.relpath(AUTH_FILE, ROOT),
                        note="integration 模式需要明确授权记录（authorized=true），"
                             "当前拒绝运行。真实集成只申请一次小额度（≤8 attempts）。")
            self.finalize()
            return 2
        auth = json.load(open(AUTH_FILE, encoding="utf-8"))
        if not auth.get("authorized"):
            self.record("G11", "REFUSED", [os.path.relpath(AUTH_FILE, ROOT)],
                        observed="authorized=false")
            self.finalize()
            return 2
        # R3#8：授权在位 → 先跑本地替身完整演练（真实 OpenAI 兼容 HTTP）；
        # 未执行任何演练时 G11 不得记 PASS，本模式不得 exit=0。
        rc, out = run_tool([sys.executable, "-B", "-X", "utf8",
                            "tools/test_g11_standin.py"], timeout=1200)
        drill_ok = rc == 0 and "G11 STANDIN PASS" in out
        # 真实上游批次：仅在授权清单同时冻结端点并获用户单独批准时执行
        real = auth.get("real_endpoint") or {}
        real_note = ("真实上游批次待批（授权清单 real_endpoint.authorized 缺失）"
                     if not real.get("authorized") else
                     "真实上游批次按授权清单另行执行（≤8 attempts）")
        self.record("G11", "PASS" if drill_ok else "FAIL",
                    ["logs/g11_standin_result.json"],
                    command="test_g11_standin（本地 OpenAI 兼容替身完整演练）",
                    observed="standin rc=%d（model/温度/图片/usage/不截断/账本）；%s"
                             % (rc, real_note),
                    note=None if drill_ok else (out[-300:] or "drill failed"))
        self.finalize()
        return 0 if drill_ok else 1

    def finalize(self):
        # 总状态判定（验收模板口径）
        offline_all = all(self.gates.get(g, {}).get("status") == "PASS"
                          for g in REQUIRED_OFFLINE)
        g11 = self.gates.get("G11", {}).get("status")
        g06b = self.gates.get("G06b", {}).get("status")
        if offline_all and g11 == "PASS" and g06b == "PASS":
            overall = "ARENA_V1_READY_HUMAN"
        elif offline_all and g11 == "PASS":
            overall = "ENGINEERING_READY"
        elif offline_all:
            overall = "OFFLINE_READY"
        else:
            overall = "NOT_READY"
        acceptance = {
            "document_type": "arena_v1_acceptance",
            "is_template": False,
            "run_id": os.path.basename(self.out),
            "generated_at": datetime.datetime.now().isoformat(),
            "mode": self.mode,
            "overall_status": overall,
            "evaluation_mode": "human_supervised",
            "separate_flags": {"AUTO_JUDGE_READY": False,
                               "PROMOTION_AUTHORIZED": False,
                               "MONSTER_VALIDATED": False},
            "gates": [self.gates[k] for k in sorted(self.gates)],
        }
        p = os.path.join(self.out, "ACCEPTANCE.json")
        json.dump(acceptance, open(p, "w", encoding="utf-8"),
                  ensure_ascii=False, indent=1)
        self.write_report(overall)
        print("OVERALL: %s -> %s" % (overall, os.path.relpath(self.out, ROOT)))
        # 退出码：必要门禁集合全 PASS 才 0
        ok = all(self.gates.get(g, {}).get("status") == "PASS"
                 for g in REQUIRED_OFFLINE)
        return 0 if ok else 1

    def write_report(self, overall):
        lines = ["# ARENA V1 验收报告（%s）" % os.path.basename(self.out), ""]
        lines.append("模式：%s ｜ 生成时间：%s" % (
            self.mode, datetime.datetime.now().isoformat(timespec="seconds")))
        lines.append("")
        if overall in ("OFFLINE_READY",) or (
                overall in ("NOT_READY",) and
                self.gates.get("G06b", {}).get("status") != "PASS"):
            lines.append("> **独立选择未就绪（G06b）**：独立出题/保管身份未指定，"
                         "不得简称“完整考场建成”。")
            lines.append("")
        lines.append("总状态：**%s**" % overall)
        lines.append("")
        lines.append("| 门禁 | 状态 | 说明 |")
        lines.append("|---|---|---|")
        for k in sorted(self.gates):
            g = self.gates[k]
            lines.append("| %s | %s | %s |" % (
                k, g["status"], (g.get("note") or g.get("observed_result") or "")
                .replace("|", "/")[:120]))
        lines.append("")
        lines.append("口径：OFFLINE_READY = G01-G05、G06a、G07-G10 全 PASS；"
                     "ENGINEERING_READY = + G11；ARENA_V1_READY_HUMAN = 再 + G06b。")
        lines.append("Judge 自动裁判未启用；真实 B 线未开启；52 次候选对照另列未授权。")
        open(os.path.join(self.out, "ACCEPTANCE_REPORT.md"), "w",
             encoding="utf-8").write("\n".join(lines))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["offline", "integration"], default="offline")
    ap.add_argument("--release", default="refs/arena_v1/release.json")
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    out = a.out or os.path.join(
        ROOT, "logs", "arena_v1_acceptance",
        datetime.datetime.now().strftime("%Y%m%d_%H%M%S"))
    v = Verify(a.mode, a.release, out)
    if a.mode == "integration":
        return v.run_integration()
    return v.run_offline()


if __name__ == "__main__":
    sys.exit(main())
