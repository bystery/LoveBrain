# -*- coding: utf-8 -*-
"""iso_run.py — 隔离运行 CLI（同一命令，仅切换 --candidate）。

python tools/iso_run.py --episode benchmark/episodes/X.json \
    --candidate phase3_facts --out runs/iso_x \
    [--adapter mock] [--quota N] [--stop-after N] [--resume]

复用 arena/isolation/trusted_controller.IsolatedRun：真实候选按参数加载、
同步代理生成、可信侧评分、attempt 账本落盘。
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__))), "arena"))
from isolation.trusted_controller import IsolatedRun  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--episode", required=True)
    ap.add_argument("--candidate", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--adapter", default="mock")
    ap.add_argument("--quota", type=int, default=8)
    ap.add_argument("--stop-after", type=int, default=None)
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--run-dir", default=None,
                    help="staging 目录（默认 out 的兄弟 _run）")
    ap.add_argument("--require-assets", default="1")
    args = ap.parse_args()

    ep = os.path.join(ROOT, args.episode) if not os.path.isabs(args.episode) \
        else args.episode
    out = args.out if os.path.isabs(args.out) else os.path.join(ROOT, args.out)
    run_dir = args.run_dir or os.path.join(
        os.path.dirname(out.rstrip("\\/")) or ROOT,
        "_iso_run_" + os.path.basename(out.rstrip("\\/")))
    control = os.path.join(out, "_control")

    run = IsolatedRun(run_dir, out, control, args.candidate,
                      adapter=args.adapter, quota=args.quota).stage()
    try:
        run.start()
        m, proxy = run.run_episode(
            ep, stop_after=args.stop_after, resume=args.resume,
            require_assets=args.require_assets == "1")
        print(json.dumps({"episode_id": m["episode_id"], "turns": m["turns"],
                          "complete": m["complete"],
                          "mean_score10": m["mean_score10"],
                          "veto_turns": m["veto_turns"],
                          "mechanism": m["mechanism"],
                          "lifecycle": m["lifecycle"],
                          "adapter": m["adapter"],
                          "run_id": m["run_id"]}, ensure_ascii=False))
        return 0
    finally:
        run.close()


if __name__ == "__main__":
    sys.exit(main())
