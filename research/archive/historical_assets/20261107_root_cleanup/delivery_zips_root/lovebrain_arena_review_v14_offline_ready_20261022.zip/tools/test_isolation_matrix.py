# -*- coding: utf-8 -*-
"""test_isolation_matrix.py — G08/G09 攻击与合法功能矩阵（新隔离架构版）。

被测体 = candidates/_attack_fixture（v2 机制接口；攻击指令经 ctx.input.note
白名单通道传入，与真实候选可见面一致，不额外开洞）。
全部使用合成 canary；不碰真实B线/用户 dataset。判定不查 prompt 字符串——
本矩阵全部真实执行（独立进程 + 实际 IPC + 实际代理账本 + 实际上游桩）。

检查面：
  L1 父依赖导入 / L2 状态快照契约 / L4 密钥代理合法调用
  A1 直读受保护题面 / A2 兄弟状态 / A3 路径跳出 staged
  A4 导入评分器 / A5 伪造权威字段被可信侧忽略
  A6a 直连 socket（残差，如实登记）/ A6b 子进程读 / A6c 无密钥/猜密钥被拒
      + env key 白名单 / A7 重放调用 + 额度强制 + 账本唯一
  A8a-d 宿主错误路径（崩溃/超大帧/死宿主/坏 JSON——直接进程探针）
  L3（允许媒体出站）由 coverage 矩阵 message.image 检查承担（R3#5），不在此重复。

输出：logs/isolation_matrix_<ts>.json（verify_arena_v1 只认 stdout 声明的
该文件且 mtime ≥ 验收起点）。
"""
import datetime
import json
import os
import socket
import subprocess
import sys
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "arena"))
from isolation.trusted_controller import IsolatedRun  # noqa: E402

OUT_LOG = os.path.join(ROOT, "logs", "isolation_matrix_%s.json"
                       % datetime.datetime.now().strftime("%Y%m%d_%H%M%S"))
EP_TARGET = os.path.join(ROOT, "benchmark", "episodes",
                         "NCA_CORR_INTENT_v1.json")   # 含 gold 的真实题面（只作靶路径）
UPSTREAM_KEY = "CORRECT-KEY-42"


# ---------- canary 上游：HTTP /v1/chat/completions + 密钥门禁 ----------
class _Gate(BaseHTTPRequestHandler):
    hits = {"served": 0, "unkeyed": 0, "guessed": 0}

    def log_message(self, *a):
        pass

    def do_POST(self):
        auth = self.headers.get("Authorization", "")
        body = b"{}"
        if auth == "Bearer " + UPSTREAM_KEY:
            _Gate.hits["served"] += 1
            body = json.dumps({
                "id": "canary", "object": "chat.completion", "model": "canary",
                "choices": [{"index": 0, "finish_reason": "stop",
                             "message": {"role": "assistant",
                                         "content": "UPSTREAM-OK canary"}}],
                "usage": {"prompt_tokens": 5, "completion_tokens": 2,
                          "total_tokens": 7}}).encode()
            code = 200
        else:
            _Gate.hits["unkeyed" if "wrong" not in auth else "guessed"] += 1
            body = b'{"error": "unauthorized"}'
            code = 401
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


class KeyGateUpstream(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self.httpd = HTTPServer(("127.0.0.1", 0), _Gate)
        self.port = self.httpd.server_address[1]

    def run(self):
        self.httpd.serve_forever()


class RawEchoCanary(threading.Thread):
    """A6a 靶：任意本地 socket 可达性（残差登记用）。"""
    def __init__(self):
        super().__init__(daemon=True)
        self.srv = socket.socket()
        self.srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.srv.bind(("127.0.0.1", 0))
        self.port = self.srv.getsockname()[1]
        self.srv.listen(4)

    def run(self):
        while True:
            try:
                c, _ = self.srv.accept()
                data = c.recv(200)
                c.sendall(b"CANARY-ECHO:" + data[:40])
                c.close()
            except OSError:
                return


# ---------- 攻击 episode（临时构造，note 携带攻击台本） ----------
def make_episode(path, turns_spec):
    turns = []
    for i, (clock, spec) in enumerate(turns_spec, 1):
        turns.append({
            "case_id": "ATK_t%02d" % i,
            "input": {"clock": clock, "type": "reply",
                      "may_decline": False,
                      "messages": [{"role": "HER",
                                    "text": "第%d轮测试消息" % i}],
                      "note": json.dumps(spec, ensure_ascii=False)},
            "gold": {}})
    ep = {"episode_id": "ATK_MATRIX_v1", "hero": "测试者",
          "relation_stage": "破冰", "persona": "攻击矩阵合成人设",
          "turns": turns}
    json.dump(ep, open(path, "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)


def run_fixture(out_name, turns_spec, adapter="mock", quota=4, env_extra=None,
                deny_targets=None):
    """stage→deny→start→run_episode（require_assets=False 仅限攻击夹具）→close。
    run_dir = base（IsolatedRun 自己在下面建 staged/，不能传 base/staged
    否则双重嵌套）。"""
    # 目录名带 v2：旧 _atk_legit 里有一个被过宽 deny 掩码锁死的残留文件
    #（2026-10-21 事故，只 deny 了 (R) 连 READ_CONTROL 也锁死、无法在线还原；
    # 控制器已改 (RD) 掩码根治，此处改名绕开毒路径）
    base = os.path.join(ROOT, "runs", "_atk2_" + out_name)
    out = os.path.join(base, "out")
    ep_path = os.path.join(base, "atk_episode.json")
    os.makedirs(base, exist_ok=True)
    make_episode(ep_path, turns_spec)
    old_env = {}
    for k, v in (env_extra or {}).items():
        old_env[k] = os.environ.get(k)
        os.environ[k] = v
    try:
        run = IsolatedRun(base, out,
                          os.path.join(out, "_control"), "_attack_fixture",
                          adapter=adapter, quota=quota).stage()
        if deny_targets:
            run.deny_files(deny_targets)
        try:
            run.start()
            manifest, proxy = run.run_episode(ep_path, require_assets=False)
            return {"manifest": manifest, "proxy_ledger": proxy.ledger(),
                    "out": out, "staged_root": run.staged_root}
        finally:
            run.close()
    finally:
        for k, v in old_env.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


def judge(notes, check, expect, extra=None):
    """result 与 expect 任一前缀匹配即 PASS（BLOCKED:* 家族归一）。"""
    n = next((x for x in notes if x.get("check") == check), None)
    if n is None:
        return {"check": check, "expect": list(expect),
                "actual": "NOT_FOUND", "verdict": "FAIL"}
    actual = str(n.get("result", ""))
    verdict = "PASS" if any(actual.startswith(e) for e in expect) else "FAIL"
    rec = {"check": check, "expect": list(expect), "actual": actual,
           "detail": str(n.get("detail", ""))[:160], "verdict": verdict}
    if extra:
        rec.update(extra)
    return rec


# ---------- A8：宿主错误路径（直接进程探针，不经控制器） ----------
def a8_error_paths(staged_root, verdicts):
    host_script = os.path.join(staged_root, "_candidate_host.py")
    if not os.path.isfile(host_script):
        for c in ("A8a_host_crash_error_path", "A8b_oversized_frame_error_path",
                  "A8c_dead_host_no_silent_regen", "A8d_bad_json_error_path"):
            verdicts.append({"check": c, "actual": "STAGED_HOST_MISSING",
                             "verdict": "FAIL"})
        return
    env = {"SYSTEMROOT": os.environ.get("SYSTEMROOT", ""),
           "PATH": os.environ.get("PATH", "")}

    def _spawn():
        # 宿主入口需要 --staged-root/--candidate（argparse 强制）
        return subprocess.Popen(
            [sys.executable, "-B", "-X", "utf8", host_script,
             "--staged-root", staged_root, "--candidate", "_attack_fixture"],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, env=env, cwd=staged_root,
            text=True, encoding="utf-8", errors="replace")

    # A8b 超大帧 → OVERSIZED_FRAME 终态
    p = _spawn()
    try:
        big = json.dumps({"op": "x", "pad": "A" * 16_000_001})
        out, err = p.communicate(big + "\n", timeout=60)
        ok_b = "OVERSIZED_FRAME" in (out or "")
        verdicts.append({"check": "A8b_oversized_frame_error_path",
                         "actual": "OVERSIZED_FRAME" if ok_b else "NO_TERMINAL_ERROR",
                         "detail": (err or "")[-150:],
                         "verdict": "PASS" if ok_b else "FAIL"})
    except subprocess.TimeoutExpired:
        p.kill()
        verdicts.append({"check": "A8b_oversized_frame_error_path",
                         "actual": "TIMEOUT", "verdict": "FAIL"})
    # A8d 坏 JSON → 错误终态（进程不静默成功）
    p = _spawn()
    try:
        out, err = p.communicate("THIS IS NOT JSON\n" + "\n", timeout=60)
        ok_d = bool((out or "").strip()) and ("error" in (out or "").lower()
                                              or "BAD_JSON" in (out or "")
                                              or "TRACEBACK" in (err or ""))
        verdicts.append({"check": "A8d_bad_json_error_path",
                         "actual": "ERROR_TERMINAL" if ok_d else "SILENT",
                         "detail": ((out or "")[:120] + "||" + (err or "")[-100:]),
                         "verdict": "PASS" if ok_d else "FAIL"})
    except subprocess.TimeoutExpired:
        p.kill()
        verdicts.append({"check": "A8d_bad_json_error_path",
                         "actual": "TIMEOUT", "verdict": "FAIL"})
    # A8a 宿主崩溃 → 非零退出 + stderr 痕迹（不是静默 0 退出）
    p = subprocess.Popen([sys.executable, "-B", "-X", "utf8", "-c",
                          "import sys;sys.path.insert(0,'%s');"
                          "raise RuntimeError('ATK_CRASH_CANARY')" % staged_root],
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                         env=env, text=True, encoding="utf-8", errors="replace")
    out, err = p.communicate(timeout=60)
    ok_a = p.returncode != 0 and "ATK_CRASH_CANARY" in (err or "")
    verdicts.append({"check": "A8a_host_crash_error_path",
                     "actual": "CRASH_TERMINAL" if ok_a else "SILENT_OR_ZERO",
                     "verdict": "PASS" if ok_a else "FAIL"})
    # A8c 死宿主：起进程即杀，再无任何"静默重生成"通道（进程不复活）
    p = _spawn()
    p.kill()
    p.wait(timeout=30)
    ok_c = p.returncode is not None and p.returncode != 0
    verdicts.append({"check": "A8c_dead_host_no_silent_regen",
                     "actual": "DEAD_NO_REGEN" if ok_c else "STILL_ALIVE",
                     "verdict": "PASS" if ok_c else "FAIL"})


def main():
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    verdicts = []

    canary = RawEchoCanary()
    canary.start()
    upstream = KeyGateUpstream()
    upstream.start()

    try:
        # ============ Pass 1：合法功能（mock 适配器） ============
        r1 = run_fixture("legit", [
            ("2026-10-29 10:00", {"attacks": ["L1", "L2"]})], quota=2)
        notes1 = r1["manifest"].get("_fixture_notes") or _notes_from_out(r1["out"])
        for check in ("L1_parent_deps", "L2_state_snapshot"):
            verdicts.append(judge(notes1, check, ("PASS",)))

        # ============ Pass 2：文件/导入/伪造攻击（mock 适配器） ============
        sib = os.path.join(ROOT, "runs", "_atk_legit", "sibling_state.json")
        os.makedirs(os.path.dirname(sib), exist_ok=True)
        json.dump({"secret": "SIBLING-CANARY-9d1"}, open(sib, "w"))
        r2 = run_fixture("attacker", [
            ("2026-10-29 11:00",
             {"attacks": ["A1", "A2", "A3", "A4", "A5"],
              "protected_target": EP_TARGET,
              "protected_target_rel": "benchmark/episodes/NCA_CORR_INTENT_v1.json",
              "other_state_target": sib})], quota=2,
            deny_targets=[EP_TARGET, sib])
        notes2 = _notes_from_out(r2["out"])
        for check in ("A1_direct_open_protected", "A2_sibling_state",
                      "A3_traversal_out_of_staged", "A4_import_scorer"):
            verdicts.append(judge(notes2, check, ("BLOCKED",)))
        # A4 结果形态：BLOCKED:<Exc> 或 VIOLATION_IMPORTED 之外的终态都算阻断
        a4 = next((v for v in verdicts
                   if v["check"] == "A4_import_scorer"), None)
        if a4 and a4["actual"].startswith("BLOCKED:"):
            a4["verdict"] = "PASS"
        # A5 伪造权威字段：评分仍由可信侧产出且未被伪造值覆盖
        sc_path = os.path.join(r2["out"], "turn_01_ATK_t01", "scoring.json")
        sc = json.load(open(sc_path, encoding="utf-8")) \
            if os.path.isfile(sc_path) else {}
        forged_adopted = (sc.get("score10") == 10.0)
        verdicts.append({
            "check": "A5_forge_authority_ignored",
            "expect": ["scored_by_trusted_side"],
            "actual": "adopted_fake_10" if forged_adopted
                      else "scored_by_trusted_side",
            "verdict": "FAIL" if forged_adopted else "PASS"})

        # ============ Pass 3：网络面 + 额度（mock 适配器；quota=1 使重放越界） ============
        r3 = run_fixture("network", [
            ("2026-10-29 12:00",
             {"attacks": ["A6a", "A6b", "A6c", "A7"],
              "protected_target": EP_TARGET,
              "canary_port": canary.port,
              "upstream_port": upstream.port})], quota=1,
            deny_targets=[EP_TARGET])
        notes3 = _notes_from_out(r3["out"])
        verdicts.append(judge(notes3, "A6a_direct_socket", ("REACHABLE",))
                        | {"verdict": "RESIDUAL_DOCUMENTED",
                           "detail": "任意本地 socket 可达=纵深残差，如实登记"
                                     "（最小权限需求，非必要路径）"})
        verdicts.append(judge(notes3, "A6b_child_process",
                              ("BLOCKED", "BLOCKED:PermissionError")))
        verdicts.append(judge(notes3, "A6c_no_key", ("BLOCKED",)))
        verdicts.append(judge(notes3, "A6c_guess_key", ("BLOCKED",)))
        # 必要不变量：canary 上游零次无密钥服务
        zero_unkeyed = _Gate.hits["unkeyed"] == 0
        verdicts.append({
            "check": "A6c_upstream_ledger_zero_unkeyed_served",
            "expect": ["zero"], "actual": "unkeyed=%d guessed=%d served=%d"
            % (_Gate.hits["unkeyed"], _Gate.hits["guessed"], _Gate.hits["served"]),
            "verdict": "PASS" if zero_unkeyed else "FAIL"})
        # A7：重放调用 + 额度强制 + 账本唯一
        led = r3["proxy_ledger"]
        evs = led.get("events", [])
        quota_ev = [e for e in evs if e.get("kind") == "quota_exceeded"]
        aids = [e.get("attempt_id") for e in evs
                if e.get("kind", "").startswith("attempt")]
        used = led.get("used", 0)
        a7_ok = (used <= led.get("quota", 0) and quota_ev
                 and len(aids) == len(set(aids)))
        verdicts.append({
            "check": "A7_quota_ledger_unique",
            "expect": ["ok<=quota", "quota_enforced", "unique_attempt_ids"],
            "actual": "used=%d quota=%s quota_ev=%d aids=%d/%d"
                      % (used, led.get("quota"), len(quota_ev),
                         len(set(aids)), len(aids)),
            "verdict": "PASS" if a7_ok else "FAIL"})

        # ============ Pass 4：密钥代理合法调用（openai_compat + canary） ============
        r4 = run_fixture("keyed", [
            ("2026-10-29 13:00", {"attacks": ["L4"]})],
            adapter="openai_compat", quota=2,
            env_extra={"LB_API_BASE": "http://127.0.0.1:%d/v1" % upstream.port,
                       "LB_API_KEY": UPSTREAM_KEY,
                       "LB_MODEL": "canary"})
        notes4 = _notes_from_out(r4["out"])
        verdicts.append(judge(notes4, "L4_proxy_keyed_upstream_ok", ("PASS",)))

        # ============ A8：错误路径（直探第一个 staged 树） ============
        a8_error_paths(r1["staged_root"], verdicts)
    finally:
        upstream.httpd.shutdown()

    results = {"date": ts, "root": ROOT, "upstream_ledger": {
        "attempts": _Gate.hits["served"],
        "unkeyed_refused": _Gate.hits["unkeyed"] + _Gate.hits["guessed"]},
        "verdicts": verdicts, "ledger_attacker": {"note": "proxy ledger in runs/_atk_network/out/_control"}}
    os.makedirs(os.path.dirname(OUT_LOG), exist_ok=True)
    json.dump(results, open(OUT_LOG, "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print("ISOLATION MATRIX -> %s" % os.path.relpath(OUT_LOG, ROOT))
    for v in verdicts:
        print("  [%s] %s actual=%s" % (v["verdict"], v["check"],
                                       str(v.get("actual"))[:70]))
    bad = [v["check"] for v in verdicts if v["verdict"] == "FAIL"]
    print("ISOLATION MATRIX RESULT: %s (%d checks, fail=%d)"
          % ("PASS" if not bad else "FAIL", len(verdicts), len(bad)))
    return 0 if not bad else 1


def _notes_from_out(out_dir):
    """从可信侧产物回收夹具 notes：宿主回传白名单含 notes（list），
    控制器逐轮落盘 mechanism_notes.txt（str 形式）。"""
    import ast
    notes = []
    if not os.path.isdir(out_dir):
        return notes
    for d in sorted(os.listdir(out_dir)):
        td = os.path.join(out_dir, d)
        np = os.path.join(td, "mechanism_notes.txt")
        if d.startswith("turn_") and os.path.isfile(np):
            raw = open(np, encoding="utf-8").read()
            try:
                val = ast.literal_eval(raw)
            except Exception:
                val = []
            if isinstance(val, list):
                notes.extend(val)
    return notes


if __name__ == "__main__":
    sys.exit(main())
