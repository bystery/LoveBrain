#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""盲评材料生成（判决令 2026-10-18 §九.交付3）。

从 logs/pilot_r1 双候选运行提取逐轮原始回复（不润色），生成匿名 A/B 盲评 md。
- 媒体轮（L1_t07）跳过：图片未注入 prompt，凭空答图不构成有效样本。
- A/B 身份按固定种子随机，评完后可用 seed 反查。
- 评价选项：原样愿意发 / 修改后愿意发（写怎么改）/ 不想发 / 两句都不想发。
"""
import json, glob, os, random

RUN = "logs/pilot_r1"
SEED = 20261018
SKIP = {"L1_t07"}  # 媒体轮
OUT = "refs/BLIND_SAMPLES_PILOT_R1.md"


def load_run(d):
    turns = {}
    for td in sorted(glob.glob(os.path.join(d, "turn_*"))):
        m = json.load(open(os.path.join(td, "manifest.json"), encoding="utf-8"))
        cid = m["case_id"]
        raw = open(os.path.join(td, "reply_raw.txt"), encoding="utf-8").read().strip()
        reply = None
        if not m.get("veto"):
            # LoveBrain 输出契约：JSON.response.recommended = 用户视角首选可发文本。
            # 结构化提取 ≠ 润色；提取失败按 veto 处理（不手工补）。
            try:
                reply = json.loads(raw)["response"]["recommended"].strip()
            except Exception:
                reply = None
        turns[cid] = {"raw": raw, "reply": reply, "veto": m.get("veto") or
                      (None if reply else "extract_failed"),
                      "clock": m.get("clock_injected"), "score": m.get("score10")}
    return turns


def main():
    ep = json.load(open("benchmark/episodes/PILOT_L1_v1.json", encoding="utf-8"))
    base = load_run(os.path.join(RUN, "baseline_L1"))
    beta = load_run(os.path.join(RUN, "beta_L1"))
    rng = random.Random(SEED)
    lines = ["# Pilot L1 真实模型匿名盲评材料 R1（自动生成，原始回复未润色）\n",
             "> 固定模型 dsf；同冻结历史、同预算口径。A/B 身份随机（seed=%d，评完可反查）。" % SEED,
             "> 媒体轮 L1_t07 未纳入（图片未注入 prompt，不做成对盲评）。\n"]
    keys = [t["case_id"] for t in ep["turns"] if t["case_id"] not in SKIP]
    keymap = {}
    n = 0
    for cid in keys:
        t = next(x for x in ep["turns"] if x["case_id"] == cid)
        if cid not in base or cid not in beta:
            lines.append("\n## %s ——（缺运行，跳过）\n" % cid)
            continue
        if base[cid]["veto"] or beta[cid]["veto"]:
            lines.append("\n## %s ——（契约 veto：%s/%s，回复不可作盲评样本）\n" % (
                cid, base[cid]["veto"], beta[cid]["veto"]))
            continue
        n += 1
        a_is_base = rng.random() < 0.5
        keymap[cid] = "baseline" if a_is_base else "beta_single"
        a, b = (base, beta) if a_is_base else (beta, base)
        lines.append("\n## 组 %d · %s（%s）\n" % (n, cid, t["input"]["clock"]))
        lines.append("**聊天上下文**（末条为待回复消息）：\n")
        for m in t["input"]["messages"]:
            sp = "她" if m["role"] == "HER" else "我"
            lines.append("- %s（%s）：%s" % (sp, m["ts"][11:16], m["text"]))
        intent = (t["input"].get("intent") or {}).get("text")
        if intent:
            lines.append("\n**我的意图**：%s" % intent)
        lines.append("\n**匿名回复 A**\n\n> %s" % a[cid]["reply"])
        lines.append("\n**匿名回复 B**\n\n> %s" % b[cid]["reply"])
        lines.append("\n**评价**（四选一，可改写）：\n")
        lines.append("- [ ] A 可原样发  - [ ] B 可原样发  - [ ] 修改后愿意发（写怎么改）")
        lines.append("- [ ] 不想发（写为什么）  - [ ] 两句都不想发\n")
    lines.append("\n---\n\n**评分键（评完再看）**：seed=%d，A 身份映射见 logs/pilot_r1/blind_key.json\n" % SEED)
    open(OUT, "w", encoding="utf-8").write("\n".join(lines))
    json.dump({"seed": SEED, "a_is_baseline": keymap}, open(
        os.path.join(RUN, "blind_key.json"), "w", encoding="utf-8"),
        ensure_ascii=False, indent=1)
    print("盲评材料 %d 组 → %s" % (n, OUT))


if __name__ == "__main__":
    main()
