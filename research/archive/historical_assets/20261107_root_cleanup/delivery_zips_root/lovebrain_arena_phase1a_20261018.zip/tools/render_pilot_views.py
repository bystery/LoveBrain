#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""双视图渲染器（判决令 2026-10-18 §六）。

从同一份 episode JSON 渲染两种视图，禁止单独加工：
  A 纯微信记录：仅时间+说话人+文本，图片/视频按 [图片]/[视频] 占位，
    无节点号/意图/探针/备注/评分信息 —— 供连续阅读审人机感。
  B 结构化考题版：节点号/类型/意图/may_decline/媒体资产/布景备注/隐藏事实 —— 供工程审查。
隐藏事实（meta.hidden / gaps.note 隐藏声明）只出现在 B。
"""
import json, sys, os

SPEAKER = {"HER": "她", "ME": "我"}


def render(eps):
    A, B = [], []
    for ep in eps:
        A.append("# %s × %s（%s）\n" % (ep.get("me_name", "我"), ep["hero"], ep["relation_stage"]))
        B.append("# %s · 结构化考题版\n\n> episode_id=%s | 请求位 %d | gap %d\n" % (
            ep["episode_id"], ep["episode_id"], len(ep["turns"]), len(ep.get("gaps", []))))
        events = []
        for t in ep["turns"]:
            events.append(("turn", t))
        # gap 按时间插入
        gaps = ep.get("gaps", [])
        events.sort(key=lambda e: e[1]["input"]["messages"][0]["ts"]
                    if e[0] == "turn" else e[1]["from"])
        for kind, obj in events:
            if kind == "gap":
                A.append("\n—— %s 至 %s：没有消息 ——\n" % (obj["from"], obj["to"]))
                B.append("\n## gap · %s → %s\n> %s\n" % (obj["from"], obj["to"], obj["note"]))
                continue
            t = obj
            inp = t["input"]
            meta = t.get("meta", {})
            B.append("\n## %s · %s · 类型=%s%s\n" % (
                t["case_id"], inp["clock"], inp.get("type", "normal"),
                " · may_decline" if inp.get("may_decline") else ""))
            if (inp.get("intent") or {}).get("enabled"):
                B.append("> 意图：%s\n" % inp["intent"]["text"])
            if meta.get("media"):
                B.append("> 媒体：%s\n" % json.dumps(meta["media"], ensure_ascii=False))
            if meta.get("delay"):
                B.append("> 延迟：%s\n" % meta["delay"])
            if meta.get("note"):
                B.append("> 布景备注（不入候选）：%s\n" % meta["note"])
            if meta.get("hidden"):
                B.append("> 隐藏事实（候选不可见）：%s\n" % meta["hidden"])
            A.append("")  # 空行分节点（仅视觉分隔，无标签）
            for m in inp["messages"]:
                line = "%s %s" % (m["ts"][5:], m["text"])
                A.append("%s（%s）：%s" % (SPEAKER[m["role"]], m["ts"][11:16], m["text"]))
                B.append("- [%s] %s `%s`" % (m["role"], m["ts"], m["text"]))
        B.append("\n---\n")
        A.append("\n---\n")
    return "\n".join(A), "\n".join(B)


def main():
    eps = [json.load(open(p, encoding="utf-8")) for p in sys.argv[1:]]
    a, b = render(eps)
    os.makedirs("refs", exist_ok=True)
    open("refs/PILOT_VIEWS_A_clean.md", "w", encoding="utf-8").write(
        "# Pilot 纯微信聊天记录（视图 A，自动生成，无任何考题标注）\n\n" + a)
    open("refs/PILOT_VIEWS_B_structured.md", "w", encoding="utf-8").write(
        "# Pilot 结构化考题版（视图 B，自动生成，与视图 A 同源）\n\n" + b)
    print("视图 A/B 已生成（%d 个 episode）" % len(eps))


if __name__ == "__main__":
    main()
