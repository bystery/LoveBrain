#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Pilot episode 时间线与输入协议自动校验（判决令 2026-10-18 §九.交付4）。

检查项：
 1. 消息 ts 在节点内按序不倒退（含跨角色交错）；
 2. 节点首条消息 ts > 上一节点末条消息 ts（跨节点严格单调）；
 3. request clock ≥ 本节点末条消息 ts（历史齐备才可请求）；
 4. may_decline 位有标注、media 位有资产路径且文件存在；
 5. intent 位文本非空；gap 与任何节点时间不重叠；
 6. 消息内不得出现 'gold'/'探针'/'考' 等防泄漏禁词出现在候选可见文本（messages 文本本身）。
"""
import json, os, sys, datetime

TS_FMT = "%Y-%m-%d %H:%M"
BAD_WORDS = ("gold", "探针", "考点", "评分", "F3", "F4", "F6", "布景历史")


def parse(ts):
    return datetime.datetime.strptime(ts, TS_FMT)


def validate(ep_path):
    ep = json.load(open(ep_path, encoding="utf-8"))
    errs, warns = [], []
    prev_last = None
    turns = ep["turns"]
    for i, t in enumerate(turns):
        cid = t["case_id"]
        inp = t["input"]
        msgs = inp["messages"]
        prev_ts = None
        for m in msgs:
            ts = parse(m["ts"])
            if prev_ts and ts < prev_ts:
                errs.append("%s: 消息时间倒退 %s(%s)" % (cid, m["text"][:12], m["ts"]))
            prev_ts = ts
            if m["role"] not in ("HER", "ME"):
                errs.append("%s: 非法角色 %s" % (cid, m["role"]))
            for w in BAD_WORDS:
                if w in m["text"]:
                    errs.append("%s: 候选可见文本含禁词'%s': %s" % (cid, w, m["text"][:30]))
        clock = parse(inp["clock"])
        if clock < prev_ts:
            errs.append("%s: request clock(%s) 早于末条消息(%s)" % (cid, inp["clock"], m["ts"]))
        if prev_last and parse(msgs[0]["ts"]) <= prev_last:
            errs.append("%s: 首条消息未严格晚于上一节点末条" % cid)
        prev_last = prev_ts
        if inp.get("may_decline") != t.get("meta", {}).get("may_decline"):
            warns.append("%s: may_decline 双处标注不一致" % cid)
        for ref in (inp.get("media") or {}).get("images", []):
            if not os.path.exists(ref):
                errs.append("%s: 图片资产缺失 %s" % (cid, ref))
        if (inp.get("intent") or {}).get("enabled") and not inp["intent"].get("text"):
            errs.append("%s: intent.enabled 但文本为空" % cid)
    # gap 重叠检查
    for g in ep.get("gaps", []):
        g0, g1 = parse(g["from"]), parse(g["to"])
        for t in turns:
            ts0 = parse(t["input"]["messages"][0]["ts"])
            ts1 = parse(t["input"]["messages"][-1]["ts"])
            if ts0 < g1 and ts1 > g0:
                errs.append("gap 与 %s 时间重叠" % t["case_id"])
    n_req = len(turns)
    n_md = sum(1 for t in turns if t["input"].get("may_decline"))
    return ep["episode_id"], n_req, n_md, len(ep.get("gaps", [])), errs, warns


def main():
    ok = True
    for p in sys.argv[1:]:
        eid, n_req, n_md, n_gap, errs, warns = validate(p)
        print("== %s: 请求位 %d（可不回 %d）gap %d" % (eid, n_req, n_md, n_gap))
        for e in errs:
            ok = False
            print("  [ERR]", e)
        for w in warns:
            print("  [WARN]", w)
    print("校验结果:", "PASS" if ok else "FAIL")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
