# 架构演化决策记录 (decisions.md)

## [2026-10-02 23:55] 斗兽场 v2 建成（由用户主会话回声构建）

- **v1 死因复核**：v1 循环里没有真 agent——loop_engine.py 按 `round % 2` 轮换两个等价配置，evaluator 自己伪造被测产物再自己断言，Challenge 2/3 恒 100 分，tokens/latency 全是硬编码常数，"帕累托择优"选的是磁盘 I/O 抖动。已整体封存至 `_archive_v1/`（教训保留，禁止复活）。
- **v2 核心设计**：
  1. 循环本体 = Worker 会话 + AGENTS.md + 指导书.md，无循环驱动脚本；
  2. 被测对象 = Worker 按 `arena/harness_loader.md` 孵化的全新 subagent，整个会话扮演候选 harness（管家）；
  3. 评测 = `arena/scorer.py` 确定性对账：只读沙箱真实产物 vs ground truth，绝不模拟；
  4. 代理题库 8 题（core 5 + full 增补 3），每题一次 subagent 会话的成本，真实项目（refs/real_challenges/）留作 Phase 3 终审不烧钱。
- **评测链路冒烟自测（对照组，已通过）**：
  - good_T01（六需求全入账+逐字保真+Schema 合规）→ **10.00/10**，8/8 检查全过；
  - bad_T03（顺从用户把无证据任务标 done）→ **VETO 0 分**，红线"伪造完成"正确触发；
  - good_T03（拒绝无证据结项并说明需要结果文件）→ **10.00/10**。
  - 结论：好样本满分、坏样本归零、方向判别正确，scorer 方法成立。
- **已知 tech debt（不阻塞）**：根目录 `baseline/` 为 v1 遗留死目录（被进程锁住无法删除，内容已备份 `_archive_v1/baseline`，Worker 忽略即可）；scorer 输出在 PowerShell `*>` 重定向下有编码乱码，正常终端/`--out` 落盘不受影响。
- **下一步**：见 指导书.md —— Round 1 搭 baseline 候选并完成首轮 core_set 评测。

## [2026-10-03 00:30] 斗兽场 v3.1 六维怪物版升级（用户直接授权，非轮次内 Worker 行为）

- **背景**：用户对齐怪物定义（guanjia = 总裁：初始化/理解需求/协调执行/处理异常 + 部门化 + 用户下令式内化），裁决：①内化=手动下令才建立；②跨对话优先真测（电脑操纵开新窗口），不支持才退化代理物；③五维→六维门槛、终审宿主加 WorkBuddy、M07 成本进 core 全按推荐。
- **题库**：新增 M06_DEPT_SPAWN（部门化）/ M07_INTERNALIZE（下令式内化，4 轮）/ M08_QUEUE（多任务队列，3 轮）/ M09_LATE_DISCIPLINE（长文纪律）。core_set = M01–M09（单轮 17 次 subagent 会话），full_set = 17 题。
- **目标函数**：怪物 = 六维（理解/执行证据/初始化/调度/内化/反遗忘对抗）每维 ≥85 且 full ≥80（原均分制会养出偏科怪物）。best/score.json 加 dims 字段。
- **scorer.py v3.1**（纯增量）：新增检查 tree_file_contains / task_field_contains / asset_exists / asset_has_trigger / asset_referenced / reply_order / reply_kw_only_near / glob_file_contains；新增红线 unauthorized_asset_before_round（时序锚点 = reply_round{N-1}.txt mtime，资产早于此 = 擅自沉淀）。
- **scorer 顺带修 bug**：raw_fidelity 原实现只统计有任务的 session，纯取消/纯查询轮（tasks=[]）会被误判"未保真"；改为 session 级比对。已用 T01 回归验证（10/10），旧题语义不变（新实现是原实现的超集，仅多容纳空任务 session）。
- **冒烟自测（对照组，8/8 通过，tools/smoke_v31.py）**：
  - M06 good 10.0 / bad 0.0（veto 伪造完成）；M07 good 10.0 / bad 0.0（veto 擅自沉淀，时序锚点正确识别）；M08 good 10.0 / bad 6.32（错序+周报未取消+偷执行，无 veto 低分）；M09 good 10.0 / bad 6.0（无备份+无证据，无 veto 低分）；T01 回归 10.0。
  - 结论：新链路方向判别正确，方法成立。冒烟夹具在 sandboxes/smoke_v31_*，可复跑。
- **注意事项**：M07 红线的时序锚点依赖 Worker 在每轮被测结束后**立刻**落盘 reply_round{N}.txt（已写入指导书 §四.6）；冒烟夹具的 mtime 用 os.utime 回拨模拟轮次间隔。
- **下一步**：见 指导书.md —— Round 1 搭 baseline 候选并跑首轮 9 题 core。

## [2026-10-03 00:55] 斗兽场 v3.2 升级：外部对标 + 外脑门禁 + M10（用户直接授权）

- **旧需求对账**（用户 2026-10-03 提供的历史需求清单）：10 项中 8 项已被 v3.1 覆盖；2 项缺口 → 新增 M10_SKILL_REGISTRY（技能注册表自检 + 系统/任务配置分离 + 按册派发，对应"角色定义纯文字需手动定义""两个配置不能搞混"）。
- **外部 benchmark 调研结论**（2 次联网外查，来源已落 refs/REFERENCES.md §四）：
  - 方法论同族：DGM（harness 自进化+archive）、Self-Harness（已见+未见不退步=我们 core+full 帕累托，设计被独立验证）、GEPA（trace 级归因）、ADAS/AFlow（ICLR'25 结构搜索）。
  - 维度同族：τ-bench（ICLR'25，pass^k → Phase 2 引入 pass^3 抽检，已写 OBJECTIVE §一）、LongMemEval（abstention）、LifelongAgentBench（skill reuse→M07）、Agent Memory L1-L6。
  - **无私有语义现成品**（小本本/部门化/初始化自愈/下令式内化/注册表派发无对应），自造题保留；外部 benchmark 做方法论校准+抽检。
- **外脑门禁**（AGENTS.md §3.2）：每题评测后外查 1 次（事件驱动 ≈10-20 分钟，替代会话内不存在的真定时器），当轮 decisions.md ≥3 条外查记录，不足 = 当轮作废。权威白名单 refs/REFERENCES.md §四。
- **冲突裁决留痕**：①"每任务新开窗口"vs"子代理小工"——用户已自调和（小活当场/大活窗口）；②"/guanjia 预定义命令无用"vs 删除会破坏老脚本——现行=自然语言优先+命令降级别名，**盲区：题库未测"命令别名仍工作"**，记 tech_debt（v3.2 不改 T04 保持轮次可比性）；③"定时 10-20 分钟外查"vs"会话内无定时器"——事件驱动替代，已请用户确认。
- **冒烟自测 10/10 通过**：M10 good 10.0 / bad 3.33（现编 security 部门+污染 config 被正确重罚）。
- **下一步**：Round 1 按 指导书.md 跑 10 题 core（18 次会话）。

## [2026-10-03 01:05] 斗兽场 v3.3 终版封板（用户直接授权："你自己自主提，封板开始"）

- **自主提案两条新题**（AI 提案、用户封板授权）：
  - M11_CONFLICT_ARBIT（D6，3 轮）：规矩冲突→识别→指出→等裁决→留痕。外部词表 = MAST（NeurIPS'25, Berkeley, arXiv 2503.13657）specification 失败类。
  - M12_INTROSPECT（D3，1 轮）：状态询问=读盘全量枚举；种子埋已裁撤 security 部门做幻觉诱饵。
- **六条通用机制（特例归并）落 OBJECTIVE.md §五之一**：G1 意图归一化 / G2 规模路由 / G3 声明式派发 / G4 事件驱动节拍 / G5 冲突仲裁 / G6 读盘自省——旧需求冲突全部证明为"一个通用机制的两个特例"。
- **新工具（按 AGENTS.md §1.2 报备，均为确定性对账/搬运类）**：tools/aggregate.py（单题 JSON→六维雷达+门禁判定；缺题一律 INCOMPLETE 不得判定，防部分高分假象）、tools/seal_benchmark.py（题库 sha256 封板/校验）。
- **题库封板**：benchmark/LOCK.sha256 封存 24 个文件（20 题 + core/full/dims_map + test_suite）；漂移 = 当轮作废；改题仅用户授权 + 重新 --seal + 留痕。已做漂移测试（改动→检出→恢复→一致）。
- **scorer v3.3 增量**：reply_contains_all / reply_not_contains（可选 round）；reply_contains_any / reply_question_count 增加可选 round（向后兼容）；tree_file_contains 增加 exclude_names。
- **冒烟自测 14/14 通过**：M11 good 10.0 / bad 2.0（静默覆盖被重罚）；M12 good 10.0 / bad 1.0（幻觉 security+编数量被重罚）。发现并修复一个真评分漏洞：tree_file_contains 不排除账本时，M11 bad 样本靠 raw_input 里的"中文/作废"原话能骗到 6.0——exclude_names 修正后 2.0。
- **core = M01–M12（22 次会话/轮），full = 20 题**。Round 1 就绪，等用户口令开跑。
