# lb_mechanism.py — 机制层接口契约 v1 + 基线机制实现
# 宪法地位：候选 candidates/round_N/mechanism/mechanism.py 必须暴露与本文件相同的三个函数。
# runner 加载优先级：候选 mechanism/mechanism.py 存在 → 用之；否则用本模块（= lb_assembly 原样包装，
# 即 round_0_baseline 语义，对拍豁免权仅属 round_0_baseline）。
#
# 接口契约（MECHANISM_INTERFACE v1）：
#   init_state(assets_root: str, episode_meta: dict) -> dict
#       episode 开考时调用一次。episode_meta = {"episode_id", "initial_kb", ...}。
#       单题模式不调用（state=None）。
#   build_prompts(assets_root: str, case_input: dict, state: dict|None)
#       -> {"system": str, "user": str, "id_map": dict, "scene": str}
#       装配入口。state 为机制自管的记忆实例（episode 模式跨轮传递；单题为 None）。
#   update_state(state: dict, case_input: dict, parsed_output: dict|None, raw_reply: str) -> dict
#       每轮评分后调用，把本轮输出写回记忆。parsed_output 为模型输出提取的 JSON（解析失败为 None）。
#       必须返回 state（可原地改）。抛出异常 = episode 中止并记 mechanism_error。
#
# 隔离纪律（宪法 §6）：不同候选使用隔离记忆实例——runner 每个 episode 每次运行都调 init_state
# 新建 state，机制不得在模块级/global 变量存跨轮状态。

import copy
import json
from typing import Optional

import lb_assembly


# ---------- 基线机制 = lb_assembly 原样包装 + 默认写回 v0 ----------

def init_state(assets_root: str, episode_meta: dict) -> dict:
    return {"kb": copy.deepcopy(episode_meta.get("initial_kb") or {}),
            "turn": 0}


def build_prompts(assets_root: str, case_input: dict, state: Optional[dict]) -> dict:
    if state is not None:
        # episode 模式：kb 由机制状态供给（turn input 里的 kb 字段被状态覆盖）
        case_input = dict(case_input)
        case_input["kb"] = copy.deepcopy(state.get("kb") or {})
    return lb_assembly.build_reply_prompts(assets_root, case_input)


def update_state(state: dict, case_input: dict, parsed_output: Optional[dict],
                 raw_reply: str) -> dict:
    """默认写回策略 v0（确定性近似，非 App 逐字节复刻；App 写回逻辑待源码对拍后升级）。
    规则：
      - topic_label 非空 → kb.topic 更新、topic_age_hours 归零
      - scene_facts → 追加 scene_chain 行 "- [clock] f1；f2"
      - ongoing[] {item,status} → 合并进 kb.ongoing_plan（同 item 覆盖，格式 "item | status"）
      - lessons 不自动写（v0 保守：经验教训沉淀归机制变异探索，基线不动）
    """
    kb = state.setdefault("kb", {})
    state["turn"] = state.get("turn", 0) + 1
    if not parsed_output:
        return state
    ana = parsed_output.get("analysis")
    if not isinstance(ana, dict):
        return state

    label = (ana.get("topic_label") or "").strip()
    if label:
        kb["topic"] = label
        kb["topic_age_hours"] = 0

    facts = [f.get("text", "").strip() for f in ana.get("scene_facts") or []
             if isinstance(f, dict) and f.get("text", "").strip()]
    if facts:
        clock = case_input.get("clock", "1970-01-01 00:00")
        line = "- [%s] %s" % (clock, "；".join(facts))
        kb["scene_chain"] = ((kb.get("scene_chain") or "") + "\n" + line).strip()

    ongoing = [o for o in ana.get("ongoing") or []
               if isinstance(o, dict) and (o.get("item") or "").strip()]
    if ongoing:
        lines = [ln for ln in (kb.get("ongoing_plan") or "").split("\n") if ln.strip()]
        for o in ongoing:
            item, status = o["item"].strip(), (o.get("status") or "").strip()
            lines = [ln for ln in lines if not ln.split("|")[0].strip() == item]
            lines.append("%s | %s" % (item, status))
        kb["ongoing_plan"] = "\n".join(lines)

    return state
