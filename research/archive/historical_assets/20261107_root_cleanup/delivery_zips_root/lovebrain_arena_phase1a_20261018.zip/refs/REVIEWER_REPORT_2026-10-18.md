# LoveBrain 斗兽场 · Phase 1A 第四波交付报告（供大牛全面检查）

> 日期：2026-10-18 上午 ｜ 撰写：Worker ｜ 状态：等独立复审
> 本报告承诺：只写真实发生过的事；凡未做的，明确写"未做"。

---

## 〇、给评审的三句话摘要

1. **第三轮判决（2026-10-17 深夜《第三轮独立复核》）的六条指令已全部执行**，每条落点见 §三。
2. 本波抓到并修复了 **两个真实工程 bug**（网关 temperature=null、runner 裸候选名静默失败），均有存档证据。
3. **第一份真实模型匿名盲评材料（9 组）已产出**——这是本项目第一次让真实候选在固定历史下生成可读回复，等您盲评。

---

## 一、项目背景（30 秒版）

培育一套回复质量胜过用户产品 LoveBrain 的微信聊天辅助 AI（"Monster"）。方法论：**机制 >> prompt 调优，真人感第一，考场（评测体系）先于进化**。

- 候选 = harness 机制 + 资产（非 prompt 包装）。当前候选：`round_0_baseline`（LoveBrain 复刻）、`phase0_beta_single`（文件 KV + LCS 检索 + 原子写，单次调用）、`phase0_beta`（同上加二次记忆调用，消融显示暂无收益已默认关闭）。
- 三层评分：lb_scorer（确定性 C0-C13）→ judge 评审团（**未上岗**）→ 用户 HITL。
- 当前阶段：**Phase 1A（真实聊天质量 Pilot + Judge 可信度校准）**，大规模自动进化冻结中。

## 二、历史阶段与三轮评审结论（速查）

| 阶段 | 核心交付 | 评审结论 |
|---|---|---|
| Phase 0 | 架构核验 + 生命周期改造（init/run_turn/snapshot/restore）+ 220 轮 echo 考场 + α/β 双架构 | 通过（附条件） |
| Phase 0.5 | 负对照判别力 ×3、基线保真审计、调用预算消融、严格意图对照、强杀恢复、judge 校准首轮 | 有条件通过 |
| 第一轮评审 | PHASE1A_JUDGE_RERANK.md（重排实验）+ Pilot 大纲 v1 + L1/L2 台词 v1 | 部分退回：Judge 归因过早、L3 返工、台词 ME 占位 |
| 第二轮评审 | 2×2 归因实验 + 大纲 v2 + 台词 v2 + HUMAN_FLAVOR_AUDIT + 证据包复算 + IO 契约 + L3 来源包 | 本轮不判 PASS，执行令 §7 六步 |
| 第三轮评审（最新） | 投票模拟 + L1/L2 JSON 化 + 双视图 + L3 台词 + 盲评 9 组 | **本报告即对该轮执行的交付** |

关键已撤回结论（防误引用）：
- ~~"temperature=0.7 是判决翻转头号根因"~~（撤回：旧日志出站 temperature 实为 null，且服务端行为未核验）
- ~~"A 类 5 条 = 真 Judge 错误实锤"~~（降级为"稳定拒绝，标签待终审"）
- ~~"位置效应独立于内容、两倍差距"~~（降级为观察性差异）
- SPLIT_v1 的 val 6 题 ≠ 独立验收集（已降级为回归留出集）

## 三、第三轮判决六条指令 → 落点对照

| # | 判决指令 | 落点 | 状态 |
|---|---|---|---|
| 一 | Judge：投票模拟先行、逐选项翻转统计、不刷旧 20 题、不上岗 | `refs/PHASE1A_JUDGE_2X2.md` 附录五 + `arena/lb_vote_sim.py` + `logs/phase1a/vote_sim.json` | ✅ |
| 二 | L1：ME 真实化、笔误、间隔口径、图片资产、t09/t10 时间冲突、t12 短告别 | `tools/build_pilot_json.py` → `benchmark/episodes/PILOT_L1_v1.json`；校验器 PASS | ✅ |
| 三 | L2：宣传腔、单方推动、排班、"分晓自见"、14:57 口径、3号场来源、反手密度、回笼觉、t11 不计请求 | 同上 → `PILOT_L2_v1.json`（v3 重写，22 请求位） | ✅ |
| 四 | 数据协议：已发送历史/待回复消息/意图/时间戳/gold 隔离/可接受范围 | `refs/IO_CONTRACT_PILOT.md`（七类事件 + 时间三分 + action 位 + 防泄露自检） | ✅ |
| 五 | L3 来源包 + 试写；L3B 不可无限延期 | `refs/L3_SOURCE_PACK.md`（S1/S2/S3 出处原文）+ `refs/PILOT_DIALOGUES_L3_v1.md`（过敏段 5 节点 + 约饭段 6 节点，**待审未入库**） | ✅（L3B 协议已立，**实施未开始**） |
| 六 | 双视图同源（A 纯聊天 / B 结构化） | `tools/render_pilot_views.py` → `refs/PILOT_VIEWS_A_clean.md` / `PILOT_VIEWS_B_structured.md` | ✅ |
| 七 | 时间线自动校验 | `tools/validate_pilot_timeline.py`（跨节点单调 / 资产存在 / 防泄漏禁词），L1+L2 全 PASS | ✅ |
| — | 真实模型回复 8–10 组 | `refs/BLIND_SAMPLES_PILOT_R1.md`（9 组，见 §五） | ✅ |

## 四、本波抓到的两个工程 bug（含证据）

**Bug 1：网关 temperature=null。** 适配器 `payload.get("temperature", 0.7)` 在显式传 None 时仍会发 `"temperature": null`（键存在，默认值不生效）——此前所有 judge 实验实际出站温度未知。修复：显式归一 None→0.7；CallLog 新增**实际出站 temperature + 原始响应全文（raw_text）落盘**（此前只有 usage，响应原文未存，这正是评审指出的"不可核验"项）。证据：`logs/_invalid/` 旧运行对比 + `arena/lb_gateway.py` 当前实现。

**Bug 2：runner 裸候选名静默失败。** `--candidate round_0_baseline`（裸名）时 assets_root 解析为相对路径 `round_0_baseline/assets`（不存在），`read_asset` 吞掉 OSError 返回空串 → **system prompt 整体为空（148 字符）→ 模型散文作答 → 12/12 假 veto**。修复：`resolve_candidate_dir` fail-fast（`arena/lb_runner.py`）。无效运行完整归档于 `logs/_invalid/pilot_r1_bare_candidate_bug/`（未删除，可复核）。

> 注：打包时安全删除护栏拦截了 `rm -rf`，改为 mv 归档——无效数据完好保留。

## 五、真实模型盲评材料（本轮最重要交付）

**制作方式**：L1 全 12 请求位，同冻结历史（候选不可改写已发生消息），固定 dsf 端点，`round_0_baseline` vs `phase0_beta_single` 同输入生成；9 组 A/B 匿名随机对（seed=20261018，密钥 `logs/pilot_r1/blind_key.json`）。

如实声明：
- 基线 3 轮（t04/t07/t08）输出 JSON 碎裂触发契约 veto，**如实排除不冒充样本**——这本身是 dsf×基线契约遵从性的真实信号；
- 媒体轮 t07 的图片资产未注入 prompt（占位传递），该轮不构成视觉理解测试，未做盲评对；
- 盲评材料呈现 `response.recommended` 的结构化提取（非润色），原始输出全文在 `logs/pilot_r1/*/turn_*/reply_raw.txt`；
- 本批全部为**开发反馈**，不进封存验收集。

初步观感（待您裁决，不算数）：t05 基线输出整段"购机报告体"（典型人机信号）；多个节点两候选都在"接吐槽"但分寸不同。评分器均值：基线 7.5 / β_single 10.0（分差主要由契约 veto 造成，**不构成质量结论**）。

## 六、Judge 投票模拟结论（零新调用，附录五全文见 2X2 报告）

| 协议 | 聚合保留率 | 陷阱识别 |
|---|---|---|
| 三票多数 · temp=0 | 70.9% | 20/21 |
| 三票多数 · temp=0.7 | 65.8% | 21/21 |
| 五位置票 ×5 | 72.2% | 21/21 |

**结论（判决令口径）**：投票摊平抖动但全部过不了 80%——缺口是系统性的（gold 争议 + 判罚标准），不是采样噪声。**不上投票协议，judge 继续不具晋级裁判资格**。temp=0 下仍 25/100 选项翻转（服务端非确定性实锤，但旧日志无法区分"参数未生效"——网关修复后下次运行可区分）。

## 七、诚实清单：未做 / 未完成（防"修订项全部落点"式虚报）

| 项 | 状态 | 说明 |
|---|---|---|
| Judge 独立真人标注验证集 | **未建** | 需新场景 + 真人标注 + 全程隔离；等 Pilot 盲评回流后启动 |
| 27 条误杀的标签终审 | **悬置** | 稳定拒绝 10 / 波动拒绝 17，全部待您/用户裁决，未动 gold 一字 |
| judge prompt / 评分标准修改 | **未动** | 按判决令禁止先改 |
| L3B 空状态自主记忆专项 | **协议已立，实施未开始** | 十条最低协议见 L3_SOURCE_PACK.md §L3B |
| 沙箱整改（进程隔离/文件 ACL/封存不可见） | **未实施** | 只在 IO 契约层定义了可见性，未做运行时隔离 |
| 基线保真补齐（记忆纠错四动作/来源校验） | **方案在 BASELINE_FIDELITY.md，未实施** | 当前 round_0_baseline 仍是缩水复刻 |
| B 线封存验收集 | **框架就绪，未启用** | benchmark/b_line/README_SEALED.md |
| L2 全线真实模型运行 | **未跑** | 仅 L1 跑了双候选 |
| 大规模自动进化 | **冻结中** | 等全部解锁条件 |

## 八、请求您重点审查的问题（按优先级）

1. **盲评 9 组**（`BLIND_SAMPLES_PILOT_R1.md`）：四选一 + 改写。请同时裁：盲评呈现格式是否可用、`response.recommended` 提取是否丢真。
2. **双视图连续阅读**（`PILOT_VIEWS_A_clean.md`，约 10 分钟）：v3 修订后还有没有"编剧式推进 / 单方推动 / 刻意造梗 / 旧事重提"？我们自查已按关口 2 六维度做过，但需要您的连续视角。
3. **L3 台词**（`PILOT_DIALOGUES_L3_v1.md`）：过敏段"提示版 A / 无提示诊断分叉 D-1"的拆分是否成立；S2/S3 本批不出现是否正确。
4. **盲评方法学**：同冻结历史 + 固定端点 + 随机匿名，这个设计对"第一次真实质量信号"是否足够？缺什么控制？
5. **bug 修复复核**：gateway temperature 归一 + runner fail-fast（§四），实现是否有漏洞。
6. **JSON 考题**：`PILOT_L1_v1.json` / `PILOT_L2_v1.json` 的 schema 是否达到"可入库"标准。

## 九、文件索引（本包内）

```
refs/                       全部报告与规范（含 archive/ 历史版本存档）
  ├─ 本报告                 REVIEWER_REPORT_2026-10-18.md
  ├─ 盲评材料               BLIND_SAMPLES_PILOT_R1.md            ★ 优先
  ├─ 双视图                 PILOT_VIEWS_A_clean.md / B_structured.md ★ 优先
  ├─ Judge 系列             PHASE1A_JUDGE_{RERANK,2X2,EVIDENCE}.md
  ├─ Pilot                  PILOT_OUTLINES_v2 / PILOT_DIALOGUES_{L1L2_v2,L3_v1}
  ├─ 契约与纪律             IO_CONTRACT_PILOT / HUMAN_FLAVOR_AUDIT / L3_SOURCE_PACK
  └─ 历史存档               archive/（v1/v2 报告原样保留）
benchmark/
  ├─ episodes/PILOT_L{1,2}_v1.json   正式考题 JSON（时间线校验 PASS）
  ├─ anchors/                        20 题锚点 + 密钥 + SPLIT_v1（已降级口径）
  ├─ media/pilot/                    4 张虚构布景图
  └─ b_line/                         B 线封存框架
arena/                      runner / gateway / mechanism / scorer / 全部实验脚本
  └─ lb_vote_sim.py, lb_judge_2x2.py, lb_judge_rerank.py, lb_judge_calib.py
tools/                      build_pilot_json / validate_pilot_timeline / render_pilot_views / make_blind_samples / mk_pilot_assets
candidates/                 全部候选（baseline / alpha / beta / beta_single / 负对照 / probe）
logs/
  ├─ phase1a/               judge 重排 + 2×2 + 轮换 + vote_sim 全部原始记录
  ├─ pilot_r1/              L1 双候选真实运行（含 reply_raw.txt 原始输出 + blind_key.json）
  ├─ _invalid/              bug 证据存档（裸候选名空 prompt 运行、mock smoke）
  ├─ phase05/               judge_calib.json + discrimination.json（其余大目录未入包）
  └─ decisions.md           决策日志
AGENTS.md / OBJECTIVE.md / 指导书.md   项目章程
```

> 未入包：logs/phase0、logs/phase05 的逐轮大目录（约 60MB，如需可补）、_archive_v1、dataset/（用户真实素材，避免外传）。

---

Worker 2026-10-18
