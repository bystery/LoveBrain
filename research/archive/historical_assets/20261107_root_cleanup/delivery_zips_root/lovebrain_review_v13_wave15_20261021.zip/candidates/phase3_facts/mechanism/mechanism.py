# candidates/phase3_facts — 事实出处与纠正状态候选（父版本 = phase2_expr / 检索 base = phase1_retr_idf）
#
# v12 独立复核 §6-C 执行令的唯一主变量 = 事实出处与纠正状态。
# 实测根因（复核 §2）：NCB_t03 分析层把旧车次 G7812 写成新到站事实（source_ids=[m0]，
# m0 原文"正点 到合肥了"）→ 落库 → t04 因"到/正"弱重合再召回 → 进入真实请求。
# 类型正确 + ID 存在这道门不检验语义支持关系。
#
# 本候选的机制变更（全部确定性代码，无话题词表，无逐题答案规则）：
#   1) 证据支持门（写回时强制）：事实文本中的每个英数 token（车次/编号/时刻等
#      实体标识，复用 base._alnum_tokens）必须逐字出现在所引用消息原文或其时间戳中；
#      source_ids 无效（越界/不存在）→ 拒绝；违例事实拒绝入库（不复述、不降级存入），
#      理由与原文写入追踪。CJK 语义支持不做确定性判定（登记为已知边界，交给
#      facts_evidence.md 生成侧约束 + 下游审计）。
#   2) 全局来源键持久化：每条事实附 src=[{key:"case_id:mid", speaker, ts, text}]、
#      entities、status、anchor_ts——摘要与原始证据分开存储。
#   3) 纠正追踪：所引证据含更正标记（改签/更正/改成/换成/不是这趟）→ 记纠正事件；
#      库内已被点名的旧编号值事实标记 superseded，注入时整条排除（不入请求）。
#      库内存在更正事件时，其余含编号实体的旧事实注入时附"以最新更正为准"警示。
#   4) 状态推导（确定性，不要求模型新增输出字段）：事实文本含约定词且所引证据为
#      问句/提议 → offer（注入标"提议未确认"）；含未来标记 → intent（标"意向未发生"）；
#      否则 event。只有真实 HER/ME 消息能支撑事实——source_ids 只映射当前窗口
#      真实消息，模型草稿永远不在映射表内。
#   5) 相对时间锚定：事实文本含相对时间词时，注入行附出处消息日期锚点。
#   6) 注入渲染变更（仅标注，不改变排序）：scene_chain 行附 src 键与状态/锚点标注。
#
# 不变量（复核 §6-C 约束）：
#   - 检索排名算法零改动：base._retrieve 原函数调用，无副本；
#   - 温度/网关/输出槽位/评分协议/params 契约不变；assets 与 A3 逐字节一致 + 新增
#     facts_evidence.md（生成侧辅助提示，只服务上述机制假设）；
#   - expression.md 注入与生成后四族词面审计继承自 A3（评估专用，不改写回复）。
# 已知边界（登记，不装作已修）：
#   - CJK 语义级编造（钟点/数量/地点的无中生有）机制层不判，靠生成侧提示 + 审计；
#   - 更正证据未点名旧编号时（如"不是这趟 我改签了"）不建立 supersession 链，
#     只做注入警示；HER/ME 归属检索层不可分（继承 base 登记）。

import json
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))          # .../phase3_facts/mechanism
_ROOT = os.path.join(_HERE, "..", "..", "..")               # repo root
_SYS = os.path.join(_ROOT, "arena")
if _SYS not in sys.path:
    sys.path.insert(0, _SYS)

import lb_assembly          # noqa: E402
import lb_scorer            # noqa: E402

# ---- 加载检索 base（phase1_retr_idf，检索/存储唯一事实来源，无副本） ----
import importlib.util as _ilu
_BASE_PATH = os.path.join(_ROOT, "candidates", "phase1_retr_idf",
                          "mechanism", "mechanism.py")
_spec = _ilu.spec_from_file_location("phase1_retr_idf_base", _BASE_PATH)
base = _ilu.module_from_spec(_spec)
_spec.loader.exec_module(base)

# ---- 加载父本 A3（expression 审计四族复用，无副本） ----
_P2_PATH = os.path.join(_ROOT, "candidates", "phase2_expr",
                        "mechanism", "mechanism.py")
_spec2 = _ilu.spec_from_file_location("phase2_expr_parent", _P2_PATH)
parent = _ilu.module_from_spec(_spec2)
_spec2.loader.exec_module(parent)

_EXPR_ASSET = "system_prompt/expression.md"
_FACTS_ASSET = "system_prompt/facts_evidence.md"
_FACTS_FILE = base.FACTS_FILE            # kv_facts.jsonl（记录结构扩展，文件名不变）
ONGOING_FILE = base.ONGOING_FILE

# ---- 通用确定性标记（领域无关；无任何题面实体词） ----
_CORRECTION_MARKS = ("改签", "更正", "改成", "换成", "改成了", "不是这趟", "不是这班", "改乘")
_OFFER_MARKS = ("要不要", "好吗", "行吗", "怎么样", "愿不愿意", "一起", "要不要一起")
_JOINT_MARKS = ("一起", "约好", "约定", "说好了", "约了", "商量好")
_FUTURE_MARKS = ("打算", "准备", "计划", "想要", "下次", "回头", "到时候", "要去看", "要一起")
_CORRECTION_NOTE = "⚠其后存在更正类记录，编号/时刻以最新更正为准"


# ---------- 证据支持门（机制主变量核心） ----------

def _src_lookup(ctx):
    """m-id → (speaker, text, ts)。与 lb_assembly.render_chat 的编号规则一致：
    仅 HER/ME 消息按序编号 m0..（IDEA 不占号）。模型草稿不在输入消息里，
    结构上不可能被引用——"不把待发送草稿当历史"由此保证。"""
    msgs = [m for m in ctx["input"].get("messages", []) if isinstance(m, dict)]
    lookup = {}
    for i, m in enumerate(msgs):
        lookup["m%d" % i] = {"speaker": "HER" if m.get("role") == "HER" else "ME",
                             "text": m.get("text", ""),
                             "ts": str(m.get("ts") or "")}
    return lookup


def _gate_fact(fact, lookup, case_id):
    """证据支持门。返回 (src_records|None, reject_reason|None)。
    拒绝策略：拒绝即不入库（不复述、不降级），理由与原文留痕于追踪。"""
    sids = fact.get("source_ids") or []
    if not isinstance(sids, list) or not sids:
        return None, "gate_reject:source_ids_empty"
    srcs = []
    for sid in sids:
        rec = lookup.get(str(sid).strip())
        if rec is None:
            return None, "gate_reject:source_id_unknown:%s" % sid
        srcs.append(dict(rec, key="%s:%s" % (case_id, sid)))
    # 英数实体支持检查：事实文本 token ⊆ 所引原文∪其时间戳 的 token 池
    toks = set(base._alnum_tokens(fact.get("text") or ""))
    if toks:
        pool = set()
        for r in srcs:
            pool |= set(base._alnum_tokens(r["text"]))
            pool |= set(base._alnum_tokens(r["ts"]))
        missing = toks - pool
        if missing:
            return None, "gate_reject:entity_not_in_evidence:" + ",".join(sorted(missing)[:4])
    return srcs, None


def _derive_status(fact_text, srcs):
    """确定性状态推导（不要求模型新增字段）：
    offer = 事实含约定/同行动词 且 所引证据为问句或提议（邀请≠约定）；
    intent = 事实或证据含未来标记（意向未发生）；
    event  = 其余（默认，证据背书）。"""
    txt = fact_text or ""
    src_join = "".join(r["text"] for r in srcs)
    low = txt.lower()
    src_is_offer = (any(w in src_join for w in _OFFER_MARKS)
                    or any(r["text"].rstrip().endswith(("吗", "？", "?"))
                           for r in srcs))
    if any(w in txt for w in _JOINT_MARKS) and src_is_offer:
        return "offer"
    if any(w in low for w in _FUTURE_MARKS) or any(w in src_join for w in _FUTURE_MARKS):
        return "intent"
    return "event"


def _is_correction(srcs):
    return any(any(w in r["text"] for w in _CORRECTION_MARKS) for r in srcs)


# ---------- 存储（文件名/读写函数与 base 一致，记录结构扩展） ----------

def _append_fact(h, fact):
    with open(os.path.join(h["sandbox"], _FACTS_FILE), "a", encoding="utf-8") as f:
        f.write(json.dumps(fact, ensure_ascii=False) + "\n")


def _load_facts(h):
    return base._load_facts(h)


def _load_ongoing(h):
    return base._load_ongoing(h)


def _save_ongoing(h, ongoing):
    base._save_ongoing(h, ongoing)


def _write_trace(h, trace):
    base._write_trace(h, trace)


def _hours_between(a, b):
    return base._hours_between(a, b)


# ---------- 提示装配：expression.md（继承 A3） + facts_evidence.md（本候选） ----------
# 直接调用式组装（本候选自持 run_turn，无需作用域替换全局函数）。

_raw_build = getattr(lb_assembly.build_reply_prompts, "_expr_orig",
                     lb_assembly.build_reply_prompts)


def _build_with_assets(assets_root, case_input):
    out = _raw_build(assets_root, case_input)
    for rel in (_EXPR_ASSET, _FACTS_ASSET):
        guard = lb_assembly.read_asset(assets_root, rel)
        if guard:
            out["system"] = out["system"] + "\n\n---\n\n" + guard
    return out


# ---------- 注入渲染（排序不变，仅标注） ----------

def _render_scene_chain(selected, has_correction_events):
    lines = []
    for _, f in selected:
        note = ""
        ents = f.get("entities") or []
        status = f.get("status", "event")
        if status == "offer":
            note += "｜⚠提议未确认，不当已约定"
        elif status == "intent":
            note += "｜⚠意向未发生"
        if f.get("superseded"):
            continue   # 已被更正的旧值整条不入请求（复核 §6-C-2）
        if has_correction_events and ents:
            note += "｜" + _CORRECTION_NOTE
        # 相对时间锚定：事实文本含相对时间词 → 附出处日期锚
        anchor = f.get("anchor_ts") or ""
        text = f.get("text", "")
        if anchor and any(w in text for w in base._TIME_WORDS):
            note += "｜相对时间以出处消息日 %s 为锚" % anchor.split(" ")[0]
        src_keys = ",".join(r["key"] for r in (f.get("src") or []))
        lines.append("- [%s] %s%s%s" % (f.get("clock", ""), text,
                                        ("｜src=" + src_keys) if src_keys else "",
                                        note))
    return "\n".join(lines)


# ---------- 生命周期 ----------

def init(assets_root, episode_meta, gateway, sandbox):
    return base.init(assets_root, episode_meta, gateway, sandbox)


def set_memory_access(h, enabled):
    base.set_memory_access(h, enabled)


def run_turn(h, ctx, gw):
    h["turn"] += 1
    ai = ctx["input"]
    window = "".join(m.get("text", "") for m in ai.get("messages", [])
                     if isinstance(m, dict))
    mem_on = bool(h.get("memory_access", True))
    clock = ai.get("clock", "")
    case_id = ctx.get("case_id") or ai.get("case_id", "")
    trace = {"turn": h["turn"], "case_id": case_id, "clock": clock,
             "memory_access": mem_on,
             "strategy_note": ("唯一主变量=事实出处与纠正状态；检索=base._retrieve 原函数；"
                               "写回=证据支持门+来源键+纠正追踪+状态/锚点")}
    facts = _load_facts(h) if mem_on else []
    ongoing = _load_ongoing(h) if mem_on else []
    trace["facts_stored"] = [{"fact_id": i, "clock": f.get("clock", ""),
                              "text": f.get("text", ""), "status": f.get("status", ""),
                              "superseded": bool(f.get("superseded"))}
                             for i, f in enumerate(facts)]
    trace["ongoing_stored"] = ongoing
    retrieved_pairs = base._retrieve(window, facts, trace=trace) if mem_on else []
    # 纠正事件感知（库内任一事实由更正证据写入）→ 旧编号事实注入附警示
    has_corr_events = any(bool(f.get("correction")) for f in facts)
    selected = [(i, f) for i, f in retrieved_pairs if not f.get("superseded")]
    dropped_superseded = [i for i, f in retrieved_pairs if f.get("superseded")]
    trace["injected"] = {
        "scene_chain_fact_ids": [i for i, _ in selected],
        "superseded_dropped": dropped_superseded,
        "ongoing_all": [o.get("item", "") for o in ongoing],
        "topic": h.get("topic", "") if mem_on else "",
        "ongoing_injection_mode": "full（与父版本一致，不经过检索）"}

    if mem_on and clock and h.get("last_clock"):
        dh = _hours_between(h["last_clock"], clock)
        if dh is not None:
            h["hours_since_last_exchange"] = max(0.0, dh)
    if clock:
        h["last_clock"] = clock

    kb = {"scene_chain": _render_scene_chain(selected, has_corr_events),
          "ongoing_plan": "\n".join("%s | %s" % (o["item"], o["status"])
                                    for o in ongoing),
          "topic": h.get("topic", "") if mem_on else ""}
    if mem_on and h.get("topic_started_at") and clock:
        dh2 = _hours_between(h["topic_started_at"], clock)
        kb["topic_age_hours"] = max(0.0, dh2) if dh2 is not None else 0
    elif mem_on and h.get("topic"):
        kb["topic_age_hours"] = 0
    if mem_on and h.get("hours_since_last_exchange") is not None:
        kb["hours_since_last_exchange"] = h["hours_since_last_exchange"]
    if mem_on and h.get("initial_kb"):
        ik = h["initial_kb"]
        for k in ("me", "her", "warmth", "style", "stage", "topic",
                  "topic_age_hours", "lessons", "recent", "scene_chain",
                  "ongoing_plan"):
            if ik.get(k) and not kb.get(k):
                kb[k] = ik[k]
    ai2 = dict(ai)
    ai2["kb"] = kb
    if h.get("persona"):
        ai2.setdefault("persona", h["persona"])
    assets_root = ctx.get("assets_root") or h["assets_root"]
    assembled = _build_with_assets(assets_root, ai2)
    images = [m["image"] for m in ai.get("messages", [])
              if isinstance(m, dict) and m.get("image")]
    res = gw.generate(assembled["system"], assembled["user"],
                      images=images or None, tag="main")

    # ---- 写回：证据支持门 + 来源键 + 纠正追踪 + 状态推导（本候选主变量） ----
    parsed = lb_scorer.extract_json_block(res["text"])
    wb_skip = None
    ana_safe = None
    gate_acc, gate_rej, corrections = [], [], []
    lookup = _src_lookup(ctx)
    if parsed:
        raw_ana = parsed.get("analysis")
        if isinstance(raw_ana, dict):
            ana = raw_ana
            errs = lb_scorer.analysis_type_errors(ana)
            if errs:
                wb_skip = "nested_type_violation:" + ",".join(errs[:6])
            else:
                ana_safe = ana
                # memory_access=False：写回整体关闭（与 base notes 声明语义一致：
                # kv_facts/kv_ongoing/topic 全部不落盘），读侧已为空。
                for f in (ana.get("scene_facts") or []) if mem_on else []:
                    if not isinstance(f, dict):
                        continue
                    t = (f.get("text") or "").strip()
                    if not t:
                        continue
                    srcs, reason = _gate_fact(f, lookup, case_id) if mem_on else ([], None)
                    if reason:
                        gate_rej.append({"text": t, "reason": reason,
                                         "source_ids": f.get("source_ids")})
                        continue
                    status = _derive_status(t, srcs)
                    ents = sorted(set(base._alnum_tokens(t)))
                    rec = {"clock": clock, "text": t,
                           "src": srcs, "entities": ents, "status": status,
                           "anchor_ts": (srcs[0]["ts"] if srcs else clock),
                           "correction": bool(_is_correction(srcs)) if srcs else False,
                           "superseded": False, "superseded_by": None}
                    # 纠正追踪：更正证据点名了库内旧编号值 → 旧值标记 superseded
                    if rec["correction"] and mem_on:
                        corr_toks = set()
                        for r in srcs:
                            corr_toks |= set(base._alnum_tokens(r["text"]))
                        for old in facts:
                            if old.get("superseded"):
                                continue
                            ot = set(old.get("entities") or
                                     base._alnum_tokens(old.get("text", "")))
                            if ot and (ot & corr_toks):
                                old["superseded"] = True
                                old["superseded_by"] = rec["src"][0]["key"] if rec["src"] else case_id
                                corrections.append({"superseded_text": old.get("text", ""),
                                                    "by": old["superseded_by"]})
                        # 重写整库以固化 superseded 标记（append-only 库的小整写：
                        # 只加标记不改文本；kv_facts 为本机制私有文件，原子性见下）
                        if corrections:
                            p = os.path.join(h["sandbox"], _FACTS_FILE)
                            tmp = p + ".tmp"
                            with open(tmp, "w", encoding="utf-8") as tf:
                                for old in facts:
                                    tf.write(json.dumps(old, ensure_ascii=False) + "\n")
                            os.replace(tmp, p)
                    _append_fact(h, rec)
                    facts.append(rec)
                    gate_acc.append({"text": t, "status": status,
                                     "src": [r["key"] for r in srcs]})
                changed = False
                for o in (ana.get("ongoing") or []) if mem_on else []:
                    item = (o.get("item") or "").strip() if isinstance(o, dict) else ""
                    if item:
                        ongoing = [x for x in ongoing if x["item"] != item]
                        ongoing.append({"item": item, "status": o.get("status", "")})
                        changed = True
                if changed:
                    _save_ongoing(h, ongoing)
                label = (ana.get("topic_label") or "").strip()
                if label and label != h.get("topic"):
                    h["topic"] = label
                    h["topic_started_at"] = clock
        else:
            wb_skip = "analysis_not_dict:%s" % type(raw_ana).__name__

    trace["writeback"] = {"facts_appended":
                          [g["text"] for g in gate_acc] if ana_safe else None,
                          "skipped": wb_skip}
    trace["fact_gate"] = {"accepted": gate_acc, "rejected": gate_rej,
                          "corrections": corrections,
                          "policy": ("alnum-token evidence support; invalid source_ids "
                                     "reject; superseded excluded from injection")}
    _write_trace(h, trace)

    notes = "phase3_facts: evidence-gated writeback(src-key+entity gate+correction+status/anchor); retrieval=base._reuse; expression.md+facts_evidence.md"
    if gate_rej:
        notes += " | gate_rejected=%d" % len(gate_rej)
    if wb_skip:
        notes += " | writeback_skipped(%s)" % wb_skip
    if not mem_on:
        notes += (" | memory_access=False: kv_facts/kv_ongoing/topic/检索/"
                  "last_clock/initial_kb 已关闭（共同画像 persona 保留）")
    out = {"reply": res["text"], "notes": notes,
           "id_map": assembled["id_map"]}

    # ---- 生成后四族词面审计（继承 A3：评估专用，不改写回复、不参与控制流） ----
    parsed2 = lb_scorer.extract_json_block(out.get("reply") or "")
    findings, parse_ok = [], parsed2 is not None
    if parse_ok:
        import re as _re
        _FAMILIES = parent._load_families()
        resp = parsed2.get("response")
        texts = []
        if isinstance(resp, dict):
            for k in ("recommended", "bad_boy", "playful", "warm"):
                v = resp.get(k)
                if isinstance(v, str) and v.strip():
                    texts.append(("response." + k, v))
        dirs = parsed2.get("directions")
        if isinstance(dirs, list):
            for i, v in enumerate(dirs):
                if isinstance(v, str) and v.strip():
                    texts.append(("directions[%d]" % i, v))
        for field, text in texts:
            for fam, pat, label in _FAMILIES:
                m = _re.search(pat, text)
                if m:
                    findings.append({"family": fam, "field": field,
                                     "match": m.group(0), "label": label})
    try:
        with open(os.path.join(h["sandbox"], "expr_trace.jsonl"), "a", encoding="utf-8") as f:
            f.write(json.dumps({"turn": h.get("turn"), "case_id": case_id,
                                "parse_ok": parse_ok,
                                "expr_policy": "expression.md injected",
                                "findings": findings,
                                "n_findings": len(findings)},
                               ensure_ascii=False, default=str) + "\n")
    except OSError:
        pass
    return out


def snapshot(h):
    # 与 base 一致（retrieval_trace/expr_trace 不入快照）
    parts = []
    for fn in (_FACTS_FILE, ONGOING_FILE):
        p = os.path.join(h["sandbox"], fn)
        data = open(p, "rb").read() if os.path.exists(p) else b""
        parts.append(fn.encode("utf-8") + b"\n" + data + b"\n--SNAP--\n")
    meta = json.dumps({"turn": h["turn"], "topic": h["topic"],
                       "last_clock": h.get("last_clock"),
                       "topic_started_at": h.get("topic_started_at"),
                       "hours_since_last_exchange": h.get("hours_since_last_exchange"),
                       "persona": h.get("persona") or {},
                       "initial_kb": h.get("initial_kb") or {},
                       "memory_access": bool(h.get("memory_access", True))},
                      ensure_ascii=False).encode("utf-8")
    return b"".join(parts) + b"META\n" + meta


def restore(sandbox, snap):
    h = {"assets_root": None, "sandbox": sandbox, "turn": 0,
         "topic": "", "topic_age": 99}
    chunks = snap.split(b"META\n")
    body, meta = chunks[0], chunks[1]
    for block in body.split(b"\n--SNAP--\n"):
        if not block.strip():
            continue
        nl = block.index(b"\n")
        fn = block[:nl].decode("utf-8")
        data = block[nl + 1:]
        with open(os.path.join(sandbox, fn), "wb") as f:
            f.write(data)
    m = json.loads(meta.decode("utf-8"))
    h.update(m)
    return h
