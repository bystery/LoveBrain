#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""l3b_frozen_fork.py — L3B 冻结分叉最小实验（第五波判决 §6.3/§11-4）。

取代旧"有前史/无前史"CTRL 设计（判决否决理由：FULL 经历 t1-t6、CTRL 只经历
t4-t6，是前史对照而非"同一冻结状态下关闭记忆访问"）。

流程（每步落 fork_log.jsonl：事件/时间/pid/散列）：
  P0 冻结点：同一前史（L3B_MINI_FULL t1-t4）跑到 stop_after=4，独立子进程执行；
     记录 checkpoint.bin sha256 + sandbox 文件清单散列。
  P1 分叉：两个**新进程、新目录**各自 restore 同一快照——
     分支 A（full）        = 完整记忆（全部历史渠道开放）；
     分支 B（memory_off）  = --memory-off（kv_facts/kv_ongoing/topic/检索/
                             last_clock/initial_kb 全关，persona 保留）。
     差异清单由机制 notes 逐轮落盘。
  P2 后测：两分支各跑 t5（召回：边界/过敏分开计分）+ t6（不应回提）。
  P3 报告：读两分支 scoring.json/prompt/calls，产出证据矩阵
     （logs/l3b_fork/fork_summary.json + refs/PHASE1A_L3B_FORK_REPORT.md）。

恢复证据链要求（判决 §6.3）：恢复前快照散列、恢复源=该快照、新 pid、
新目录 sandbox 重建文件清单——无网络也可验证（--adapter mock 离线先行）；
真实调用为"有限"档：2 分支 × 2 轮 = 4 次请求。

用法：
  python tools/l3b_frozen_fork.py --adapter mock                # 离线协议验证
  python tools/l3b_frozen_fork.py --adapter openai_compat      # 有限真实调用
"""
import argparse
import datetime
import hashlib
import json
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EP = os.path.join(ROOT, "benchmark", "episodes", "L3B_MINI_FULL.json")
FREEZE_AFTER = 4          # 前史 = t1-t4（含窗口驱逐轮）
POSTTEST_TURNS = 6        # 总轮数（后测 t5-t6）

CHANNELS_CLOSED = ["kv_facts（事实检索库）", "kv_ongoing（进行中事项）",
                   "topic 摘要与话题年龄", "LCS 检索缓存输出",
                   "last_clock / hours_since_last_exchange", "initial_kb 预置资源"]


def _now():
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def _sandbox_tree(d):
    out = {}
    for root, _, files in os.walk(d):
        for fn in sorted(files):
            p = os.path.join(root, fn)
            out[os.path.relpath(p, d).replace("\\", "/")] = _sha(p)
    return out


class ForkLog:
    def __init__(self, path):
        self.path = path

    def log(self, event, **kw):
        rec = {"event": event, "ts": _now(), "pid": os.getpid()}
        rec.update(kw)
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False, default=str) + "\n")
        print("[fork] %s %s" % (event, kw.get("detail", "")))


def _run_runner(args_list, log, event):
    """独立子进程执行 runner（第六波判决 §6.2：记录实际子进程 pid，不再只有父 pid）。"""
    cmd = [sys.executable, os.path.join(ROOT, "arena", "lb_runner.py")] + args_list
    log.log(event + "_start", detail=" ".join(args_list), cmd=cmd[0])
    p = subprocess.Popen(cmd, cwd=ROOT, stdout=subprocess.PIPE,
                         stderr=subprocess.PIPE, text=True,
                         encoding="utf-8", errors="replace")
    log.log(event + "_child_pid", pid=p.pid, detail="runner subprocess")
    out, errout = p.communicate()
    if p.returncode != 0:
        raise RuntimeError("%s 失败 rc=%d\nstdout=%s\nstderr=%s"
                           % (event, p.returncode, (out or "")[-2000:],
                              (errout or "")[-2000:]))
    log.log(event + "_child_exit", pid=p.pid, rc=p.returncode)
    return (out or "").strip()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--adapter", default="mock",
                    choices=["mock", "openai_compat", "echo"])
    ap.add_argument("--outdir", default=os.path.join(ROOT, "logs", "l3b_fork"),
                    help="实验根目录；每次运行在其下建唯一 run_id 子目录")
    ap.add_argument("--candidate", default="phase0_beta_single")
    ap.add_argument("--freeze-from", default=None,
                    help="复用已有冻结点目录（复制其 checkpoint/turns 进本次 run；"
                         "判据：复用前史不重烧）")
    ap.add_argument("--run-id", default=None, help="覆盖自动 run_id（调试用）")
    args = ap.parse_args()

    # ---- 第六波判决 §6.1：唯一 run_id + 独立不可覆盖目录 ----
    run_id = args.run_id or ("l3bfork_%s_pid%d" % (
        datetime.datetime.now().strftime("%Y%m%d_%H%M%S"), os.getpid()))
    run_dir = os.path.join(args.outdir, run_id)
    if os.path.exists(run_dir):
        raise RuntimeError("run 目录已存在，拒绝覆盖（历史证据不可销毁）: %s" % run_dir)
    os.makedirs(run_dir, exist_ok=True)
    # 全局追加式索引（只追加，永不删除/覆盖——旧 fork_log 同文件追加导致重跑覆盖证据，已废）
    index_path = os.path.join(args.outdir, "INDEX.jsonl")
    with open(index_path, "a", encoding="utf-8") as f:
        f.write(json.dumps({"run_id": run_id, "ts": _now(), "pid": os.getpid(),
                            "adapter": args.adapter, "candidate": args.candidate},
                           ensure_ascii=False) + "\n")
    log = ForkLog(os.path.join(run_dir, "fork_log.jsonl"))
    log.log("experiment_start", run_id=run_id, adapter=args.adapter,
            candidate=args.candidate, design="freeze-fork v3（第六波判决 §6.1）")

    out_freeze = os.path.join(run_dir, "freeze")
    ck_bin = os.path.join(out_freeze, "checkpoint.bin")
    ck_json = os.path.join(out_freeze, "checkpoint.json")

    # ---- P0 冻结点 ----
    if args.freeze_from:
        import shutil
        src_ck = os.path.join(args.freeze_from, "checkpoint.bin")
        if not os.path.isfile(src_ck):
            raise RuntimeError("--freeze-from 缺 checkpoint.bin: %s" % src_ck)
        os.makedirs(out_freeze, exist_ok=True)
        shutil.copytree(args.freeze_from, out_freeze,
                        dirs_exist_ok=True, ignore=shutil.ignore_patterns("gateway_events.jsonl"))
        log.log("freeze_reused", detail=args.freeze_from, sha256=_sha(src_ck))
    else:
        _run_runner(["--episode", EP, "--candidate", args.candidate,
                     "--out", out_freeze, "--adapter", args.adapter,
                     "--stop-after", str(FREEZE_AFTER)], log, "prehistory_run")
        log.log("freeze_point", detail=ck_bin, sha256=_sha(ck_bin),
                sandbox_tree=_sandbox_tree(os.path.join(out_freeze, "_sandbox")))
    if not os.path.isfile(ck_bin):
        raise RuntimeError("冻结点 checkpoint.bin 缺失")
    freeze_sha = _sha(ck_bin)
    log.log("freeze_hash_locked", sha256=freeze_sha)

    # ---- P1+P2 分叉（每分支独立新进程、新目录） ----
    branches = {"A_full": [], "B_memory_off": ["--memory-off"]}
    branch_info = {}
    for name, extra in branches.items():
        out_b = os.path.join(run_dir, name)
        if os.path.exists(out_b):
            raise RuntimeError("分支目录已存在，拒绝覆盖: %s" % out_b)
        os.makedirs(out_b, exist_ok=True)
        # 恢复源快照复制 + 散列留证；前史轮产物一并复制——resume 需要前史 manifest，
        # 且分支目录自含完整轮记录便于审计（两分支共享同一前史，本就同源）
        import shutil as _sh
        _sh.copy2(ck_bin, os.path.join(out_b, "checkpoint.bin"))
        _sh.copy2(ck_json, os.path.join(out_b, "checkpoint.json"))
        for d in sorted(os.listdir(out_freeze)):
            if d.startswith("turn_"):
                _sh.copytree(os.path.join(out_freeze, d), os.path.join(out_b, d))
        log.log("restore_source_staged", branch=name, source_sha256=freeze_sha,
                staged_sha256=_sha(os.path.join(out_b, "checkpoint.bin")))
        _run_runner(["--episode", EP, "--candidate", args.candidate,
                     "--out", out_b, "--adapter", args.adapter,
                     "--resume"] + extra, log, "branch_run_%s" % name)
        # 恢复后 sandbox 重建证据
        log.log("branch_done", branch=name,
                sandbox_tree=_sandbox_tree(os.path.join(out_b, "_sandbox")))
        branch_info[name] = out_b

    # ---- P3 汇总报告 ----
    summary = {"design": "freeze-fork v3", "run_id": run_id,
               "adapter": args.adapter,
               "candidate": args.candidate, "freeze_sha256": freeze_sha,
               "channels_closed_B": CHANNELS_CLOSED, "branches": {}}
    for name, out_b in branch_info.items():
        em = json.load(open(os.path.join(out_b, "episode_manifest.json"),
                            encoding="utf-8"))
        b = {"resumed_from": em.get("resumed_from"),
             "complete": em.get("complete"), "turns": em.get("turns"),
             "posttest": {}}
        for i, cid in ((4, "L3B_t05"), (5, "L3B_t06")):
            td = os.path.join(out_b, "turn_%02d_%s" % (i + 1, cid))
            sc = json.load(open(os.path.join(td, "scoring.json"), encoding="utf-8"))
            checks = {c["id"]: c for c in sc["checks"]}
            prompt_user = ""
            calls_p = os.path.join(td, "calls.json")
            if os.path.isfile(calls_p):
                calls = json.load(open(calls_p, encoding="utf-8"))
                if calls:
                    prompt_user = calls[0].get("user") or ""
            reply = open(os.path.join(td, "reply_raw.txt"), encoding="utf-8").read()
            b["posttest"][cid] = {
                "score10": sc["score10"], "veto": sc["veto"],
                "allergy_kw_hit": checks.get("must_kw_0", {}).get("pass"),
                "boundary_kw_hit": checks.get("must_kw_1", {}).get("pass"),
                "stale_mentions": [c for c in sc["checks"]
                                   if c["id"].startswith("stale_kw_") and not c["pass"]],
                "prompt_has_allergy_fact": "过敏" in prompt_user,
                "prompt_has_boundary_fact": ("门外" in prompt_user
                                             or "不让进" in prompt_user),
                "prompt_has_ongoing_cat": "养猫" in prompt_user,
                "reply_excerpt": reply[:200],
            }
        summary["branches"][name] = b

    with open(os.path.join(run_dir, "fork_summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    log.log("report_written", detail="fork_summary.json")

    # 控制台摘要
    for name in branch_info:
        b = summary["branches"][name]["posttest"]
        t5 = b["L3B_t05"]
        print("%s: t5 score=%s 过敏=%s 边界=%s | prompt含过敏事实=%s 含边界=%s 含ongoing=%s"
              % (name, t5["score10"], t5["allergy_kw_hit"], t5["boundary_kw_hit"],
                 t5["prompt_has_allergy_fact"], t5["prompt_has_boundary_fact"],
                 t5["prompt_has_ongoing_cat"]))
    print("汇总 → %s" % os.path.join(run_dir, "fork_summary.json"))


if __name__ == "__main__":
    main()
