#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""make_review_package.py — 审稿包白名单打包（第六波判决 §11/§12-4）。

背景：v4 全量包实际包含 84 个 dataset/（用户真实素材）与 25 个 _archive_v1/ 文件，
与交付声明"已排除"不符——判决要求审稿包用白名单重出，附 manifest 与排除断言。
旧全量 zip 保留本地证据，不再外发。

用法：python tools/make_review_package.py --out lovebrain_review_v5.zip
"""
import argparse
import hashlib
import json
import os
import time
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 白名单：审稿必需的目录（相对 ROOT）；未列出一律不进包
WHITELIST_DIRS = ("arena", "candidates", "tools", "refs",
                  "benchmark/episodes", "benchmark/media", "benchmark/anchors",
                  "benchmark/cases")
# 明确排除（即使落在白名单目录内）
EXCLUDE_PARTS = ("dataset", "_archive_v1", "__pycache__", ".git")
EXCLUDE_EXT = (".pyc", ".zip")

# 历史大日志目录：只带关键证据目录
LOG_INCLUDE = ("logs/pilot_r3", "logs/l3b_fork", "logs/l3b_mini",
               "logs/phase1a", "logs/pilot_r1_bare_candidate_bug",
               "logs/pilot_r2_image_ref_bug")


def _allowed(rel_path: str) -> bool:
    parts = rel_path.replace("\\", "/").split("/")
    if any(p in EXCLUDE_PARTS for p in parts):
        return False
    if rel_path.endswith(EXCLUDE_EXT):
        return False
    rel = rel_path.replace("\\", "/")
    if rel.startswith(tuple(d + "/" for d in WHITELIST_DIRS)):
        return True
    if rel.startswith(tuple(d + "/" for d in LOG_INCLUDE)):
        return True
    return os.path.dirname(rel) == "" and rel.endswith((".md", ".txt"))   # 根部说明文件


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    out = args.out or os.path.join(
        ROOT, "lovebrain_review_v5_%s.zip" % time.strftime("%Y%m%d_%H%M%S"))

    members = []
    for root, dirs, files in os.walk(ROOT):
        rel_dir = os.path.relpath(root, ROOT).replace("\\", "/")
        if rel_dir == ".":
            rel_dir = ""
        for fn in files:
            rel = (rel_dir + "/" + fn).lstrip("/")
            if _allowed(rel):
                members.append(rel)
    members.sort()

    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for rel in members:
            z.write(os.path.join(ROOT, rel), rel)

    # manifest + 排除断言
    entries = []
    for rel in members:
        p = os.path.join(ROOT, rel)
        h = hashlib.sha256(open(p, "rb").read()).hexdigest()
        entries.append({"path": rel, "bytes": os.path.getsize(p), "sha256": h[:16]})
    violations = [e["path"] for e in entries
                  if any(p in e["path"].split("/") for p in ("dataset", "_archive_v1"))]
    manifest = {
        "package": os.path.basename(out),
        "built_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "n_files": len(entries),
        "size_bytes": os.path.getsize(out),
        "whitelist_dirs": list(WHITELIST_DIRS),
        "log_include": list(LOG_INCLUDE),
        "excluded_parts": list(EXCLUDE_PARTS),
        "exclusion_assertion": "PASS" if not violations else "FAIL: %s" % violations[:10],
        "declaration": ("审稿白名单包：dataset/（用户真实素材）与 _archive_v1/ 已排除，"
                        "本 manifest 逐文件 sha256（前16位）可复核。旧全量 zip 仅留本地。"),
        "files": entries,
    }
    mpath = os.path.join(ROOT, "refs", "REVIEW_PACKAGE_MANIFEST.json")
    with open(mpath, "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=1)
    print("files=%d size=%.1fMB exclusion_assertion=%s" %
          (len(entries), os.path.getsize(out) / 1e6, manifest["exclusion_assertion"]))
    print("manifest →", mpath)
    if violations:
        raise SystemExit("排除断言失败")


if __name__ == "__main__":
    main()
