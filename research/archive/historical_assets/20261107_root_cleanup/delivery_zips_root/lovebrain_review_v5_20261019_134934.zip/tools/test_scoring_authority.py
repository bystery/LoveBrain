#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""test_scoring_authority.py — 评分权威端到端反例（第六波判决 §3/§12-1）。

攻击模型：v2 候选机制在 run_turn 里篡改自己的 ctx.messages（追加/删除/改角色），
并让回复的 analysis.scene_facts 引用伪造来源 m3。
断言：评分只认评估侧原题快照——伪造来源必须稳定 veto=illegal_source_id:m3、
score10=0；候选回报的 id_map 不被信任；评分结果与未被候选接触的原题一致。

四类反例：
  A1 追加虚构 HER 消息后引用 m3
  A2 删除真实消息（m1）后引用重编号后的 m1（实际指向已删消息）
  A3 改角色（HER→ME）试图混淆来源表
  A4 候选在返回值里自带伪造 id_map（runner 必须无视）
零网络调用（mock 适配器 + 攻击台本走 ctx 注入）。
"""
import json
import os
import shutil
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))
sys.path.insert(0, os.path.join(ROOT, "arena"))
import lb_runner  # noqa: E402

EPISODE = {
    "episode_id": "T_AUTH",
    "turns": [{
        "case_id": "AUTH_t01", "turn_type": "reply",
        "input": {"clock": "2026-10-19 10:00",
                  "messages": [
                      {"role": "HER", "text": "周末去爬山吗", "ts": "2026-10-19 09:58"},
                      {"role": "HER", "text": "天气报说周日晴", "ts": "2026-10-19 09:59"},
                      {"role": "HER", "text": "你去过那边没", "ts": "2026-10-19 10:00"}]},
        "gold": {},
    }],
}

# 攻击回复：引用 m3（原题只有 m0-m2）——按原题评分必须非法
ATTACK_REPLY = json.dumps({
    "response": {"recommended": "虚构来源攻击", "bad_boy": None,
                 "playful": None, "warm": None},
    "directions": [None] * 4,
    "analysis": {"topic_status": "new", "topic_label": "爬山",
                 "scene_facts": [{"text": "她说周日晴", "source_ids": ["m3"]}],
                 "ongoing": []}}, ensure_ascii=False)

ATTACK_MODES = ["append", "delete", "swap_role", "forge_idmap"]

MECH = '''# -*- coding: utf-8 -*-
import json
MODE = %(mode)r
REPLY = %(reply)r

def init(assets_root, episode_meta, gateway, sandbox):
    return {"n": 0}

def run_turn(h, ctx, gateway):
    h["n"] += 1
    msgs = ctx["input"].setdefault("messages", [])
    if MODE == "append":
        msgs.append({"role": "HER", "text": "这是候选伪造的消息", "ts": "2026-10-19 10:01"})
    elif MODE == "delete":
        del msgs[1]                      # 删掉真实 m1，使后续重编号
    elif MODE == "swap_role":
        msgs[0]["role"] = "ME"           # 改角色试图混淆来源表
    idmap = {"m0": "HER", "m3": "HER"} if MODE == "forge_idmap" else None
    return {"reply": REPLY, "notes": "attack:%%s" %% MODE, "id_map": idmap}

def snapshot(h):
    return json.dumps(h).encode("utf-8")

def restore(sandbox, snap):
    return json.loads(snap.decode("utf-8"))
'''


def make_candidate(tmp, mode):
    cdir = os.path.join(tmp, "cand_" + mode)
    os.makedirs(os.path.join(cdir, "mechanism"))
    os.makedirs(os.path.join(cdir, "assets", "system_prompt"))
    for f in ("core.md", "format.md", "redline.md", "naturalness_check.md"):
        with open(os.path.join(cdir, "assets", "system_prompt", f), "w",
                  encoding="utf-8") as fh:
            fh.write("test")
    with open(os.path.join(cdir, "mechanism", "mechanism.py"), "w",
              encoding="utf-8") as fh:
        fh.write(MECH % {"mode": mode, "reply": ATTACK_REPLY})
    return cdir


def main():
    tmp = tempfile.mkdtemp(prefix="lb_auth_")
    ep_path = os.path.join(tmp, "ep.json")
    with open(ep_path, "w", encoding="utf-8") as f:
        json.dump(EPISODE, f, ensure_ascii=False)
    fails = []
    for mode in ATTACK_MODES:
        out = os.path.join(tmp, "out_" + mode)
        cdir = make_candidate(tmp, mode)
        try:
            lb_runner.run_episode(ep_path, cdir, out, "mock")
        except Exception as e:
            fails.append("%s: runner 异常 %s: %s" % (mode, type(e).__name__, e))
            continue
        sc = json.load(open(os.path.join(out, "turn_01_AUTH_t01", "scoring.json"),
                            encoding="utf-8"))
        if sc.get("veto") != "illegal_source_id:m3":
            fails.append("%s: 伪造来源未被拦（veto=%s score=%s）"
                         % (mode, sc.get("veto"), sc.get("score10")))
        if sc.get("score10") != 0.0:
            fails.append("%s: 伪造来源仍得分 %s" % (mode, sc["score10"]))
        # 独立复核：对未被候选接触的原题直接评分，结果必须与 runner 一致
        import lb_scorer
        ref = lb_scorer.run_case_scoring(
            EPISODE["turns"][0], ATTACK_REPLY,
            lb_runner.canonical_id_map(EPISODE["turns"][0]["input"]["messages"]), None)
        if (ref["veto"], ref["score10"]) != (sc["veto"], sc["score10"]):
            fails.append("%s: runner 评分与原题权威评分不一致（%s/%s vs %s/%s）"
                         % (mode, sc["veto"], sc["score10"], ref["veto"], ref["score10"]))
    # 对照组：干净候选（不篡改）引用真实 m1 → 合法
    clean_reply = ATTACK_REPLY.replace('"m3"', '"m1"')
    cdir = os.path.join(tmp, "cand_clean")
    os.makedirs(os.path.join(cdir, "mechanism"))
    os.makedirs(os.path.join(cdir, "assets", "system_prompt"))
    for f in ("core.md", "format.md", "redline.md", "naturalness_check.md"):
        open(os.path.join(cdir, "assets", "system_prompt", f), "w",
             encoding="utf-8").write("test")
    with open(os.path.join(cdir, "mechanism", "mechanism.py"), "w",
              encoding="utf-8") as fh:
        fh.write(MECH % {"mode": "none", "reply": clean_reply})
    out = os.path.join(tmp, "out_clean")
    lb_runner.run_episode(ep_path, cdir, out, "mock")
    sc = json.load(open(os.path.join(out, "turn_01_AUTH_t01", "scoring.json"),
                        encoding="utf-8"))
    if sc.get("veto") == "illegal_source_id:m1":
        fails.append("clean: 真实来源 m1 被误判非法（对照组失败）")

    shutil.rmtree(tmp, ignore_errors=True)
    if fails:
        print("SCORING AUTHORITY FAIL")
        for x in fails:
            print(" -", x)
        sys.exit(1)
    print("SCORING AUTHORITY PASS：追加/删除/改角色/伪造 id_map 四类篡改均以原题快照评分"
          "（伪造 m3 稳定 veto=illegal_source_id:m3），真实来源对照组不误杀。")


if __name__ == "__main__":
    main()
