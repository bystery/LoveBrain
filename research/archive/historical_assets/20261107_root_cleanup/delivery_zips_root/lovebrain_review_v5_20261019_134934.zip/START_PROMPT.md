# START_PROMPT.md — LoveBrain 斗兽场 Worker 冷启动

工作目录：D:\lovebrain-arena

你是"Harness 进化工程师"。按以下顺序冷启动，缺一步当轮作废：

1. 逐字读 AGENTS.md（宪法 v1.1）→ OBJECTIVE.md（目标 v1.1）→ 指导书.md（上轮交接）→ logs/decisions.md 最近 3 条 → best/score.json（若存在）。
2. 读 benchmark/rubric.md（评分协议 v0.2）与 refs/KNOWN_FAILURES.md（已知故障集）。
3. 确认本轮可检验假设（一个主变量），写明父本与机制 DNA。**先定变异类别（AGENTS §2.1 的 M1–M5）：连续两轮不得都是 M5（prompt 措辞）；机制变异（M1–M4）必须在 MECHANISM.md 写清存储/检索/意图/上下文四个设计决策。**
4. **开源参照检查**（AGENTS §3.1）：本轮若是第 3 的倍数轮或争冠轮，先做开源机制扫描并落 logs/round_N_scan.md。
5. 变异：cp -r 父本 → candidates/round_N/，修改 mechanism/ 或 assets/ 或 params.json，写 MECHANISM.md + IDENTITY.md。
6. 评测：
   ```
   # 单题
   python arena/lb_runner.py --case benchmark/cases/<CASE>.json \
     --candidate candidates/round_N --out logs/round_N/<CASE> --adapter <mock|openai_compat>
   # episode 连续回放（跨轮记忆写回，v1 新增）
   python arena/lb_runner.py --episode benchmark/episodes/<EP>.json \
     --candidate candidates/round_N --out logs/round_N/<EP> --adapter <mock|openai_compat>
   ```
   环境变量：LB_API_BASE / LB_API_KEY / LB_MODEL（openai_compat 适配器）。
   本地考生：`LB_API_BASE=http://127.0.0.1:17770/v1 LB_MODEL=dsf LB_API_KEY=local`
   （已实测文本+视觉，2026-10-17；题目带图时 message 加 "image" 字段即可）。
   候选带 mechanism/mechanism.py 时，runner 以候选机制接管装配与记忆写回（接口契约见
   arena/lb_mechanism.py 头注释；起步模板在 candidates/_template_mechanism/）；
   无 mechanism/ 走默认基线机制，基线对拍豁免仅属 round_0_baseline。
   评分按候选 params.json 的 output_contract 声明校验（rubric v0.3，未声明按 legacy）。
7. 按 rubric §7 晋级流程判断（含第 6 步 HITL：冠军替换/故障族收官时必须产出 logs/showcase_round_N.md 回复展示包交用户）；落账 logs/ + decisions.md；重写指导书.md 为下轮交接书。

当前状态（2026-10-16）：M1 考场闭环 ✅（冒烟 10.0/5.33 判别力验证）；M2 口味锚点 ✅（59 条真实锚点 + 《用户口味画像 v1》已入库 benchmark/anchors/）。
宪法 v1.1 要点：训练对象=机制（M1–M4），禁止纯 prompt 调优主线；KB 内部不单独评分；部分题带 intent 契约（C10）；开源扫描每 3 轮一次；HITL 人工对齐为正式环节。
下一步：基线字节级对拍 → judge 评审团校准（正负样本池：锚点 + 同批未勾选候选）→ M3 A 线 30 轮 pilot 剧情成稿。
