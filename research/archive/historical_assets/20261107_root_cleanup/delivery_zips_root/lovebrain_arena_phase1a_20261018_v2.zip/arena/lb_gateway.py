# lb_gateway.py — 考场统一模型网关（Phase 0 v2，refs/REFACTOR_PLAN_PHASE0.md §2）
# 宪法地位：候选调模型的唯一通道。候选通过网关自主决定调用次数与编排（多阶段推理），
# 每次调用强制记账（tag/延迟/字符或 token），runner 汇总进评分账。
# 隔离纪律：网关持有 adapter 与 per-turn directive（mock/echo 测试替身的台本，由 runner 设置），
# 候选拿不到 case、gold、未来事件——只能拿到当轮 turn_ctx。
#
# 适配器统一签名（v2）：generate(system, user, payload) -> {"text", "finish", "usage"}
#   payload = {"images": [ref...], "model": str|None, "temperature": float|None,
#              "timeout_s": int, "directive": dict}   # directive 仅测试替身使用

import datetime
import json
import os

import lb_assembly


# ---------- 适配器 ----------

class MockAdapter:
    """确定性假适配器：返回 directive.mock_response 或内置合法 JSON。"""
    name = "mock"

    def generate(self, system: str, user: str, payload: dict) -> dict:
        d = payload.get("directive") or {}
        text = d.get("mock_response") or json.dumps({
            "response": {"recommended": "我一般挑悬疑片，看到最后还得回想一下。你呢",
                         "bad_boy": "你猜我看哪种，猜对有奖",
                         "playful": "悬疑片重度用户，要不要交换片单",
                         "warm": "看得挺杂的，你平时爱看哪种呀"},
            "directions": ["你呢，平时看哪种", None, "最近有部悬疑不错", None],
            "analysis": {"topic_status": "new", "topic_label": "电影",
                         "scene_facts": [{"text": "她今晚要加班", "source_ids": ["m0"]},
                                         {"text": "她问我周末看什么类型电影", "source_ids": ["m2"]}],
                         "ongoing": []}
        }, ensure_ascii=False)
        return {"text": text, "finish": "stop", "usage": None}


class OpenAICompatAdapter:
    """OpenAI 兼容适配器（本地 dsf / gpt-oss-120b / DeepSeek 官方等）。
    LB_API_BASE / LB_API_KEY / LB_MODEL 环境变量；usage 存在时用真实 token。
    视觉：payload.images 里的 ref（data:/http: 直用；本地路径读文件转 base64）。"""
    name = "openai_compat"

    def __init__(self):
        self.base = os.environ.get("LB_API_BASE", "").rstrip("/")
        self.key = os.environ.get("LB_API_KEY", "")
        self.model = os.environ.get("LB_MODEL", "gpt-oss-120b")
        if not self.base:
            raise RuntimeError("LB_API_BASE 未设置")

    @staticmethod
    def _image_url(ref: str) -> str:
        if ref.startswith(("data:", "http://", "https://")):
            return ref
        import base64
        import mimetypes
        mime = mimetypes.guess_type(ref)[0] or "image/png"
        with open(ref, "rb") as f:
            return "data:%s;base64,%s" % (mime, base64.b64encode(f.read()).decode())

    def generate(self, system: str, user: str, payload: dict) -> dict:
        import urllib.request
        content = [{"type": "text", "text": user}]
        for ref in payload.get("images") or []:
            content.append({"type": "image_url", "image_url": {"url": self._image_url(ref)}})
        if len(content) == 1:
            user_msg = {"role": "user", "content": user}
        else:
            user_msg = {"role": "user", "content": content}
        # 2026-10-18 修复：temperature=None 时旧写法 payload.get("temperature",0.7)
        # 因键存在返回 None，出站 JSON 实为 "temperature": null（服务端默认温度，未知值）。
        # 现显式归一：None → 0.7，且 CallLog 记录实际出站值（判决令：记录实际请求与返回）。
        _t = payload.get("temperature")
        body = json.dumps({
            "model": payload.get("model") or self.model,
            "messages": [{"role": "system", "content": system}, user_msg],
            "temperature": 0.7 if _t is None else _t,
            "stream": False,
        }).encode("utf-8")
        req = urllib.request.Request(
            self.base + "/chat/completions", data=body,
            headers={"Content-Type": "application/json",
                     "Authorization": "Bearer " + self.key})
        timeout = payload.get("timeout_s", 120)
        with urllib.request.urlopen(req, timeout=timeout if isinstance(timeout, (int, float)) else 120) as r:
            data = json.loads(r.read().decode("utf-8"))
        choice = data["choices"][0]
        return {"text": choice["message"]["content"],
                "finish": choice.get("finish_reason", ""),
                "usage": data.get("usage"),
                # 判决令 §10.1：响应侧标识落盘（响应 model / response id / finish_reason）
                "resp_model": data.get("model"), "resp_id": data.get("id")}


class EchoAdapter:
    """回声适配器（Phase 0 协议测试替身）：验证"机制组织逻辑"而非模型智商。
    行为（全部确定性）：
      - directive.keywords：每个关键词，若出现在 user prompt 中 → 进入 recommended/directions
        （考"机制有没有把该记忆注入 prompt"——注入了才会被回声吐回来）；
      - directive.decline_when：任一关键词在 prompt 中 → 输出 decline JSON（静默轮协议）；
      - directive.facts / directive.ongoing：作为 analysis 写回素材（模拟"正确抽取的模型"），
        走机制 update_state 入记忆——考"存储→检索→再注入"全链路。
    这是测试替身：台本由 runner 设置，候选不可见。真实模型质量评估归后续阶段。"""
    name = "echo"

    def generate(self, system: str, user: str, payload: dict) -> dict:
        d = payload.get("directive") or {}
        decline_hits = [kw for kw in (d.get("decline_when") or []) if kw in user]
        if decline_hits:
            out = {"response": {"recommended": None, "bad_boy": None,
                                 "playful": None, "warm": None},
                   "decline_reason": d.get("decline_reason")
                   or ("不建议发送：命中静默条件 " + ";".join(decline_hits)),
                   "directions": [None] * 4,
                   "analysis": {"topic_status": "end", "topic_label": "收尾",
                                "scene_facts": d.get("facts") or [],
                                "ongoing": d.get("ongoing") or []}}
            return {"text": json.dumps(out, ensure_ascii=False), "finish": "stop", "usage": None}

        kws = [kw for kw in (d.get("keywords") or []) if kw in user]
        if kws:
            rec = "记得：" + "、".join(kws)
            resp = {"recommended": rec, "bad_boy": "我记性可好了",
                    "playful": "考考你我还记得啥", "warm": "都记着呢"}
            dirs = [rec, None, "你还记得吗", None]
        else:
            rec = "没什么特别要提的"
            resp = {"recommended": rec, "bad_boy": "忘了也没事",
                    "playful": "随便聊聊", "warm": "慢慢聊"}
            dirs = [rec, None, "想起来再说", None]
        out = {"response": resp, "directions": dirs,
               "analysis": {"topic_status": "same", "topic_label": "echo",
                            "scene_facts": d.get("facts") or [],
                            "ongoing": d.get("ongoing") or []}}
        return {"text": json.dumps(out, ensure_ascii=False), "finish": "stop", "usage": None}


ADAPTERS = {"mock": MockAdapter, "openai_compat": OpenAICompatAdapter, "echo": EchoAdapter}


# ---------- 网关 ----------

class ModelGateway:
    """考场统一模型网关。候选唯一调模型通道；强制记账。"""

    def __init__(self, adapter):
        self._adapter = adapter
        self.calls = []          # 本轮 CallLog（runner 每轮重置）
        self.directive = {}      # 测试替身台本（runner 设置；真实适配器忽略）

    @property
    def adapter_name(self):
        return self._adapter.name

    def generate(self, system: str, user: str, images=None, model=None,
                 temperature=None, timeout_s=120, tag="main") -> dict:
        payload = {"images": images or [], "model": model,
                   "temperature": temperature, "timeout_s": timeout_s,
                   "directive": self.directive}
        t0 = datetime.datetime.now()
        try:
            res = self._adapter.generate(system, user, payload)
        except Exception as e:
            # 判决令 §10.1：失败/重试也要留账（此前适配器抛错时 calls 未 append，失败账丢失）
            lat = int((datetime.datetime.now() - t0).total_seconds() * 1000)
            self.calls.append({
                "tag": tag, "ts": t0.strftime("%H:%M:%S"), "latency_ms": lat,
                "prompt_chars": 0, "reply_chars": 0, "usage": {"source": "error"},
                "system": system, "user": user,
                "temperature": (0.7 if temperature is None else temperature),
                "images": list(images or []),
                "error": "%s: %s" % (type(e).__name__, e)})
            raise
        lat = int((datetime.datetime.now() - t0).total_seconds() * 1000)
        usage = res.get("usage")
        if usage:
            u = {"prompt": usage.get("prompt_tokens"),
                 "completion": usage.get("completion_tokens"),
                 "cache_hit": usage.get("prompt_cache_hit_tokens"),
                 "cache_miss": usage.get("prompt_cache_miss_tokens"),
                 "source": "api_usage"}
        else:
            u = {"prompt": lb_assembly.kotlin_len(system) + lb_assembly.kotlin_len(user),
                 "completion": lb_assembly.kotlin_len(res["text"]),
                 "cache_hit": None, "cache_miss": None, "source": "kotlin_len_chars"}
        self.calls.append({
            "tag": tag, "ts": t0.strftime("%H:%M:%S"), "latency_ms": lat,
            "prompt_chars": u["prompt"], "reply_chars": u["completion"], "usage": u,
            # V6 证据链：完整入参落盘（验收断言 gold 不泄漏、回复不冒充已发送）
            "system": system, "user": user,
            # 判决令 2026-10-18：实际出站参数与原始响应落盘（区分参数未生效/服务端非确定性）
            "temperature": (0.7 if temperature is None else temperature),
            "images": list(images or []),
            "resp_model": res.get("resp_model"), "resp_id": res.get("resp_id"),
            "finish": res.get("finish", ""),
            "raw_text": res.get("text", "")})
        return res

    def turn_usage(self) -> dict:
        """汇总本轮全部调用（多阶段编排 = 多条 CallLog）。"""
        if not self.calls:
            return {"prompt": 0, "completion": 0, "cache_hit": None,
                    "cache_miss": None, "source": "none", "n_calls": 0}
        src = self.calls[0]["usage"]["source"]
        return {"prompt": sum(c["usage"]["prompt"] or 0 for c in self.calls),
                "completion": sum(c["usage"]["completion"] or 0 for c in self.calls),
                "cache_hit": None, "cache_miss": None, "source": src,
                "n_calls": len(self.calls)}
