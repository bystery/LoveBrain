# lb_runner.py — LoveBrain 斗兽场考场运行时 v2（Phase 0 改造，refs/REFACTOR_PLAN_PHASE0.md）
# 职责：case/episode → Harness 生命周期驱动（v2 开放接口 / v1 兼容回退）→ 网关记账 → 评分 → manifest
# v2 变更（2026-10-17 Phase 0）：
#   - Harness 生命周期 v2：候选可暴露 init/run_turn/snapshot/restore，持有 ModelGateway 自主
#     多阶段调模型（多阶段推理成为一等能力，审计能力 3 缺口关闭）；state 可为任意对象，
#     快照为任意 bytes（文件型/sqlite 存储合法，审计能力 1 缺口关闭）。
#   - 消毒边界：交给机制/网关的 turn_ctx 剥掉 gold/mock_response/echo（审计能力 6 敞口关闭）；
#     适配器统一经 lb_gateway，不再接收原始 case。
#   - checkpoint/resume：每轮末写 checkpoint（轮指针 + 快照 bytes），--resume 断点续跑，
#     --stop-after 模拟中断（审计能力 4 缺口关闭）。
#   - 轮型协议 turn_type：reply（默认）/ rewrite（改草稿）/ silent（不建议发送，配 may_decline 契约）。
#   - v1 三函数接口继续可用（round_0_baseline 对拍豁免需要它）。
# 宪法纪律不变：本工具只做确定性搬运；变异与归因归 Worker；每轮产物全部落盘可复核。

import argparse
import datetime
import importlib.util
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lb_assembly
import lb_mechanism
import lb_scorer
from lb_gateway import ADAPTERS, ModelGateway

# 候选可见边界（2026-10-18 第四波判决 §2.1：黑名单 → 白名单）
# 旧 SANITIZE_DROP 黑名单只删 gold/mock_response/echo，漏掉 meta（布景备注/正确策略/隐藏信息）
# 与 episode 顶层 gaps（未来时间+隐藏原因）——接口违规。现改允许字段清单，白名单之外一律不给候选。
TURN_VISIBLE_KEYS = ("case_id", "input", "turn_type", "turn_index", "assets_root")
INPUT_VISIBLE_KEYS = ("messages", "clock", "intent", "may_decline", "note", "kb")
EP_META_VISIBLE_KEYS = ("episode_id", "persona", "initial_kb")


# ---------- token 记账（确定性评分账） ----------

def token_count(text: str) -> int:
    """评分账口径 v0：UTF-16 code unit 数（与 Kotlin 长度一致，确定性）。"""
    return lb_assembly.kotlin_len(text)


# ---------- 候选加载 ----------

def resolve_candidate_dir(candidate: str) -> str:
    """2026-10-18 修复：裸候选名静默失败防御。传 'round_0_baseline' 时
    assets_root='round_0_baseline/assets' 不存在，read_asset 吞 OSError 返回空串，
    导致 system prompt 整体为空（模型散文作答、契约 veto）——此类失败必须 fail-fast。"""
    if os.path.isdir(candidate):
        return candidate
    alt = os.path.join("candidates", candidate)
    if os.path.isdir(alt):
        return alt
    raise RuntimeError("候选目录不存在: %s（也尝试了 %s）" % (candidate, alt))


def load_mechanism(candidate_dir: str):
    """返回 (module, origin_str, version)。version: "v2"（有 init+run_turn）或 "v1"。
    v2 可选实现 snapshot/restore（无则 checkpoint 降级为 JSON 尝试）。
    v1 必须有 init_state/build_prompts/update_state（原契约，见 lb_mechanism.py 头注释）。"""
    mech_path = os.path.join(candidate_dir, "mechanism", "mechanism.py")
    if os.path.isfile(mech_path):
        cand = os.path.basename(candidate_dir.rstrip("/\\"))
        mod_name = "lb_candidate_mechanism_%s_%d" % (cand, id(candidate_dir))
        spec = importlib.util.spec_from_file_location(mod_name, mech_path)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        if callable(getattr(mod, "run_turn", None)) and callable(getattr(mod, "init", None)):
            return mod, "candidate:" + os.path.relpath(mech_path, candidate_dir), "v2"
        for fn in ("init_state", "build_prompts", "update_state"):
            if not callable(getattr(mod, fn, None)):
                raise RuntimeError("候选 mechanism 缺少接口函数 %s（v1/v2 契约见 arena/lb_mechanism.py）" % fn)
        return mod, "candidate:" + os.path.relpath(mech_path, candidate_dir), "v1"
    return lb_mechanism, "default:arena/lb_mechanism.py", "v1"


def load_contract(candidate_dir: str):
    pj = os.path.join(candidate_dir, "params.json")
    if os.path.isfile(pj):
        with open(pj, "r", encoding="utf-8") as f:
            return json.load(f).get("output_contract")
    return None


# ---------- 边界与工具 ----------

def sanitize_turn(turn: dict) -> dict:
    """消毒：候选可见的 turn_ctx 按白名单重组（TURN_VISIBLE_KEYS ⊂ 键，
    input 内层再按 INPUT_VISIBLE_KEYS 过滤）。作者 meta / gold / 探针标注 / 正确策略
    一律留在评估侧，不因"没在黑名单"而泄漏。"""
    ctx = {k: turn[k] for k in TURN_VISIBLE_KEYS if k in turn}
    if isinstance(ctx.get("input"), dict):
        ctx["input"] = {k: ctx["input"][k] for k in INPUT_VISIBLE_KEYS
                        if k in ctx["input"]}
    return ctx


def _turn_directive(turn: dict) -> dict:
    d = {}
    if "mock_response" in turn:
        d["mock_response"] = turn["mock_response"]
    if isinstance(turn.get("echo"), dict):
        d.update(turn["echo"])
    return d


def canonical_id_map(messages) -> dict:
    """runner 独立计算的权威 id_map（HER/ME 顺序编号；不信任候选回报）。"""
    id_map = {}
    n = 0
    for m in messages or []:
        if isinstance(m, dict) and m.get("role") in ("HER", "ME"):
            id_map["m%d" % n] = m["role"]
            n += 1
    return id_map


def _turn_dir(out_dir: str, i: int, turn: dict) -> str:
    return os.path.join(out_dir, "turn_%02d_%s" % (i + 1, turn.get("case_id", "case")))


def _w(out_dir: str, name: str, content: str):
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, name), "w", encoding="utf-8", newline="") as f:
        f.write(content)


def _wb(out_dir: str, name: str, content: bytes):
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, name), "wb") as f:
        f.write(content)


def _snapshot_bytes(version: str, mech, handle) -> bytes:
    if version == "v2":
        if callable(getattr(mech, "snapshot", None)):
            snap = mech.snapshot(handle)
            return snap if isinstance(snap, bytes) else json.dumps(
                snap, ensure_ascii=False, default=str).encode("utf-8")
        return json.dumps(handle, ensure_ascii=False, default=str).encode("utf-8")
    return json.dumps(handle, ensure_ascii=False, default=str).encode("utf-8")


def _restore_handle(version: str, mech, sandbox: str, snap: bytes):
    """v2 restore(sandbox, snap) -> harness（文件型存储在 sandbox 重建自身文件）；
    v1/无 restore：JSON 反序列化。"""
    if version == "v2" and callable(getattr(mech, "restore", None)):
        return mech.restore(sandbox, snap)
    return json.loads(snap.decode("utf-8"))


# ---------- 单轮执行 ----------

def _exec_turn_v2(turn, ctx, candidate_dir, turn_dir, gateway, mech, handle, contract) -> dict:
    t0 = datetime.datetime.now()
    out = mech.run_turn(handle, ctx, gateway)
    reply = out["reply"]
    latency_ms = int((datetime.datetime.now() - t0).total_seconds() * 1000)
    usage = gateway.turn_usage()
    id_map = canonical_id_map(ctx.get("input", {}).get("messages"))
    scoring = lb_scorer.run_case_scoring(turn, reply, id_map, contract)

    _w(turn_dir, "reply_raw.txt", reply)
    _w(turn_dir, "scoring.json", json.dumps(scoring, ensure_ascii=False, indent=2))
    _w(turn_dir, "calls.json", json.dumps(gateway.calls, ensure_ascii=False, indent=2))
    notes = out.get("notes", "")
    if notes:
        _w(turn_dir, "mechanism_notes.txt", notes)

    manifest = {
        "case_id": turn.get("case_id"), "turn_type": turn.get("turn_type", "reply"),
        "candidate": os.path.basename(candidate_dir.rstrip("/\\")),
        "adapter": gateway.adapter_name,
        "model": os.environ.get("LB_MODEL", "") or "mock",
        "lifecycle": "v2",
        "clock_injected": ctx.get("input", {}).get("clock"),
        "media_refs": _collect_images(ctx.get("input", {})),
        "tokens": usage, "gateway_calls": usage.get("n_calls", 0),
        "latency_ms": latency_ms,
        "score10": scoring["score10"], "veto": scoring["veto"],
        "mechanism_error": None,
        "ts": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "prompt_chars": {"prompt_sum": usage.get("prompt"), "reply_sum": usage.get("completion")},
    }
    _w(turn_dir, "manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
    return manifest


def _collect_images(case_input: dict) -> list:
    """收集本轮消息携带的图片资产引用（判决令 §2：资产存在 ≠ 进入请求，须显式传网关）。"""
    return [m["image"] for m in (case_input.get("messages") or [])
            if isinstance(m, dict) and m.get("image")]


def _exec_turn_v1(turn, ctx, candidate_dir, turn_dir, gateway, mech, state, contract) -> dict:
    assets_root = os.path.join(candidate_dir, "assets")
    t0 = datetime.datetime.now()
    assembled = mech.build_prompts(assets_root, ctx["input"], state)
    images = _collect_images(ctx["input"])
    gen = gateway.generate(assembled["system"], assembled["user"],
                           images=images or None,
                           model=turn.get("model"), temperature=turn.get("temperature"),
                           timeout_s=turn.get("timeout_s", 120), tag="main")
    latency_ms = int((datetime.datetime.now() - t0).total_seconds() * 1000)
    usage = gateway.turn_usage()
    scoring = lb_scorer.run_case_scoring(turn, gen["text"], assembled["id_map"], contract)

    mech_error = None
    if state is not None:
        parsed = lb_scorer.extract_json_block(gen["text"])
        try:
            mech.update_state(state, ctx["input"], parsed, gen["text"])
        except Exception as e:
            mech_error = "%s: %s" % (type(e).__name__, e)

    _w(turn_dir, "prompt_system.txt", assembled["system"])
    _w(turn_dir, "prompt_user.txt", assembled["user"])
    _w(turn_dir, "reply_raw.txt", gen["text"])
    _w(turn_dir, "scoring.json", json.dumps(scoring, ensure_ascii=False, indent=2))
    _w(turn_dir, "calls.json", json.dumps(gateway.calls, ensure_ascii=False, indent=2))
    if state is not None:
        _w(turn_dir, "state_after.json",
           json.dumps(state, ensure_ascii=False, indent=2, default=str))

    manifest = {
        "case_id": turn.get("case_id"), "turn_type": turn.get("turn_type", "reply"),
        "candidate": os.path.basename(candidate_dir.rstrip("/\\")),
        "adapter": gateway.adapter_name,
        "model": turn.get("model") or os.environ.get("LB_MODEL", "mock"),
        "lifecycle": "v1",
        "clock_injected": ctx["input"].get("clock"),
        "scene_inferred": assembled.get("scene"),
        "media_refs": _collect_images(ctx["input"]),
        "tokens": usage, "gateway_calls": usage.get("n_calls", 0),
        "latency_ms": latency_ms,
        "score10": scoring["score10"], "veto": scoring["veto"],
        "mechanism_error": mech_error,
        "ts": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "prompt_chars": {"system": lb_assembly.kotlin_len(assembled["system"]),
                         "user": lb_assembly.kotlin_len(assembled["user"])},
    }
    _w(turn_dir, "manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2))
    if mech_error:
        raise RuntimeError("mechanism_error at case %s: %s" % (turn.get("case_id"), mech_error))
    return manifest


# ---------- 单题模式 ----------

def run_case(case_path: str, candidate_dir: str, out_dir: str, adapter_name: str) -> dict:
    with open(case_path, "r", encoding="utf-8") as f:
        case = json.load(f)
    mech, origin, version = load_mechanism(candidate_dir)
    contract = load_contract(candidate_dir)
    gateway = ModelGateway(ADAPTERS[adapter_name]())
    gateway.directive = _turn_directive(case)
    ctx = sanitize_turn(case)
    os.makedirs(out_dir, exist_ok=True)
    if version == "v2":
        sandbox = os.path.join(out_dir, "_sandbox")
        os.makedirs(sandbox, exist_ok=True)
        handle = mech.init(os.path.join(candidate_dir, "assets"), {"mode": "single"}, gateway, sandbox)
        ctx["assets_root"] = os.path.join(candidate_dir, "assets")
        ctx["turn_type"] = case.get("turn_type", "reply")
        ctx["turn_index"] = 1
        m = _exec_turn_v2(case, ctx, candidate_dir, out_dir, gateway, mech, handle, contract)
    else:
        state = mech.init_state(os.path.join(candidate_dir, "assets"), {"mode": "single"})
        m = _exec_turn_v1(case, ctx, candidate_dir, out_dir, gateway, mech, state, contract)
    m["mechanism"] = origin
    m["contract"] = contract or "legacy"
    _w(out_dir, "manifest.json", json.dumps(m, ensure_ascii=False, indent=2))
    return m


# ---------- episode 连续回放（v2：消毒 + checkpoint + resume） ----------

def run_episode(episode_path: str, candidate_dir: str, out_dir: str, adapter_name: str,
                stop_after=None, resume=False, intent_override=None) -> dict:
    with open(episode_path, "r", encoding="utf-8") as f:
        ep = json.load(f)
    mech, origin, version = load_mechanism(candidate_dir)
    contract = load_contract(candidate_dir)
    gateway = ModelGateway(ADAPTERS[adapter_name]())
    os.makedirs(out_dir, exist_ok=True)
    sandbox = os.path.join(out_dir, "_sandbox")
    os.makedirs(sandbox, exist_ok=True)
    assets_root = os.path.join(candidate_dir, "assets")

    # 判决令 §2.1：ep_meta 白名单——gaps（未来时间+隐藏原因）、布景 note 等留在评估侧；
    # persona / initial_kb 是"语义上已发生且允许候选知道"的显式可见入口。
    ep_meta = {k: v for k, v in ep.items() if k in EP_META_VISIBLE_KEYS}
    ck_path = os.path.join(out_dir, "checkpoint.json")
    ck_bin = os.path.join(out_dir, "checkpoint.bin")

    start_idx = 0
    if resume and os.path.isfile(ck_path):
        with open(ck_path, "r", encoding="utf-8") as f:
            ck = json.load(f)
        start_idx = int(ck["turns_done"])
        with open(ck_bin, "rb") as f:
            snap = f.read()
        handle = _restore_handle(version, mech, sandbox, snap)   # v2 文件型存储在此重建
    elif version == "v2":
        handle = mech.init(assets_root, ep_meta, gateway, sandbox)
    else:
        handle = mech.init_state(assets_root, ep_meta)

    turns_manifest = []
    # Phase 0.5 意图对照：--intent-override 从 resume 点起把每轮 intent 覆盖为指定文本。
    # 配合 --stop-after/--resume = 冻结同一 Harness 状态分叉，仅改意图（严格对照）。
    if intent_override is not None:
        for i in range(start_idx, len(ep["turns"])):
            inp = ep["turns"][i].setdefault("input", {})
            inp["intent"] = {"enabled": True, "text": intent_override}
    for i in range(start_idx):   # 已完成轮：从落盘 manifest 重建汇总
        td = _turn_dir(out_dir, i, ep["turns"][i])
        with open(os.path.join(td, "manifest.json"), "r", encoding="utf-8") as f:
            turns_manifest.append(json.load(f))

    ran = 0
    for i in range(start_idx, len(ep["turns"])):
        if stop_after is not None and (i + 1) > stop_after:
            break
        turn = ep["turns"][i]
        turn_dir = _turn_dir(out_dir, i, turn)
        gateway.calls = []
        gateway.directive = _turn_directive(turn)
        ctx = sanitize_turn(turn)
        ctx["assets_root"] = assets_root
        ctx["sandbox"] = sandbox
        ctx["turn_type"] = turn.get("turn_type", "reply")
        ctx["turn_index"] = i + 1
        if version == "v2":
            m = _exec_turn_v2(turn, ctx, candidate_dir, turn_dir, gateway, mech, handle, contract)
        else:
            m = _exec_turn_v1(turn, ctx, candidate_dir, turn_dir, gateway, mech, handle, contract)
        turns_manifest.append(m)
        ran += 1
        # checkpoint：每轮末落快照（v2 = 候选自管 bytes；v1 = state JSON）
        _wb(out_dir, "checkpoint.bin", _snapshot_bytes(version, mech, handle))
        _w(out_dir, "checkpoint.json", json.dumps({
            "turns_done": i + 1, "episode_id": ep.get("episode_id"),
            "candidate": os.path.basename(candidate_dir.rstrip("/\\")),
            "lifecycle": version, "ts": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")},
            ensure_ascii=False, indent=2))

    # ---- episode 汇总（含 resume 拼接的全部轮） ----
    n = len(turns_manifest)
    scores = [m["score10"] for m in turns_manifest]
    vetoes = [m for m in turns_manifest if m["veto"]]
    tok_prompt = sum((m["tokens"].get("prompt") or 0) for m in turns_manifest)
    tok_completion = sum((m["tokens"].get("completion") or 0) for m in turns_manifest)
    lat = sorted(m["latency_ms"] for m in turns_manifest)
    p95 = lat[min(len(lat) - 1, int(len(lat) * 0.95))] if lat else 0

    stale_cfg = stale_hit = 0
    for i, turn in enumerate(ep["turns"][:len(turns_manifest)]):
        if (turn.get("gold") or {}).get("stale_fact_must_not"):
            stale_cfg += 1
            spath = os.path.join(_turn_dir(out_dir, i, turn), "scoring.json")
            with open(spath, "r", encoding="utf-8") as f:
                sc = json.load(f)
            if any((not c["pass"]) for c in sc["checks"] if c["id"].startswith("stale_kw_")):
                stale_hit += 1

    complete = n == len(ep["turns"])

    # ---- Phase 0.5 v2.1：探针加权汇总 + 探针窗口泄漏自检 ----
    # 天花板效应修复：220 轮均值会把探针淹没（无记忆候选 9.99 实证）。
    # probe turns（gold 含探针键）权重 W_PROBE=10，普通轮权重 1。
    PROBE_KEYS = ("must_keywords_any", "stale_fact_must_not", "intent_keywords_any",
                  "intent_must_not_keywords", "expect_decline", "must_not_keywords",
                  "expect_ongoing", "forbidden_new_facts", "geo_impossible_must_not")
    W_PROBE = 10
    wsum = 0.0
    gotsum = 0.0
    probe_report = []
    for i, turn in enumerate(ep["turns"][:len(turns_manifest)]):
        g = turn.get("gold") or {}
        is_probe = any(g.get(k) for k in PROBE_KEYS)
        sc = json.load(open(os.path.join(_turn_dir(out_dir, i, turn), "scoring.json"),
                            encoding="utf-8"))
        if is_probe:
            w = W_PROBE
            # 窗口泄漏自检：召回探针的关键词若全部出现在当轮 HER 消息里，
            # 该探针测不到记忆（候选看当轮窗口就能命中），标记 invalid。
            leak = False
            if g.get("must_keywords_any"):
                window_text = "".join(
                    m.get("text", "") for m in turn.get("input", {}).get("messages", [])
                    if isinstance(m, dict) and m.get("role") == "HER")
                leak = all(all(opt in window_text for opt in (grp if isinstance(grp, list) else [grp]))
                           for grp in g["must_keywords_any"])
            probe_report.append({
                "turn": i + 1, "case_id": turn.get("case_id"),
                "score10": sc["score10"], "veto": sc["veto"],
                "failed_checks": [c["id"] for c in sc["checks"] if not c["pass"]],
                "window_leak": leak})
        else:
            w = 1
        wsum += w
        gotsum += w * sc["score10"] / 10.0

    probe_weighted_score = round(gotsum / wsum * 10, 2) if wsum else 0.0

    ep_manifest = {
        "episode_id": ep.get("episode_id"),
        "candidate": os.path.basename(candidate_dir.rstrip("/\\")),
        "adapter": adapter_name, "mechanism": origin,
        "lifecycle": version, "contract": contract or "legacy",
        "turns": n, "turns_total": len(ep["turns"]), "complete": complete,
        "resumed_from": start_idx if start_idx else None,
        "mean_score10": round(sum(scores) / n, 2) if n else 0.0,
        "probe_weighted_score10": probe_weighted_score,
        "probe_report": probe_report,
        "veto_turns": len(vetoes),
        "first_pass_rate": round(sum(1 for m in turns_manifest if not m["veto"]) / n, 4) if n else 0.0,
        "stale_pollution": {"probes": stale_cfg, "hits": stale_hit,
                            "rate": round(stale_hit / stale_cfg, 4) if stale_cfg else None},
        "tokens_total": {"prompt": tok_prompt, "completion": tok_completion},
        "latency_ms_p95": p95,
        "ts": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    _w(out_dir, "episode_manifest.json", json.dumps(ep_manifest, ensure_ascii=False, indent=2))
    return ep_manifest


def main():
    ap = argparse.ArgumentParser(description="LoveBrain arena runner v2")
    ap.add_argument("--case", help="单题模式：case JSON 路径")
    ap.add_argument("--episode", help="连续回放模式：episode JSON 路径")
    ap.add_argument("--candidate", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--adapter", default="mock", choices=list(ADAPTERS.keys()))
    ap.add_argument("--stop-after", type=int, default=None,
                    help="跑到第 N 轮后停下（保留 checkpoint），模拟中断")
    ap.add_argument("--resume", action="store_true", help="从最近 checkpoint 续跑")
    ap.add_argument("--intent-override", default=None,
                    help="从 resume 点起覆盖每轮持续意图为该自由文本（冻结状态意图对照用）")
    args = ap.parse_args()
    if bool(args.case) == bool(args.episode):
        ap.error("--case 与 --episode 必须且只能给一个")

    cand_dir = resolve_candidate_dir(args.candidate)
    if args.case:
        m = run_case(args.case, cand_dir, args.out, args.adapter)
        print(json.dumps({"case_id": m["case_id"], "score10": m["score10"],
                          "veto": m["veto"], "tokens": m["tokens"],
                          "lifecycle": m["lifecycle"], "mechanism": m["mechanism"]},
                         ensure_ascii=False))
    else:
        m = run_episode(args.episode, cand_dir, args.out, args.adapter,
                        stop_after=args.stop_after, resume=args.resume,
                        intent_override=args.intent_override)
        print(json.dumps({"episode_id": m["episode_id"], "turns": m["turns"],
                          "turns_total": m["turns_total"], "complete": m["complete"],
                          "mean_score10": m["mean_score10"],
                          "veto_turns": m["veto_turns"],
                          "stale_pollution": m["stale_pollution"],
                          "resumed_from": m["resumed_from"],
                          "lifecycle": m["lifecycle"], "mechanism": m["mechanism"]},
                         ensure_ascii=False))


if __name__ == "__main__":
    main()
