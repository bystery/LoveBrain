# -*- coding: utf-8 -*-
"""test_input_boundary.py — 判决令 §2.1 验收：候选输入边界白名单反例验证。

用带独特隐藏标记（XXHIDDENMARKERXX）的假 episode 走完整 runner 路径（mock 适配器），
断言：1) 作者 meta / gaps / 隐藏原因不出现在候选可见对象、init 负载、网关请求、沙箱文件；
2) persona / 消息 ts / may_decline 这三类"应见信息"确实到达。
这是接口级验证，不以禁词扫描代替（标记是唯一可信探针）。"""
import json
import os
import sys
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "arena"))
import lb_runner  # noqa: E402

MARK = "XXHIDDENMARKERXX"

FAKE_EP = {
    "episode_id": "BOUNDARY_TEST",
    "note": "布景备注 " + MARK,
    "city": "某市 " + MARK,
    "relation_stage": "测试 " + MARK,
    "gaps": [{"from": "2026-10-01 10:00", "to": "2026-10-02 10:00",
              "reason": "补觉+家务 " + MARK}],
    "persona": {"关系": "高中同学", "她坐标": "苏州", "我坐标": "合肥"},
    "initial_kb": {},
    "turns": [
        {"case_id": "B_t01",
         "input": {"clock": "2026-10-05 21:47",
                   "messages": [{"role": "HER", "text": "在吗", "ts": "2026-10-05 21:41"}],
                   "intent": {"enabled": True, "text": "正常意图"},
                   "may_decline": True},
         "meta": {"note": "作者备注 " + MARK, "strategy": "正确策略 " + MARK},
         "gold": {"expect_decline": True}},
    ],
}


def scan(obj, mark=MARK):
    """递归找标记，返回出现的路径列表。"""
    hits = []
    def walk(o, path):
        if isinstance(o, str):
            if mark in o:
                hits.append(path)
        elif isinstance(o, dict):
            for k, v in o.items():
                walk(v, path + "." + str(k))
        elif isinstance(o, (list, tuple)):
            for i, v in enumerate(o):
                walk(v, "%s[%d]" % (path, i))
    walk(obj, "$")
    return hits


def main():
    fails = []
    # 1) sanitize_turn：meta/gold 不得出现
    ctx = lb_runner.sanitize_turn(FAKE_EP["turns"][0])
    hits = scan(ctx)
    if hits:
        fails.append("sanitize_turn 泄漏: %s" % hits)
    if "meta" in ctx or "gold" in ctx:
        fails.append("sanitize_turn 顶层键含 meta/gold: %s" % list(ctx.keys()))
    if not ctx.get("input", {}).get("may_decline"):
        fails.append("may_decline 未透传（应见信息丢失）")
    if ctx["input"]["messages"][0].get("ts") != "2026-10-05 21:41":
        fails.append("消息 ts 未透传（应见信息丢失）")

    # 2) ep_meta 白名单：gaps/note/city/relation_stage 不得出现；persona 必须在
    ep = json.loads(json.dumps(FAKE_EP, ensure_ascii=False))
    ep_meta = {k: v for k, v in ep.items() if k in lb_runner.EP_META_VISIBLE_KEYS}
    hits = scan(ep_meta)
    if hits:
        fails.append("ep_meta 泄漏: %s" % hits)
    if "gaps" in ep_meta or "note" in ep_meta:
        fails.append("ep_meta 含 gaps/note: %s" % list(ep_meta.keys()))
    if not ep_meta.get("persona"):
        fails.append("persona 未进入 init 负载（应见信息丢失）")

    # 3) 端到端：mock 跑一轮，扫网关 calls + 落盘文件
    tmp = tempfile.mkdtemp(prefix="lb_boundary_")
    ep_path = os.path.join(tmp, "ep.json")
    with open(ep_path, "w", encoding="utf-8") as f:
        json.dump(FAKE_EP, f, ensure_ascii=False)
    out = os.path.join(tmp, "run")
    os.environ.pop("LB_API_BASE", None)
    m = lb_runner.run_episode(ep_path, "candidates/round_0_baseline", out, "mock")
    leaks = []
    for root, _, files in os.walk(out):
        for fn in files:
            p = os.path.join(root, fn)
            data = open(p, "rb").read()
            if MARK.encode("utf-8") in data and "_sandbox" not in root:
                leaks.append(os.path.relpath(p, out))
            if fn == "calls.json":
                c = json.loads(data.decode("utf-8"))
                for call in c:
                    blob = json.dumps(call, ensure_ascii=False)
                    if MARK in blob:
                        leaks.append(p + " (calls)")
                    if call.get("user") and "高中同学" not in call["user"]:
                        leaks.append(p + " (persona 未进模型请求)")
                    if '"ts"' not in (call.get("user") or ""):
                        leaks.append(p + " (消息 ts 未进模型请求)")
    if leaks:
        fails.append("端到端泄漏/缺失: %s" % leaks)

    if fails:
        print("BOUNDARY TEST FAIL")
        for x in fails:
            print(" -", x)
        sys.exit(1)
    print("BOUNDARY TEST PASS：meta/gaps/gold 零泄漏；persona/消息 ts/may_decline 均到达模型请求。")


if __name__ == "__main__":
    main()
