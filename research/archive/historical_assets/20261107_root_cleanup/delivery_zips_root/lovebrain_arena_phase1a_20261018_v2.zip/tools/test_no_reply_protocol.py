# -*- coding: utf-8 -*-
"""test_no_reply_protocol.py — 判决令 §8 验收：no_reply 协议对两候选一致生效。

夹具两枚（用户明确不发 / 允许可不回）+ echo 替身强制两种输出形态：
  A. action="no_reply"（新统一动作）
  B. decline_reason="..."（旧式静默）
断言：baseline / beta_single / phase0_beta 三候选在两种形态下均判合法 decline；
违反例（may_decline=True 但输出正常回复且 gold.expect_decline）必须扣分。零网络调用。"""
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "arena"))
import lb_scorer  # noqa: E402

FIXTURE_ALLOW = {   # 可不回：不回与短告别均合法
    "case_id": "FIX_allow", "turn_type": "may_decline",
    "input": {"clock": "2026-10-24 12:30",
              "messages": [{"role": "HER", "text": "不聊了 我去看剧了", "ts": "2026-10-24 12:28"},
                           {"role": "HER", "text": "拜拜", "ts": "2026-10-24 12:30"}],
              "may_decline": True},
    "gold": {},
}
FIXTURE_REQUIRED = {  # 用户明确不发：必须不建议发送
    "case_id": "FIX_required", "turn_type": "silent",
    "input": {"clock": "2026-10-24 23:58",
              "messages": [{"role": "HER", "text": "别回了 我睡了", "ts": "2026-10-24 23:58"}],
              "may_decline": True},
    "gold": {"expect_decline": True},
}


def out_action():
    return json.dumps({"action": "no_reply", "reason": "对方已收尾"}, ensure_ascii=False)


def out_decline():
    return json.dumps({"response": {"recommended": None, "bad_boy": None,
                                    "playful": None, "warm": None},
                       "decline_reason": "对方已收尾",
                       "directions": [None] * 4,
                       "analysis": {"topic_status": "end", "topic_label": "收尾",
                                    "scene_facts": [], "ongoing": []}},
                      ensure_ascii=False)


def out_normal():
    return json.dumps({"response": {"recommended": "拜拜 下次聊", "bad_boy": "滚去睡吧",
                                    "playful": "晚安戊", "warm": "好梦"},
                       "directions": ["下次聊", None, None, None],
                       "analysis": {"topic_status": "end", "topic_label": "道别",
                                    "scene_facts": [], "ongoing": []}},
                      ensure_ascii=False)


def main():
    fails = []
    for cand in ("round_0_baseline", "phase0_beta_single", "phase0_beta"):
        pj = os.path.join("candidates", cand, "params.json")
        contract = json.load(open(pj, encoding="utf-8")).get("output_contract")
        for case, tag in ((FIXTURE_ALLOW, "allow"), (FIXTURE_REQUIRED, "required")):
            for name, raw in (("action", out_action()), ("decline", out_decline()),
                              ("normal", out_normal())):
                r = lb_scorer.run_case_scoring(case, raw, {}, contract)
                veto, c0 = r["veto"], {x["id"]: x for x in r["checks"]}
                schema_ok = c0["json_schema_valid"]["pass"]
                if name in ("action", "decline"):
                    if veto or not schema_ok:
                        fails.append("%s/%s/%s: 合法不回被 veto=%s schema=%s"
                                     % (cand, tag, name, veto, schema_ok))
                else:  # normal 回复在 allow 夹具合法；在 required 夹具应扣 decline_expected 分
                    if tag == "allow" and (veto or not schema_ok):
                        fails.append("%s/allow/normal: 正常告别被误判 veto=%s" % (cand, veto))
                    if tag == "required":
                        dec = c0.get("decline_expected")
                        if dec is None or dec["pass"]:
                            fails.append("%s/required/normal: 违例未被扣分" % cand)
    if fails:
        print("NO_REPLY PROTOCOL FAIL")
        for x in fails:
            print(" -", x)
        sys.exit(1)
    print("NO_REPLY PROTOCOL PASS：三候选 × {action,decline,normal} × {allow,required} 语义一致。")


if __name__ == "__main__":
    main()
