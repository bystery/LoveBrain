#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""盲评材料生成 v2（第四波判决 §4/§12.5）。

相对 v1 的修正：
  - 注入必要共同背景（persona：城市/关系/身份）——判决令 §4.1：缺背景不能判旧事重提与人物一致性；
  - 每组 A/B **分别**给 原样可发/修改后可发/不想发 三态，再独立选 A/B/都可/都不想发，可加"不回更合适"；
  - 失败行不隐藏：一方契约失败时，另一方的有效输出仍完整展示（v1 直接整组剔除）；
  - 每组引用 run 目录 + case_id（判决令 §4.3：样例可溯源）；
  - 保留 v1 纪律：结构化提取 recommended ≠ 润色；A/B 随机可反查；仅开发反馈。
"""
import json, glob, os, random

RUN = "logs/pilot_r3"
SEED = 20261019
SKIP = set()          # v2：媒体轮图片已真实进入请求，不再预剔
OUT = "refs/BLIND_SAMPLES_PILOT_R2.md"


def load_run(d):
    turns = {}
    for td in sorted(glob.glob(os.path.join(d, "turn_*"))):
        m = json.load(open(os.path.join(td, "manifest.json"), encoding="utf-8"))
        cid = m["case_id"]
        raw = open(os.path.join(td, "reply_raw.txt"), encoding="utf-8").read().strip()
        reply = None
        if not m.get("veto"):
            try:
                reply = json.loads(raw)["response"]["recommended"].strip()
            except Exception:
                reply = None
        turns[cid] = {"raw": raw, "reply": reply,
                      "veto": m.get("veto") or (None if reply else "extract_failed"),
                      "clock": m.get("clock_injected"), "score": m.get("score10"),
                      "media": m.get("media_refs") or []}
    return turns


def main():
    ep = json.load(open("benchmark/episodes/PILOT_L1_v1.json", encoding="utf-8"))
    base = load_run(os.path.join(RUN, "baseline_L1"))
    beta = load_run(os.path.join(RUN, "beta_L1"))
    rng = random.Random(SEED)
    n_ok_base = sum(1 for v in base.values() if not v["veto"])
    n_ok_beta = sum(1 for v in beta.values() if not v["veto"])
    lines = ["# Pilot L1 真实模型匿名盲评材料 R2（自动生成，原始回复未润色）\n",
             "> 固定模型 dsf；同冻结外部历史（候选草稿不入历史）、同预算口径；A/B 身份随机（seed=%d）。" % SEED,
             "> **共同背景（两人都已知）**：" + "；".join(
                 "%s=%s" % (k, v) for k, v in ep.get("persona", {}).items()),
             "> **全请求可用性（先于质量看）**：基线契约通过 %d/12，β_single %d/12；失败轮见组内标注。"
             % (n_ok_base, n_ok_beta),
             "> 消息时间戳已注入模型上下文（R2 修复）；图片经 image_url 通道进入请求（媒体轮标注）。\n"]
    keys = [t["case_id"] for t in ep["turns"] if t["case_id"] not in SKIP]
    keymap = {}
    n = 0
    for cid in keys:
        t = next(x for x in ep["turns"] if x["case_id"] == cid)
        if cid not in base or cid not in beta:
            lines.append("\n## %s ——（缺运行，跳过）\n" % cid)
            continue
        n += 1
        a_is_base = rng.random() < 0.5
        keymap[cid] = "baseline" if a_is_base else "beta_single"
        a, b = (base, beta) if a_is_base else (beta, base)
        lines.append("\n## 组 %d · %s（请求时间 %s）%s\n" % (
            n, cid, t["input"]["clock"],
            " · 媒体轮（图片已进请求）" if t["input"].get("media") else ""))
        lines.append("**聊天上下文**（末条为待回复消息）：\n")
        for m in t["input"]["messages"]:
            sp = "她" if m["role"] == "HER" else "我"
            lines.append("- %s（%s）：%s" % (sp, m["ts"][11:16], m["text"]))
        intent = (t["input"].get("intent") or {}).get("text")
        if intent:
            lines.append("\n**我的意图**：%s" % intent)
        if t["input"].get("may_decline"):
            lines.append("\n**本轮允许不回**（不回与短告别均自然）")
        for label, cand in (("A", a), ("B", b)):
            if cand[cid]["veto"]:
                lines.append("\n**匿名回复 %s**：〔契约失败：%s，无可展示文本——失败如实计入可用性，不作质量评价〕"
                             % (label, cand[cid]["veto"]))
            else:
                lines.append("\n**匿名回复 %s**\n\n> %s" % (label, cand[cid]["reply"]))
        lines.append("\n**评价**（A、B 分别勾选其一；再做总选）：\n")
        lines.append("- 回复 A：[ ] 原样可发 [ ] 修改后可发（写怎么改） [ ] 不想发（写为什么）")
        lines.append("- 回复 B：[ ] 原样可发 [ ] 修改后可发（写怎么改） [ ] 不想发（写为什么）")
        lines.append("- 总选：[ ] A 更好 [ ] B 更好 [ ] 都可 [ ] 都不想发"
                     "  附加：[ ] 这轮不回更合适（若勾，写哪句都不自然的原因）\n")
    lines.append("\n---\n\n**评分键（评完再看）**：seed=%d，A 身份映射见 %s/blind_key.json\n" % (SEED, RUN))
    open(OUT, "w", encoding="utf-8").write("\n".join(lines))
    json.dump({"seed": SEED, "a_is_baseline": keymap,
               "run_baseline": os.path.join(RUN, "baseline_L1"),
               "run_beta": os.path.join(RUN, "beta_L1")},
              open(os.path.join(RUN, "blind_key.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print("盲评材料 %d 组 → %s" % (n, OUT))


if __name__ == "__main__":
    main()
