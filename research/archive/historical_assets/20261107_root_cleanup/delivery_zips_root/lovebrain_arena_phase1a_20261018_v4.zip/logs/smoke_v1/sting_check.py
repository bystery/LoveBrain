# 蜂刺判别力专项验证（C12 物理可行性 / C13 风格趋同）
import sys
sys.path.insert(0, "arena")
import lb_scorer

case = {"gold": {"geo_impossible_must_not": ["一起吃饭", "我去接你"],
                 "geo_reason": "异地，客观上不可能"}}
bad = '{"response":{"recommended":"那我等你下课一起去吃饭？","bad_boy":"下课我去接你","playful":"想你了","warm":"好好上课"},"directions":["a","b","c","d"],"analysis":{"topic_status":"x","topic_label":"y","scene_facts":[],"ongoing":[]}}'
good = '{"response":{"recommended":"那我等你下课，上线了找我","bad_boy":"好好上课，别想着我","playful":"老师拖堂的话我帮你骂他","warm":"下课了跟我说一声"},"directions":["a","b","c","d"],"analysis":{"topic_status":"x","topic_label":"y","scene_facts":[],"ongoing":[]}}'
r_bad = lb_scorer.run_case_scoring(case, bad, {})
r_good = lb_scorer.run_case_scoring(case, good, {})
print("C12 bad:", r_bad["score10"], "| good:", r_good["score10"])
assert r_bad["score10"] < r_good["score10"], "C12 无判别力"

dup = '{"response":{"recommended":"你在干嘛呢","bad_boy":"你在干嘛呢","playful":"你在干嘛呢","warm":"你在干嘛呢"},"directions":["a","b","c","d"],"analysis":{"topic_status":"x","topic_label":"y","scene_facts":[],"ongoing":[]}}'
div = '{"response":{"recommended":"在搬砖，你呢","bad_boy":"你猜","playful":"在想一个穿裙子的人","warm":"刚忙完，正想找你"},"directions":["a","b","c","d"],"analysis":{"topic_status":"x","topic_label":"y","scene_facts":[],"ongoing":[]}}'
r_dup = lb_scorer.run_case_scoring({"gold": {}}, dup, {})
r_div = lb_scorer.run_case_scoring({"gold": {}}, div, {})
c13_dup = [c for c in r_dup["checks"] if c["id"] == "style_diversity"][0]
c13_div = [c for c in r_div["checks"] if c["id"] == "style_diversity"][0]
print("C13 dup pass=", c13_dup["pass"], c13_dup["evidence"], "| div pass=", c13_div["pass"], c13_div["evidence"])
assert not c13_dup["pass"] and c13_div["pass"], "C13 无判别力"
print("STING_OK")
